﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using log4net.Config;
using log4net.Core;
using AdvancedLogging.BE;
using AdvancedLogging.BLL;
using AdvancedLogging.Logging;
using AdvancedLogging.Utils;
using AdvancedLogging.DAL;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Linq;
using AdvancedLogging.SecureCredentials;
using System.Windows.Forms;

namespace HelperLibrary.TestConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationSettings.Logger = new CLog("TestApp");
            AdvancedLogging.Utils.SecurityProtocol.EnableAllTlsSupport();
            LogConfigData();
            RunAllTests();
        }
        private static void RunAllTests()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    Uri _DetectedUri;

                    string strUrl = "http://qa1.stage.mainspringhealth.com";
                    vAutoLogFunction.WriteLog("Testing: VerifyUrl ...");
                    if (AdvancedLogging.Utils.Utils.VerifyUrl(strUrl, out _DetectedUri))
                    {
                        Debug.WriteLine(_DetectedUri.ToString());
                    }
                    {
                        try
                        {
                            dynamic dt = "Test".ToType("Test".GetType());

                            LoggingExtensions.Log(dt, 0);
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine(ex.Message);
                        }

                        HttpWebRequest webRequest = WebRequest.Create(_DetectedUri == null ? new Uri(strUrl) : _DetectedUri) as HttpWebRequest;
                        webRequest.AllowAutoRedirect = true;
                        webRequest.Timeout = 20 * 1000;
                        webRequest.Credentials = System.Net.CredentialCache.DefaultCredentials;

                        //DataConnectionDialog dataConnectionDialog = new DataConnectionDialog();

                        string strUserName = "";
                        string strPassword = "";
                        string strName = null;

                        CredentialsDialog dialog = new CredentialsDialog("SQL Credentials");
                        if (strName != null) dialog.AlwaysDisplay = true; // prevent an infinite loop
                        if (dialog.Show(strName) == DialogResult.OK)
                        {
                            strUserName = dialog.Name;
                            strPassword = dialog.Password;
                        }
                        SqlCommand sqlCommand = new SqlCommand("SELECT GETUTCDATE() AS SERVERTIME, @TestInt AS TESTINT, @TestBit AS TESTBIT, @TestFloat AS TESTFLOAT, @TestChar50 AS TESTCHAR50", new SqlConnection(@"Data Source=localhost;Initial Catalog=master;Persist Security Info=True;User ID=" + strUserName + ";Password=" + strPassword + ";Network Library=DBMSSOCN;Application Name=Test App Name;"));

                        SqlParameter[] arrParms = {
                            new SqlParameter("TestInt", System.Data.SqlDbType.BigInt),
                            new SqlParameter("TestBit", System.Data.SqlDbType.Bit),
                            new SqlParameter("TestFloat", System.Data.SqlDbType.Float),
                            new SqlParameter("TestChar50", System.Data.SqlDbType.Char, 50)
                        };
                        arrParms[0].Value = 56755;
                        arrParms[1].Value = 1;
                        arrParms[2].Value = 567.876;
                        arrParms[3].Value = "Test String";
                        try
                        {
                            vAutoLogFunction.WriteLog("Testing: TestHttpRequest ...");
                            TestHttpRequest(webRequest);
                        }
                        catch { }
                        try
                        {
                            vAutoLogFunction.WriteLog("Testing: TestSqlCommand using SqlHelperStatic ...");
                            TestSqlCommand(sqlCommand, arrParms, true);
                        }
                        catch { }
                        try
                        {
                            vAutoLogFunction.WriteLog("Testing: TestSqlCommand without using SqlHelperStatic ...");
                            TestSqlCommand(sqlCommand, arrParms);
                        }
                        catch { }
                        try
                        {
                            vAutoLogFunction.WriteLog("Testing: TestSqlCommand SqlHelperStatic and creating a SQL Exception ...");
                            TestSqlCommand(sqlCommand, arrParms, true, true);
                        }
                        catch { }
                        try
                        {
                            vAutoLogFunction.WriteLog("Testing: TestDataTypes ...");
                            TestDataTypes(10.80m, "Test String", 456.9874, 5987);
                        }
                        catch { }
                    }
                    TestClass tc = new TestClass();
                    try
                    {
                        vAutoLogFunction.WriteLog("Testing: using a class called TestClass() ...");
                        vAutoLogFunction.WriteLog("Test Class Value: " + tc.Test());
                    }
                    catch { }
                    try
                    {
                        vAutoLogFunction.WriteLog("Testing: using a class called TestClass() generating an Exception ...");
                        vAutoLogFunction.WriteLog("Test Class Value: " + tc.Test(true));
                    }
                    catch { }
                    try
                    {
                        vAutoLogFunction.WriteLog("Testing: TestSuppresHeader ...");
                        TestSuppresHeader("TestSuppresHeader");
                    }
                    catch { }
                    try
                    {
                        vAutoLogFunction.WriteLog("Testing: TestAutoLog ...");
                        TestAutoLog();
                    }
                    catch { }

                    try
                    {
                        vAutoLogFunction.WriteLog("Testing: Function Parameters ...");
                        TestParameters(null, 1, "Test");
                    }
                    catch { }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        private static void TestParameters(object sender, int i, string str)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { sender, i, str }))
            {
                try
                {
                    vAutoLogFunction.WriteLog(new string('-', 80));
                    vAutoLogFunction.WriteLog("sender = " + (sender == null ? "(null)" : sender.ToString()));
                    vAutoLogFunction.WriteLog("i = " + i.ToString());
                    vAutoLogFunction.WriteLog("str = " + str);
                    vAutoLogFunction.WriteLog(new string('-', 80));
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { sender, i, str }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        private static void TestHttpRequest(HttpWebRequest _webRequest)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { _webRequest }))
            {
                try
                {
                    WebResponse webResponse = _webRequest.GetResponse(ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp);
                    vAutoLogFunction.WriteLog(new string('-', 80));
                    vAutoLogFunction.WriteLog("This is NOT Debug Code.  This is a TEST at INFO Level.");
                    vAutoLogFunction.WriteLog(new string('-', 80));
                    vAutoLogFunction.WriteLogFormat("Web Data: {0}", AdvancedLogging.Logging.ObjectDumper.Dump(webResponse));
                    vAutoLogFunction.WriteLog(new string('-', 80));
                    webResponse.Close();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { _webRequest }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        private static void TestSqlCommand(SqlCommand _sqlCommand, SqlParameter[] arrParms, bool bUseSqlHelperStatic = false, bool bThrowException = false)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { _sqlCommand, arrParms, bUseSqlHelperStatic }, null, null, false, bThrowException))
            {
                try
                {
                    if (bThrowException)
                        _sqlCommand.CommandText = "$" + _sqlCommand.CommandText;
                    if (bUseSqlHelperStatic)
                    {
                        if (_sqlCommand.Connection.State != System.Data.ConnectionState.Open)
                            _sqlCommand.Connection.Open();
                        SqlDataReader reader = SqlHelperStatic.ExecuteReader(_sqlCommand.Connection, System.Data.CommandType.Text, _sqlCommand.CommandText, arrParms);
                        if (reader != null)
                        {
                            if (!reader.IsClosed)
                            {
                                if (reader.HasRows)
                                {
                                    vAutoLogFunction.WriteLog("Data Results ...");
                                    while (reader.Read())
                                    {
                                        vAutoLogFunction.WriteLogFormat("SERVERTIME:{0}, TESTINT:{1}, TESTBIT:{2}, TESTFLOAT:{3}, TESTCHAR50:{4}",
                                            reader.GetDateTime(0),
                                            reader.GetInt64(1),
                                            reader.GetBoolean(2),
                                            reader.GetDouble(3),
                                            reader.GetString(4));
                                    }
                                    vAutoLogFunction.WriteLog("Data Results ... End!");
                                }
                                reader.Close();
                            }
                        }
                        if (_sqlCommand.Connection.State == System.Data.ConnectionState.Open)
                            _sqlCommand.Connection.Close();
                    }
                    else
                    {
                        _sqlCommand.Parameters.AddRange(arrParms);
                        if (_sqlCommand.Connection.State != System.Data.ConnectionState.Open)
                            _sqlCommand.Connection.Open();
                        SqlDataReader reader = _sqlCommand.ExecuteReader();
                        _sqlCommand.Parameters.Clear();
                        if (reader != null)
                        {
                            if (!reader.IsClosed)
                            {
                                if (reader.HasRows)
                                {
                                    vAutoLogFunction.WriteLog("Data Results ...");
                                    while (reader.Read())
                                    {
                                        vAutoLogFunction.WriteLogFormat("SERVERTIME:{0}, TESTINT:{1}, TESTBIT:{2}, TESTFLOAT:{3}, TESTCHAR50:{4}",
                                            reader.GetDateTime(0),
                                            reader.GetInt64(1),
                                            reader.GetBoolean(2),
                                            reader.GetDouble(3),
                                            reader.GetString(4));
                                    }
                                    vAutoLogFunction.WriteLog("Data Results ... End!");
                                }
                                reader.Close();
                            }
                        }
                        if (_sqlCommand.Connection.State == System.Data.ConnectionState.Open)
                            _sqlCommand.Connection.Close();
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { _sqlCommand, arrParms, bUseSqlHelperStatic }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        private static void TestDataTypes(decimal decValue, string sValue, double dValue, Int64 iValue)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { decValue, sValue, dValue, iValue }))
            {
                try
                {

                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { decValue, sValue, dValue, iValue }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        private static void TestAutoLog()
        {
            List<string> lstString = new List<string>() { "Value1", "Value2" };
            Dictionary<string, string> dicString = new Dictionary<string, string>() { { "Key", "Value" } };
            System.Collections.Concurrent.ConcurrentDictionary<string, string> dicString2 = new System.Collections.Concurrent.ConcurrentDictionary<string, string>();
            string[] arrString = { "test", "test2" };
            int[] arrInt = { 0, 3 };

            dicString2.AddOrUpdate("Key1", "Value1", (key, oldValue) => "Value1");
            dicString2.AddOrUpdate("Key1", "Value2", (key, oldValue) => "Value2");
            TestAutoLogParms(lstString, dicString, dicString2, arrString, arrInt);
        }
        private static void TestAutoLogParms(List<string> lstString, Dictionary<string, string> dicString, System.Collections.Concurrent.ConcurrentDictionary<string, string> dicString2, string[] arrString, int[] arrInt)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { lstString, dicString, dicString2, arrString, arrInt }))
            {
                try
                {
                    vAutoLogFunction.WriteDebug(3, "Test Debug Message");
                    vAutoLogFunction.WriteLog("Test Info Message");
                    arrInt[0]++;
                    if (arrInt[0] < arrInt[1])
                        TestAutoLogParms(lstString, dicString, dicString2, arrString, arrInt);
                    else
                    {
                        int y = 1;
                        int i = y / 0;
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { lstString, dicString, dicString2, arrString, arrInt }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        private static void TestSuppresHeader(string strMessage)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strMessage }, bSuppresFunctionDeclaration: false))
            {
                try
                {
                    vAutoLogFunction.WriteDebug(3, "Test Debug Message");
                    vAutoLogFunction.WriteLog("Test Info Message");
                    vAutoLogFunction.WriteLog(strMessage);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { strMessage }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        private static void LogConfigData()
        {
            Assembly TestApp = Assembly.GetEntryAssembly();
            System.Configuration.Configuration Config = null;
            if (TestApp != null)
            {
                Config = ConfigurationManager.OpenExeConfiguration(TestApp.Location);
            }
            string strLog4NetConfig = Config?.FilePath;
            FileInfo fiLog4NetConfig = new FileInfo(strLog4NetConfig);

            if (fiLog4NetConfig.Exists)
            {
                try
                {
                    XmlConfigurator.ConfigureAndWatch(fiLog4NetConfig);
                    ApplicationSettings.Logger.ConfigFile = fiLog4NetConfig.FullName;
                    ApplicationSettings.Logger.Monitoring = true;

                    string appConfigtext = AdvancedLogging.BLL.Configuration.RedactConfigFileContents(ApplicationSettings.Logger.ConfigFileXml, ApplicationSettings.Logger);

                    ApplicationSettings.Logger.Info("Base Directory: " + AppDomain.CurrentDomain.BaseDirectory);
                    ApplicationSettings.Logger.Info("Looking for configuration file at path: " + fiLog4NetConfig.FullName);
                    ApplicationSettings.Logger.InfoFormat("Configuration File Contents:\r\n{0}", appConfigtext);
                    ApplicationSettings.Logger.InfoFormat("Using Settings from {0} file: START", fiLog4NetConfig.Name);
                    if (ApplicationSettings.Logger.IsDebugEnabled)
                    {
                        ApplicationSettings.Logger.DebugFormat("ApplicationSettings.Logger: {0}", ApplicationSettings.Logger == null ? "Is Null" : "Is Set");
                        ApplicationSettings.Logger.DebugFormat("Debug Level: [*] (i.e., LogLevel) -> [{0}]", ApplicationSettings.Logger.LogLevel);
                        ApplicationSettings.Logger.DebugFormat("Monitoring: {0}", ApplicationSettings.Logger.Monitoring);
                        ApplicationSettings.Logger.DebugFormat("log4netLvl: {0}", ApplicationSettings.Logger.Level.DisplayName);
                        ApplicationSettings.Logger.Debug(new string('-', 80));
                        foreach (var vitem in ApplicationSettings.Logger.DebugLevels)
                        {
                            ApplicationSettings.Logger.DebugFormat("Debug Level: [{0}] -> [{1}]", vitem.Key, vitem.Value);
                        }
                        ApplicationSettings.Logger.Debug(new string('-', 80));
                        foreach (var vitem in LoggingUtils.DebugPrintLevel.OrderBy(x => x.Value))
                        {
                            ApplicationSettings.Logger.DebugFormat("Debug Printing Level: [{0}] -> [{1}]", vitem.Key, vitem.Value);
                        }
                        ApplicationSettings.Logger.Debug(new string('-', 80));

                        ApplicationSettings.Logger?.Debug("Written with ApplicationSettings.Logger.");
                    }
                    ApplicationSettings.Logger?.Info("Available Security Protocols ...");
                    SecurityProtocol.LogSecurityProtocol((CLog)ApplicationSettings.Logger);
                }
                catch (Exception ex)
                {
                    ApplicationSettings.Logger.ErrorFormat("Error Processing Config File {0}\n{1}", fiLog4NetConfig.FullName, ex);
                }
            }
        }
        public static Level ParseLevel(string level)
        {
            var loggerRepository = LoggerManager.GetAllRepositories().FirstOrDefault();

            if (loggerRepository == null)
            {
                throw new Exception("No logging repositories defined");
            }

            var stronglyTypedLevel = loggerRepository.LevelMap[level];

            if (stronglyTypedLevel == null)
            {
                throw new Exception("Invalid logging level specified");
            }

            return stronglyTypedLevel;
        }
        private void RequestDeliver_ConfigSettingChanged(object sender, CLogClassTypes.ConfigSettingChangedEventArgs e)
        {
            CLog logger = (CLog)sender;

            logger?.InfoFormat("Detected Setting Change: {0}: [{1}] is now [{2}].", e.SettingName, e.OldValue, e.NewValue);
        }

        private void RequestDeliver_ConfigFileChanged(object sender, CLogClassTypes.ConfigFileChangedEventArgs e)
        {
            LogConfigData();
        }
    }
    //bool TryGetDataConnectionStringFromUser(out string outConnectionString)
    //{
    //    using (var dialog = new DataConnectionDialog())
    //    {
    //        // If you want the user to select from any of the available data sources, do this:
    //        DataSource.AddStandardDataSources(dialog);

    //        // OR, if you want only certain data sources to be available
    //        // (e.g. only SQL Server), do something like this instead: 
    //        dialog.DataSources.Add(DataSource.SqlDataSource);
    //        dialog.DataSources.Add(DataSource.SqlFileDataSource);
    //    …

    //    // The way how you show the dialog is somewhat unorthodox; `dialog.ShowDialog()`
    //    // would throw a `NotSupportedException`. Do it this way instead:
    //    DialogResult userChoice = DataConnectionDialog.Show(dialog);

    //        // Return the resulting connection string if a connection was selected:
    //        if (userChoice == DialogResult.OK)
    //        {
    //            outConnectionString = dialog.ConnectionString;
    //            return true;
    //        }
    //        else
    //        {
    //            outConnectionString = null;
    //            return false;
    //        }
    //    }
    //}
}
