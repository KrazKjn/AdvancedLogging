﻿using AdvancedLogging.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelperLibrary.TestConsoleApp
{
    class TestClass
    {
        private int myIntVar;

        public int MyIntProperty
        {
            get { return myIntVar; }
            set { myIntVar = value; }
        }

        public TestClass()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    MyIntProperty = 10;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public string Test(bool bThrowException = false)
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    if (bThrowException)
                        throw new Exception("Test Exception!");
                    return MyIntProperty.ToString();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    if (bThrowException)
                        return "Test Exception!";
                    else
                        throw;
                }
            }
        }
    }
}
