using System;
using System.Configuration;
using System.Reflection;
using System.ServiceProcess;
using AdvancedLogging.BE.SystemStatusV1;
using AdvancedLogging.Logging;
using AdvancedLogging.Utils;

namespace AdvancedLogging.BLL.Services
{
    public class WinServiceBase : ServiceBase
    {
        public ISystemStatus SystemStatus { get; set; }
        public ICLog Log { get; set; }
        public string[] ConnectionStrings { get; set; }
        // Mark Hogan
        // Leave following code for possible future implementation where we add
        // automatic Loading of SQL Connections from the Config Files.  We can
        // use the "connectionStrings" section to store multiple named connections.
        // Look at SqlConnectionStringBuilder.ApplicationName as a possible Key for
        // the "Named" connection.
        // <configuration>
        //   <connectionStrings>
        //     <add name = "DBConnectionString" connectionString="Data Source=somehost;Initial Catalog=someschema;Persist Security Info=True; Connect Timeout=200; User ID=someuser;Password=therePassword;" providerName="System.Data.SqlClient" />
        //   </connectionStrings>
        //   ...
        // public SqlConnectionStringBuilder[] DatabaseConnections { get; set; }
        public DatabaseInfo.DatabaseTypeClass[] DatabaseTypes { get; set; }

        private ILoggerUtility m_loggerUtility;

        public ILoggerUtility LoggerUtility
        {
            get
            {
                if (m_loggerUtility == null)
                {
                    m_loggerUtility = new LoggerUtility();
                }
                return m_loggerUtility;
            }
            set
            {
                if (m_loggerUtility != null)
                {
                    if (m_loggerUtility.MyLogger != null)
                    {
                        m_loggerUtility.MyLogger.Info("Resetting Existing Logger");
                    }
                    m_loggerUtility = null;
                }
                m_loggerUtility = value;

                if (m_loggerUtility.MyLogger != null)
                {
                    m_loggerUtility.MyLogger.Info("Logger Assigned by Code");
                }
            }
        }

        public Assembly Service { get; set; }

        public System.Configuration.Configuration Config { get; set; }

        public WinServiceBase()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    Log = null;
                    PreInitialize();
                    Initialize();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public WinServiceBase(ISystemStatus systemStatus, ICLog log, string[] connectionStrings, DatabaseInfo.DatabaseTypeClass[] databaseTypes)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { systemStatus, log, connectionStrings, databaseTypes }))
            {
                try
                {
                    Log = log;
                    PreInitialize();
                    SystemStatus = systemStatus;
                    ConnectionStrings = connectionStrings;
                    DatabaseTypes = databaseTypes;
                    Initialize();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { systemStatus, log, connectionStrings, databaseTypes }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public WinServiceBase(ISystemStatus systemStatus, ICLog log, ILoggerUtility loggerUtility, string[] connectionStrings, DatabaseInfo.DatabaseTypeClass[] databaseTypes)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { systemStatus, log, loggerUtility, connectionStrings, databaseTypes }))
            {
                try
                {
                    Log = log;
                    PreInitialize();
                    SystemStatus = systemStatus;
                    LoggerUtility = loggerUtility;
                    ConnectionStrings = connectionStrings;
                    DatabaseTypes = databaseTypes;
                    Initialize();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { systemStatus, log, loggerUtility, connectionStrings, databaseTypes }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public void OnCustomCommandTestable(int command)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { command }))
            {
                try
                {
                    OnCustomCommand(command);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { command }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        protected override void OnCustomCommand(int command)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { command }))
            {
                try
                {
                    if (string.IsNullOrEmpty(SystemStatus.ServiceName) || string.IsNullOrEmpty(SystemStatus.ClientName))
                    {
                        if (string.IsNullOrEmpty(SystemStatus.ServiceName))
                        {
                            vAutoLogFunction.WriteError("No Active Service!");
                        }
                        if (string.IsNullOrEmpty(SystemStatus.ClientName))
                        {
                            vAutoLogFunction.WriteError("No Active Client!");
                        }
                    }
                    else
                    {
                        vAutoLogFunction.WriteLogFormat(Constants.SystemStatus.LogFormat.General, "Processing Custom Command: " + SystemStatus.ClientName + " - " + SystemStatus.ServiceName);
                        SystemStatus.ProcessCustomServiceCommand(command, ConnectionStrings, DatabaseTypes);

                    }
                }
                catch (Exception ex)
                {
                    vAutoLogFunction.WriteErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                }
            }
        }

        private void PreInitialize()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    SecurityProtocol.AvailableSecurityProtocols = SecurityProtocol.SecurityProtocolTypeCustom.SystemDefault;
                    SecurityProtocol.EnableAllTlsSupport();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        private void Initialize()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    Service = Assembly.GetEntryAssembly();
                    if (Service != null)
                    {
                        Config = ConfigurationManager.OpenExeConfiguration(Service.Location);
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        /// <summary>
        /// Must be called by the individual services,
        /// </summary>
        public bool InitializeAutoLoggingCleanUp(bool bCleanLogs = true)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { bCleanLogs }))
            {
                try
                {
                    //CleanUp Logs based on config settings
                    try
                    {
                        m_loggerUtility = new LoggerUtility(Log, new DirectoryManager())
                        {
                            MinutesAfterMidnight = AdvancedLogging.BLL.Configuration.GetConfigurationIntValue(Config, Log, "MinutesAfterMidnight", 120),
                            DaysInterval = AdvancedLogging.BLL.Configuration.GetConfigurationIntValue(Config, Log, "DaysInterval", 1),
                            AutoCleanUpLogFiles = bool.Parse(AdvancedLogging.BLL.Configuration.GetConfigurationStringValue(Config, Log, "AutoCleanUpLogFiles", "true"))
                        };

                        if (bCleanLogs)
                        {
                            m_loggerUtility.CleanUp();
                        }
                        return m_loggerUtility.AutoCleanUpLogFiles;
                    }
                    catch (Exception ex)
                    {
                        Log?.ErrorFormat("Invalid parameter: " + ex.Message);
                    }
                    return false;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { bCleanLogs }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
    }
}
