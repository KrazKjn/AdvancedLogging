using System;
using System.IO;
using System.Linq;
using System.Xml;
using AdvancedLogging.Logging;
using AdvancedLogging.Utils;

namespace AdvancedLogging.BLL.Services
{
    public class WebServiceBase : System.Web.HttpApplication
    {
        public bool m_bLogSoapBody = false;

        public bool LogSoapBody
        {
            get { return m_bLogSoapBody; }
            set { m_bLogSoapBody = value; }
        }

        public WebServiceBase()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    SecurityProtocol.AvailableSecurityProtocols = SecurityProtocol.SecurityProtocolTypeCustom.SystemDefault;
                    SecurityProtocol.EnableAllTlsSupport();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        public void Application_BeginRequest(Object Sender, EventArgs e)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { Sender, e }))
            {
                try
                {
                    SecurityProtocol.EnableAllTlsSupport();
                    if (Request.ServerVariables.AllKeys.Contains("HTTP_SOAPACTION"))
                    {
                        //Only SOAP action will be logged.
                        if (Request.ServerVariables["HTTP_SOAPACTION"].Length > 0)
                        {
                            string strSOAP = Request.ServerVariables["HTTP_SOAPACTION"];
                            strSOAP = strSOAP.Substring(1, strSOAP.Length - 2);
                            Uri uriSOAP = new Uri(strSOAP);
                            string strFunction = Uri.UnescapeDataString(uriSOAP.Segments.Last());
                            string strLog = "function=" + strFunction;

                            if (LogSoapBody)
                            {
                                try
                                {
                                    if (ResolveSoapMessage(Request, out string strSOAPBody))
                                    {
                                        strLog += "?" + strSOAPBody;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    vAutoLogFunction.WriteError("Error Getting SopaBody via ResolveSoapMessage.", ex);
                                }
                            }
                            int QueryStringLength = 0;
                            if (Request.QueryString.Count > 0)
                            {
                                QueryStringLength = Request.ServerVariables["QUERY_STRING"].Length;
                                Response.AppendToLog("&");
                            }
                            if ((QueryStringLength + strLog.Length) < 4100)
                            {
                                Response.AppendToLog(strLog);
                            }
                            else
                            {
                                // append only the first 4090 the limit is a total of 4100 char.
                                Response.AppendToLog(strLog.Substring(0, (4090 - QueryStringLength)));
                                // indicate buffer exceeded.  9 chars so we are still under 4100 char limit
                                Response.AppendToLog("|||...|||");
                            }

                        }
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { Sender, e }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        internal static bool ResolveSoapMessage(System.Web.HttpRequest httpRequest, out string strSOAPBody)
        {
            strSOAPBody = "";

            Stream HttpStream = httpRequest.InputStream;

            // Save the current position of stream.
            long posStream = HttpStream.Position;

            // If the request contains an HTTP_SOAPACTION
            // header, look at this message.
            if (httpRequest.ServerVariables["HTTP_SOAPACTION"] == null)
                return false;

            // Load the body of the HTTP message
            // into an XML document.
            XmlDocument dom = new XmlDocument();
            try
            {
                dom.Load(HttpStream);
                // Reset the stream position.
                HttpStream.Position = posStream;

                // Bind to the Authentication header.
                XmlNode soapBody = dom.DocumentElement.GetElementsByTagName("soap:Body")[0];
                if (soapBody == null)
                {
                    soapBody = dom.DocumentElement.GetElementsByTagName("soapenv:Body")[0];
                }
                if (soapBody == null)
                {
                    soapBody = dom.DocumentElement.GetElementsByTagName("s:Body")[0];
                }
                if (soapBody != null)
                {
                    strSOAPBody = soapBody.InnerXml;
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                // Reset the position of stream.
                HttpStream.Position = posStream;

                throw e;
            }
        }
    }
}
