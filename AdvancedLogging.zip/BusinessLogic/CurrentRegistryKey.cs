using Microsoft.Win32;
using System.Security.AccessControl;
using System;
using AdvancedLogging.Logging;

namespace AdvancedLogging.BLL
{
    public class CurrentRegistryKey : IRegistryKey
    {
        private RegistryKey _registryKey;

        public CurrentRegistryKey() { }

        public CurrentRegistryKey(RegistryKey registryKey)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { registryKey }))
            {
                try
                {
                    _registryKey = registryKey;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { registryKey }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public IRegistryKey CreateSubKey(string name, RegistryKeyPermissionCheck permissionCheck)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { name, permissionCheck }))
            {
                try
                {
                    var registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).CreateSubKey(name, permissionCheck);
                    return new CurrentRegistryKey(registryKey);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { name, permissionCheck }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public IRegistryKey CreateSubKey(string name, RegistryKeyPermissionCheck permissionCheck, RegistrySecurity registrySecurity)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { name, permissionCheck, registrySecurity }))
            {
                try
                {
                    var registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).CreateSubKey(name, permissionCheck, registrySecurity);
                    return new CurrentRegistryKey(registryKey);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { name, permissionCheck, registrySecurity }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public IRegistryKey OpenSubKey(string name, RegistryKeyPermissionCheck permissionCheck)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { name, permissionCheck }))
            {
                try
                {
                    var tempRegistryKey = Registry.LocalMachine.OpenSubKey(name, permissionCheck);
                    CurrentRegistryKey currentRegistryKey = new CurrentRegistryKey(tempRegistryKey);
                    return currentRegistryKey;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { name, permissionCheck }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public void SetValue(string name, string value)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { name, value }))
            {
                try
                {
                    _registryKey.SetValue(name, value);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { name, value }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public void SetValue(string name, double value)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { name, value }))
            {
                try
                {
                    _registryKey.SetValue(name, value);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { name, value }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public void SetValue(string name, double value, RegistryValueKind registryValueKind)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { name, value, registryValueKind }))
            {
                try
                {
                    _registryKey.SetValue(name, value, registryValueKind);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { name, value, registryValueKind }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public string GetValue(string name, string value)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { name, value }))
            {
                try
                {
                    return (string)_registryKey.GetValue(name, value);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { name, value }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public double GetValue(string name, double value)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { name, value }))
            {
                try
                {
                    double DoubleValue = value;
                    var ObjectValue = _registryKey.GetValue(name, value);

                    if (ObjectValue is Int32)
                    {
                        DoubleValue = Convert.ToDouble(ObjectValue);
                    }
                    else if (ObjectValue is string)
                    {
                        if (!Double.TryParse((string)ObjectValue, out DoubleValue))
                        {
                            DoubleValue = value;
                        }
                    }
                    return DoubleValue;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { name, value }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public void DeleteValue(string name, bool throwOnMissingValue)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { name, throwOnMissingValue }))
            {
                try
                {
                    _registryKey.DeleteValue(name, throwOnMissingValue);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { name, throwOnMissingValue }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public RegistrySecurity GetAccessControl()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    return _registryKey.GetAccessControl();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public void Close()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    if (_registryKey != null)
                    {
                        _registryKey.Close();
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
    }
}