using AdvancedLogging.BE;
using AdvancedLogging.BLL.Interfaces;
using AdvancedLogging.Logging;
using System;
using System.Diagnostics;
using System.Text;

namespace AdvancedLogging.BLL
{
    public class SecurityHelper : ISecurityHelper
    {
        private readonly string userName;
        private ISecurityHelperDataAccess dal;
        private SecurityHelperInfo securityInfo;

        public SecurityHelper(string user, ISecurityHelperDataAccess dalInterface)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { user, dalInterface }))
            {
                try
                {
                    userName = user;
                    dal = dalInterface;
                    securityInfo = dal.GetSecurityInfo(user);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { user, dalInterface }, null, true, ExOuter);
                    throw;
                }
            }
        }

        public SecurityHelper(Int64 secPrimaryId, ISecurityHelperDataAccess dalInterface)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { secPrimaryId, dalInterface }))
            {
                try
                {
                    dal = dalInterface;
                    securityInfo = dal.GetSecurityInfo(secPrimaryId);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { secPrimaryId, dalInterface }, null, true, ExOuter);
                    throw;
                }
            }
        }

        private string EncryptToUnsecure(string newPassword)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { newPassword }))
            {
                try
                {
                    string resultHash = String.Empty;

                    string strPasswd = newPassword.PadRight(32, ' ');
                    char[] HexChars = { '€', '', '‚', 'ƒ', '„', '…', '†', '‡' };//{w,x,y,z,{,|,}, ~ }

                    int intIndex = 0;
                    while (intIndex < strPasswd.Length)
                    {
                        if (strPasswd.Substring(intIndex, 1) == " ")
                        {
                            resultHash += ' ';
                        }
                        else
                        {
                            //convert each letter in byte array
                            Byte[] tempBytes = Encoding.ASCII.GetBytes(strPasswd.Substring(intIndex, 1));
                            tempBytes = new Byte[] { Convert.ToByte((Convert.ToInt32(tempBytes[0]) + 9)) };

                            // Check for "rollover"
                            if (tempBytes[0] > 127)
                            {
                                int ArrVal = tempBytes[0] - 128;
                                resultHash += HexChars[ArrVal];
                            }
                            else
                            {
                                resultHash += Encoding.ASCII.GetString(tempBytes);
                            }
                        }
                        intIndex = intIndex + 1;
                    }

                    return resultHash;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { newPassword }, null, true, ExOuter);
                    throw;
                }
            }
        }

        private string EncryptToSHA256(string newPassword)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { newPassword }))
            {
                try
                {
                    string strPasswd = securityInfo.PrimaryKeyStr + newPassword;
                    System.Security.Cryptography.SHA256Managed hashClass = new System.Security.Cryptography.SHA256Managed();
                    byte[] bytePassword = hashClass.ComputeHash(System.Text.Encoding.UTF8.GetBytes(strPasswd));
                    string resultHash = String.Empty;

                    try
                    {
                        foreach (byte tempByte in bytePassword)
                        {
                            resultHash += Convert.ToChar(tempByte);
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(ex.Message.ToString());
                    }

                    return resultHash;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { newPassword }, null, true, ExOuter);
                    throw;
                }
            }
        }

        private string EncryptToSHA512(string newPassword)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { newPassword }))
            {
                try
                {
                    string strPasswd = securityInfo.PrimaryKeyStr + newPassword;
                    System.Security.Cryptography.SHA512Managed hashClass = new System.Security.Cryptography.SHA512Managed();
                    byte[] bytePassword = hashClass.ComputeHash(System.Text.Encoding.UTF8.GetBytes(strPasswd));
                    string resultHash = String.Empty;

                    try
                    {
                        foreach (byte tempByte in bytePassword)
                        {
                            resultHash += Convert.ToChar(tempByte);
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(ex.Message.ToString());
                    }

                    return resultHash;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { newPassword }, null, true, ExOuter);
                    throw;
                }
            }
        }

        private string PlainTextToHashed(string plainTextPassword, HashType hashToUse)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { plainTextPassword, hashToUse }))
            {
                try
                {
                    string hashedPassword = String.Empty;

                    switch (hashToUse)
                    {
                        case HashType.Unsecured:
                            hashedPassword = EncryptToUnsecure(plainTextPassword);
                            break;
                        case HashType.SHA2_256:
                            hashedPassword = EncryptToSHA256(plainTextPassword);
                            break;
                        case HashType.SHA2_512:
                            hashedPassword = EncryptToSHA512(plainTextPassword);
                            break;
                        default:
                            break;
                    }

                    return hashedPassword;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { plainTextPassword, hashToUse }, null, true, ExOuter);
                    throw;
                }
            }
        }

        public void SavePassword(string plainTextPassword)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { plainTextPassword }))
            {
                try
                {
                    string encryptedPassword = PlainTextToHashed(plainTextPassword, securityInfo.TargetHash);
                    securityInfo = dal.SetSecurityInfo(securityInfo, encryptedPassword);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { plainTextPassword }, null, true, ExOuter);
                    throw;
                }
            }
        }

        public bool IsPasswordCorrect(string plainTextPassword)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { plainTextPassword }))
            {
                try
                {
                    bool result = false;
                    string encryptedPassword = PlainTextToHashed(plainTextPassword, securityInfo.CurrentHash).PadRight(65, ' ');
                    string currentEncryptedPassword = securityInfo.EncryptedPassword.PadRight(65, ' ');

                    vAutoLogFunction.WriteDebug(2, string.Format("Password Check: plain = '{0}', new encrypt '{1}', from db '{2}'. ", plainTextPassword, encryptedPassword, currentEncryptedPassword));

                    if (encryptedPassword == currentEncryptedPassword)
                    {
                        result = true;
                        if (securityInfo.TargetHash != securityInfo.CurrentHash)
                        {
                            SavePassword(plainTextPassword);
                        }
                    }
                    return result;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { plainTextPassword }, null, true, ExOuter);
                    throw;
                }
            }
        }
    }
}
