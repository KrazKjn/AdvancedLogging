﻿namespace AdvancedLogging.BLL.Interfaces
{
    public interface ISecurityHelper
    {
        void SavePassword(string plainTextPassword);

        bool IsPasswordCorrect(string plainTextPassword);
    }
}
