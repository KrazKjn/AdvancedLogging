﻿using System;

namespace AdvancedLogging.BLL.Interfaces
{
    public interface ISecurityHelperFactory
    {
        ISecurityHelper CreateSecurityHelper(string userName);

        ISecurityHelper CreateSecurityHelper(Int64 secPrimaryId);
    }
}
