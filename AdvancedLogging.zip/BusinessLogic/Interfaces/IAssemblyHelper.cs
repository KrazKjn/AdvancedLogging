﻿namespace AdvancedLogging.BLL
{
    using System.Reflection;

    public interface IAssemblyHelper
    {
        string GetFormattedVersion(Assembly assembly);
    }
}
