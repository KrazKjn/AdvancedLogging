﻿namespace AdvancedLogging.BLL
{
    using System.Data.SqlClient;
    using System.Reflection;
    using AdvancedLogging.BE;

    public interface IVersionInfoManager
    {
        VersionDetails GetVersionDetails(Assembly assembly, SqlConnectionStringBuilder ConnectionString);
        VersionDetails GetVersionDetails(Assembly assembly, string dbConnectionString);
        VersionDetails GetVersionDetails(Assembly assembly);
    }
}
