﻿using System;
using AdvancedLogging.BE;

namespace AdvancedLogging.BLL.Interfaces
{
    public interface ISecurityHelperDataAccess
    {
        SecurityHelperInfo GetSecurityInfo(string userName);

        SecurityHelperInfo GetSecurityInfo(Int64 secPrimaryId);

        SecurityHelperInfo SetSecurityInfo(SecurityHelperInfo securityInfo, string newEncryptedPassword);
    }
}
