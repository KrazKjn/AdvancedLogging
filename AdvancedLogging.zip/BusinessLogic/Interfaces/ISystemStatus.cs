﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.ServiceProcess;
using AdvancedLogging.BE.SystemStatusV1;
using System.Linq.Expressions;
using AdvancedLogging.BLL.Interfaces;
using Microsoft.Win32;

namespace AdvancedLogging.BLL
{
    public interface ISystemStatus
    {
        string ServiceName { get; set; }
        string ClientName { get; set; }
        string GetTenantName();
        ServiceController GetMyServiceController();
        string GetMyServiceName();
        string GetClientName();
        bool GetDatabaseInfo(string ServiceName, string ClientName, Assembly ServiceAssembly, string ConnectionString, DatabaseInfo.DatabaseStateClass DatabaseState, out DatabaseInfo OutDatabase);
        bool ProcessCustomServiceCommand(int command, string[] SqlConnections, DatabaseInfo.DatabaseTypeClass[] SqlDatabaseTypes, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off);
        bool InitializeRegistryConstants(Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off);
        bool GetRegistryConstants(out double dblMinRefreshTime, out double dblTimeout, out bool bForce, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off);
        bool CanSendRequest(string strServiceName, string strClientName, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off);
        bool CanWrite(string strServiceName, string strClientName, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off);
        bool SendRequest(ICurrentServiceController scThis, string strClientName, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off);
        bool SetStatus(string strServiceName, string strClientName, List<DatabaseInfo> clientDBs, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off);
        bool ClearStatus(string strServiceName, string strClientName, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off);
        bool GetStatus(string strServiceName, string strClientName, out string strDatabase, out string strConnectionString, out string strVersionInfoDB, out string strStatus, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off);
        bool GetStatus(string strServiceName, string strClientName, out List<DatabaseInfo> dbiDatabases, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off);
        bool VerifyRegistryAccess(Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off);
        int CompareVersion(string Version1, string Version2);
        string MaskConnectionString(string strConnectionString);
    }
}