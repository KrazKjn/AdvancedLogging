﻿using System.ServiceProcess;

namespace AdvancedLogging.BLL.Interfaces
{
    public interface ICurrentServiceController
    {
        string ServiceName { get; set; }
        string DisplayName { get; set; }
        ServiceStartMode StartType { get; set; }
        ServiceControllerStatus Status { get; set; }
        string ExecutableName { get; set; }
        string LogOnAccount { get; set; }
        ICurrentServiceController[] GetCurrentServices();
        void ExecuteCommand(int command);
    }
}
