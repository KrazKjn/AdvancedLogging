﻿using Microsoft.Win32;
using System.Security.AccessControl;

namespace AdvancedLogging.BLL
{
    public interface IRegistryKey
    {
        IRegistryKey CreateSubKey(string name, RegistryKeyPermissionCheck permissionCheck);
        IRegistryKey CreateSubKey(string name, RegistryKeyPermissionCheck permissionCheck, RegistrySecurity registrySecurity);
        IRegistryKey OpenSubKey(string name, RegistryKeyPermissionCheck permissionCheck);
        void SetValue(string name, string value);
        void SetValue(string name, double value);
        void SetValue(string name, double value, RegistryValueKind registryValueKind);
        string GetValue(string name, string value);
        double GetValue(string name, double value);
        void DeleteValue(string name, bool throwOnMissingValue);
        RegistrySecurity GetAccessControl();
        void Close();
    }
}