using System;
using System.Reflection;
using AdvancedLogging.Logging;

namespace AdvancedLogging.BLL
{
    public class AssemblyHelper : IAssemblyHelper
    {
        public string GetFormattedVersion(Assembly assembly)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { assembly }))
            {
                try
                {
                    var versionInfo = assembly.GetName().Version;
                    return $"{versionInfo.Major}.{versionInfo.Minor}.{versionInfo.Build}";
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { assembly }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
    }
}
