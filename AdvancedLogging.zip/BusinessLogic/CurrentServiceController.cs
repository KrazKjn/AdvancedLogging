using System.ServiceProcess;
using System.Collections.Generic;
using AdvancedLogging.BLL.Interfaces;
using System.Diagnostics;
using Microsoft.Win32;
using AdvancedLogging.Logging;
using System;

namespace AdvancedLogging.BLL
{
    public class CurrentServiceController : ICurrentServiceController
    {
        private readonly ServiceController _serviceController;

        public CurrentServiceController() { }

        public CurrentServiceController(ServiceController serviceController)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { serviceController }))
            {
                try
                {
                    _serviceController = serviceController;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { serviceController }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public string ServiceName { get { return _serviceController.ServiceName; } set { } }
        public string DisplayName { get { return _serviceController.DisplayName; } set { } }

        public ServiceStartMode StartType
        {
            get
            {
                ServiceStartMode iStartMode = 0;
                try
                {
                    RegistryKey rkService = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Default);
                    var openedKey = rkService.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + ServiceName, RegistryKeyPermissionCheck.ReadSubTree);
                    iStartMode = (ServiceStartMode)openedKey.GetValue("Start", 0);
                    openedKey.Close();
                }
                catch (System.Exception ex)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(ex.Message);
                    throw;
                }
                return iStartMode;
            }
            set
            {
                try
                {
                    RegistryKey rkService = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Default);
                    var openedKey = rkService.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + ServiceName, RegistryKeyPermissionCheck.ReadSubTree);
                    openedKey.SetValue("Start", value, RegistryValueKind.DWord);
                    openedKey.Close();
                }
                catch (System.Exception ex)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(ex.Message);
                    throw;
                }
            }
        }
        public ServiceControllerStatus Status { get { return _serviceController.Status; } set { } }

        public string ExecutableName
        {
            get
            {
                string strImagePath = "";
                try
                {
                    RegistryKey rkService = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Default);
                    var openedKey = rkService.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + ServiceName, RegistryKeyPermissionCheck.ReadSubTree);
                    strImagePath = (string)openedKey.GetValue("ImagePath", "");
                    openedKey.Close();
                }
                catch (System.Exception ex)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(ex.Message);
                    throw;
                }
                return strImagePath;
            }
            set
            {
                try
                {
                    RegistryKey rkService = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Default);
                    var openedKey = rkService.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + ServiceName, RegistryKeyPermissionCheck.ReadSubTree);
                    openedKey.SetValue("ImagePath", value);
                    openedKey.Close();
                }
                catch (System.Exception ex)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(ex.Message);
                    throw;
                }
            }
        }
        public string LogOnAccount
        {
            get
            {
                string strLogOnAccount = "";
                try
                {
                    RegistryKey rkService = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Default);
                    var openedKey = rkService.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + ServiceName, RegistryKeyPermissionCheck.ReadSubTree);
                    strLogOnAccount = (string)openedKey.GetValue("ObjectName", "");
                    openedKey.Close();
                }
                catch (System.Exception ex)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(ex.Message);
                    throw;
                }
                return strLogOnAccount;
            }
            set
            {
                try
                {
                    RegistryKey rkService = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Default);
                    var openedKey = rkService.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + ServiceName, RegistryKeyPermissionCheck.ReadSubTree);
                    openedKey.SetValue("ObjectName", value);
                    openedKey.Close();
                }
                catch (System.Exception ex)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(ex.Message);
                    throw;
                }
            }
        }
        public ICurrentServiceController[] GetCurrentServices()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    List<ICurrentServiceController> serviceControllers = new List<ICurrentServiceController>();
                    foreach (var currentController in ServiceController.GetServices())
                    {
                        serviceControllers.Add(new CurrentServiceController(currentController));
                    }
                    return serviceControllers.ToArray();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public void ExecuteCommand(int command)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { command }))
            {
                try
                {
                    _serviceController.ExecuteCommand(command);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { command }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
    }

}