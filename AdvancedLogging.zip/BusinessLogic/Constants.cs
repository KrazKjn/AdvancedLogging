﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AdvancedLogging.BLL
{
    public class Constants
    {
        public class SystemStatus
        {
            public const int DUMP_SVC_INFO = 128; // RESERVED 0-127; MAX is 255
            public const string REG_LOCATION = "SOFTWARE\\Company\\Product\\Services";
            public const string DateFormat = "MM-dd-yyyy HH:mm:ss.fff";
            public const bool DefaultForce = false;
            public struct LogFormat
            {
                public const string General = "{0}";
                public const string Version = "VersionDetails/StandardVersion => SW_Version:{0}, DB_Version:{1}";
                public const string Database = "Database Name:{0}, Type:{1}, State:{2}, Version:{3}";
                public const string Error = "{0}\n{1}";
                public const string VersionError = "VersionDetails/StandardVersion => {0}\n{1}";
            }
            public struct RegistryName
            {
                public const string MinRefreshTime = "MinRefreshTime";
                public const string Timeout = "Timeout";
                public const string Force = "ForceRefresh";
            }
            public struct DefaultTime
            {
                public const double MinRefreshTime = 120; //seconds
                public const double MaxRefreshTime = 600; //seconds
                public const double MinTimeout = 15; //seconds
                public const double MaxTimeout = 30; //seconds
            }
            public enum CodeTest
            {
                Off,
                BypassReturnTrue,
                BypassReturnFalse,
                InnerReturnTrue,
                InnerReturnFalse
            }
        }
    }
}