using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Security.AccessControl;
using log4net;
using AdvancedLogging.BE.SystemStatusV1;
using AdvancedLogging.BLL.Interfaces;
using Microsoft.Win32;
using System.Data.SqlClient;
using AdvancedLogging.Logging;

namespace AdvancedLogging.BLL
{
    public class SystemStatus : ISystemStatus
    {
        private ICLog _logger;
        private readonly IVersionInfoManager _versionManager;
        private readonly IRegistryKey _currentRegistryKey;
        private string _serviceName = "";
        private string _clientName = "";

        public string ServiceName
        {
            get
            {
                if (string.IsNullOrEmpty(_serviceName))
                    _serviceName = GetMyServiceName();
                return _serviceName;
            }
            set
            {
                _serviceName = value;
            }
        }

        public string ClientName
        {
            get
            {
                if (string.IsNullOrEmpty(_clientName))
                    _clientName = GetClientName();
                return _clientName;
            }
            set
            {
                _clientName = value;
            }
        }

        public SystemStatus()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    _logger = new CLog(typeof(SystemStatus));
                    _versionManager = new VersionInfoManager();
                    _currentRegistryKey = new CurrentRegistryKey();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public SystemStatus(ICLog log)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { log }))
            {
                try
                {
                    _logger = log;
                    _versionManager = new VersionInfoManager();
                    _currentRegistryKey = new CurrentRegistryKey();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { log }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public SystemStatus(ICLog log, IVersionInfoManager versionManager, IRegistryKey currentRegistryKey)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { log, versionManager, currentRegistryKey }))
            {
                try
                {
                    _logger = log;
                    _versionManager = versionManager;
                    _currentRegistryKey = currentRegistryKey;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { log, versionManager, currentRegistryKey }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public string GetTenantName()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    // D:\Services\ParLevelAgent\5.13.4-develop\TenantName\<Name>.exe

                    Assembly service = Assembly.GetExecutingAssembly();
                    FileInfo fi = new FileInfo(service.FullName);
                    return fi.Directory.Name;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public ServiceController GetMyServiceController()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    ServiceController sc = null;
                    ServiceController[] scServices;
                    scServices = ServiceController.GetServices();
                    FileInfo fiService = new FileInfo(System.Reflection.Assembly.GetEntryAssembly().Location);

                    foreach (ServiceController svc in scServices)
                    {
                        string strImagePath = "";
                        try
                        {
                            var regService = _currentRegistryKey.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + svc.ServiceName, RegistryKeyPermissionCheck.ReadSubTree);
                            strImagePath = regService.GetValue("ImagePath", "");
                            regService.Close();
                            string thisImagePath = strImagePath.Replace("\"", "").ToLower();
                            string thisServicePath = fiService.FullName.ToLower();
                            if (thisImagePath.Contains(thisServicePath))
                            {
                                sc = svc;
                                break;
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                        }
                    }

                    return sc;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public string GetMyServiceName()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    ServiceController sc = null;
                    ServiceController[] scServices;
                    scServices = ServiceController.GetServices();
                    FileInfo fiService = new FileInfo(System.Reflection.Assembly.GetEntryAssembly().Location);

                    foreach (ServiceController svc in scServices)
                    {
                        string strImagePath = "";
                        try
                        {
                            var regService = _currentRegistryKey.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + svc.ServiceName, RegistryKeyPermissionCheck.ReadSubTree);
                            strImagePath = regService.GetValue("ImagePath", "");
                            regService.Close();
                            string thisImagePath = strImagePath.Replace("\"", "").ToLower();
                            string thisServicePath = fiService.FullName.ToLower();
                            if (thisImagePath.Contains(thisServicePath))
                            {
                                sc = svc;
                                break;
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                        }
                    }

                    return sc.ServiceName;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public string GetClientName()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    string clientName = "";
                    try
                    {
                        FileInfo fiService = new FileInfo(System.Reflection.Assembly.GetEntryAssembly().Location);
                        string exeFolder = fiService.DirectoryName;
                        string[] strSplit = exeFolder.Split('\\');
                        clientName = strSplit[strSplit.Length - 1];
                    }
                    catch (Exception ex)
                    {
                        _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                    }

                    return clientName;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public bool GetDatabaseInfo(string ServiceName, string ClientName, Assembly ServiceAssembly, string ConnectionString, DatabaseInfo.DatabaseStateClass DatabaseState, out DatabaseInfo OutDatabase)
        {
            return GetDatabaseInfo(ServiceName, ClientName, ServiceAssembly, new SqlConnectionStringBuilder(ConnectionString), DatabaseState, out OutDatabase);
        }
        public bool GetDatabaseInfo(string ServiceName, string ClientName, Assembly ServiceAssembly, SqlConnectionStringBuilder ConnectionString, DatabaseInfo.DatabaseStateClass DatabaseState, out DatabaseInfo OutDatabase)
        {
            bool bRC = false;
            OutDatabase = new DatabaseInfo();

            try
            {
                _logger?.InfoFormat(Constants.SystemStatus.LogFormat.General, "Get Database Info: " + ClientName + " - " + ServiceName);
                _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "Connection String read: " + ConnectionString.ConnectionString);
                _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "Database State read: " + DatabaseState);
                OutDatabase.DatabaseState = DatabaseState;
                OutDatabase.VersionInfo = "";


                if (ConnectionString.InitialCatalog.Length > 0)
                {
                    OutDatabase.Name = ConnectionString.InitialCatalog;
                    if (OutDatabase.Name.ToLower().Contains("application01"))
                    {
                        OutDatabase.DatabaseType = DatabaseInfo.DatabaseTypeClass.Application01;
                    }
                    else if (OutDatabase.Name.ToLower().Contains("application02"))
                    {
                        OutDatabase.DatabaseType = DatabaseInfo.DatabaseTypeClass.Application02;
                    }
                }

                var result = _versionManager.GetVersionDetails(ServiceAssembly, ConnectionString.ConnectionString);
                OutDatabase.VersionInfo = result.Database.Replace(" ", "");
                OutDatabase.ConnectionString = MaskConnectionString(ConnectionString.ConnectionString);
                _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "Database.Name: " + OutDatabase.Name);
                _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "Database.DatabaseType: " + OutDatabase.DatabaseType.ToString());
                _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "Database.ConnectionString: " + OutDatabase.ConnectionString);
                _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "Database.VersionInfo: " + OutDatabase.VersionInfo.ToString());
                _logger?.DebugFormat(Constants.SystemStatus.LogFormat.Version, result.Software, result.Database);
                _logger?.InfoFormat(Constants.SystemStatus.LogFormat.Database, OutDatabase.Name, OutDatabase.DatabaseType, OutDatabase.DatabaseState, OutDatabase.VersionInfo);

                bRC = true;
            }
            catch (Exception ex)
            {
                _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
            }

            return bRC;
        }

        public bool ProcessCustomServiceCommand(int command, string[] SqlConnections, DatabaseInfo.DatabaseTypeClass[] SqlDatabaseTypes, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { command, SqlConnections, SqlDatabaseTypes, CodeTest }))
            {
                try
                {
                    if (CodeTest != Constants.SystemStatus.CodeTest.BypassReturnFalse && CodeTest != Constants.SystemStatus.CodeTest.BypassReturnTrue)
                    {

                        Constants.SystemStatus.CodeTest InnerCodeTest = CodeTest;
                        if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnTrue)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnTrue;
                        }
                        else if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnFalse)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnFalse;
                        }
                        bool bRC = false;
                        try
                        {
                            if (command == Constants.SystemStatus.DUMP_SVC_INFO)
                            {
                                var regService = _currentRegistryKey.CreateSubKey(Constants.SystemStatus.REG_LOCATION + "\\" + ClientName + "\\" + ServiceName, RegistryKeyPermissionCheck.ReadWriteSubTree);
                                regService.SetValue("LastRequestReceived", DateTime.Now.ToString(Constants.SystemStatus.DateFormat));
                                _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "Request time stamp written to registry.");
                                if (SqlConnections.Length == SqlDatabaseTypes.Length)
                                {
                                    if (CanWrite(ServiceName, ClientName, InnerCodeTest))
                                    {
                                        List<DatabaseInfo> clientDBs = new List<DatabaseInfo>();
                                        for (int i = 0; i < SqlConnections.Length; i++)
                                        {
                                            if (GetDatabaseInfo(ServiceName, ClientName, Assembly.GetExecutingAssembly(), SqlConnections[i], DatabaseInfo.DatabaseStateClass.Active, out DatabaseInfo OutDatabase))
                                            {
                                                clientDBs.Add(OutDatabase);
                                            }

                                        }

                                        if (clientDBs.Count > 0)
                                        {
                                            SetStatus(ServiceName, ClientName, clientDBs, InnerCodeTest);
                                            bRC = true;
                                            _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "Successfully wrote DB version info to registry.");
                                        }
                                    }
                                    else
                                    {
                                        _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "Message received to dump DB version info.  Skipping due to below minimum allowed refresh time interval.");
                                    }
                                }
                                else
                                    throw new DataMisalignedException("SqlConnection and DatabaseTypes arrays are mixed length.");
                            }
                            else
                            {
                                _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "Command ignored : " + command);
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                        }
                        return bRC;
                    }
                    else
                    {
                        if (CodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }

                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { command, SqlConnections, SqlDatabaseTypes, CodeTest }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public bool InitializeRegistryConstants(Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { CodeTest }))
            {
                try
                {
                    if (CodeTest != Constants.SystemStatus.CodeTest.BypassReturnFalse && CodeTest != Constants.SystemStatus.CodeTest.BypassReturnTrue)
                    {
                        Constants.SystemStatus.CodeTest InnerCodeTest = CodeTest;
                        if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnTrue)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnTrue;
                        }
                        else if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnFalse)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnFalse;
                        }
                        bool bRC = false;
                        double dblMinRefreshTime = Constants.SystemStatus.DefaultTime.MinRefreshTime;
                        double dblTimeout = Constants.SystemStatus.DefaultTime.MinTimeout;
                        double dblForce = 0;

                        try
                        {
                            if (InnerCodeTest == Constants.SystemStatus.CodeTest.Off || InnerCodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                            {
                                var regService = _currentRegistryKey.CreateSubKey(Constants.SystemStatus.REG_LOCATION, RegistryKeyPermissionCheck.ReadWriteSubTree);
                                if (regService != null)
                                {
                                    dblMinRefreshTime = regService.GetValue(Constants.SystemStatus.RegistryName.MinRefreshTime, Constants.SystemStatus.DefaultTime.MinRefreshTime);
                                    if (dblMinRefreshTime < Constants.SystemStatus.DefaultTime.MinRefreshTime)
                                        dblMinRefreshTime = Constants.SystemStatus.DefaultTime.MinRefreshTime;
                                    if (dblMinRefreshTime > Constants.SystemStatus.DefaultTime.MaxRefreshTime)
                                        dblMinRefreshTime = Constants.SystemStatus.DefaultTime.MaxRefreshTime;
                                    dblTimeout = regService.GetValue(Constants.SystemStatus.RegistryName.Timeout, Constants.SystemStatus.DefaultTime.MinTimeout);
                                    if (dblTimeout < Constants.SystemStatus.DefaultTime.MinTimeout)
                                        dblTimeout = Constants.SystemStatus.DefaultTime.MinTimeout;
                                    if (dblTimeout > Constants.SystemStatus.DefaultTime.MaxTimeout)
                                        dblTimeout = Constants.SystemStatus.DefaultTime.MaxTimeout;
                                    dblForce = regService.GetValue(Constants.SystemStatus.RegistryName.Force, 0);
                                    if (dblForce != 1 && dblForce != 0)
                                    {
                                        dblForce = 0;
                                    }

                                    regService.SetValue(Constants.SystemStatus.RegistryName.MinRefreshTime, dblMinRefreshTime, RegistryValueKind.DWord);
                                    regService.SetValue(Constants.SystemStatus.RegistryName.Timeout, dblTimeout, RegistryValueKind.DWord);
                                    regService.SetValue(Constants.SystemStatus.RegistryName.Force, dblForce, RegistryValueKind.DWord);

                                    _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "InitializeRegistryConstants - Registry initialized.");
                                    bRC = true;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                        }
                        return bRC;
                    }
                    else
                    {
                        if (CodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { CodeTest }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public bool GetRegistryConstants(out double dblMinRefreshTime, out double dblTimeout, out bool bForce, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off)
        {
            dblMinRefreshTime = Constants.SystemStatus.DefaultTime.MinRefreshTime;
            dblTimeout = Constants.SystemStatus.DefaultTime.MinTimeout;
            bForce = Constants.SystemStatus.DefaultForce;

            if (CodeTest != Constants.SystemStatus.CodeTest.BypassReturnFalse && CodeTest != Constants.SystemStatus.CodeTest.BypassReturnTrue)
            {
                Constants.SystemStatus.CodeTest InnerCodeTest = CodeTest;
                if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnTrue)
                {
                    InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnTrue;
                }
                else if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnFalse)
                {
                    InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnFalse;
                }
                bool bRC = false;
                double dblForce = 0;

                try
                {
                    if (InnerCodeTest == Constants.SystemStatus.CodeTest.Off || InnerCodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                    {
                        var regService = _currentRegistryKey.CreateSubKey(Constants.SystemStatus.REG_LOCATION, RegistryKeyPermissionCheck.ReadSubTree);
                        if (regService != null)
                        {
                            dblMinRefreshTime = regService.GetValue(Constants.SystemStatus.RegistryName.MinRefreshTime, Constants.SystemStatus.DefaultTime.MinRefreshTime);
                            if (dblMinRefreshTime < Constants.SystemStatus.DefaultTime.MinRefreshTime)
                                dblMinRefreshTime = Constants.SystemStatus.DefaultTime.MinRefreshTime;
                            if (dblMinRefreshTime > Constants.SystemStatus.DefaultTime.MaxRefreshTime)
                                dblMinRefreshTime = Constants.SystemStatus.DefaultTime.MaxRefreshTime;
                            dblTimeout = regService.GetValue(Constants.SystemStatus.RegistryName.Timeout, Constants.SystemStatus.DefaultTime.MinTimeout);
                            if (dblTimeout < Constants.SystemStatus.DefaultTime.MinTimeout)
                                dblTimeout = Constants.SystemStatus.DefaultTime.MinTimeout;
                            if (dblTimeout > Constants.SystemStatus.DefaultTime.MaxTimeout)
                                dblTimeout = Constants.SystemStatus.DefaultTime.MaxTimeout;
                            dblForce = regService.GetValue(Constants.SystemStatus.RegistryName.Force, 0);
                            if (dblForce != 1 && dblForce != 0)
                            {
                                dblForce = 0;
                            }
                            if (dblForce == 0)
                            {
                                bForce = false;
                            }
                            else
                            {
                                bForce = true;
                            }
                            bRC = true;
                            _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "GetRegistryConstants - Registry read.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                }
                return bRC;
            }
            else
            {
                if (CodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool CanSendRequest(string strServiceName, string strClientName, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strServiceName, strClientName, CodeTest }))
            {
                try
                {
                    if (CodeTest != Constants.SystemStatus.CodeTest.BypassReturnFalse && CodeTest != Constants.SystemStatus.CodeTest.BypassReturnTrue)
                    {
                        Constants.SystemStatus.CodeTest InnerCodeTest = CodeTest;
                        if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnTrue)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnTrue;
                        }
                        else if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnFalse)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnFalse;
                        }
                        bool bRC = false;

                        try
                        {
                            if (!GetRegistryConstants(out double dblMinRefreshTime, out double dblTimeout, out bool bForce))
                            {
                                dblMinRefreshTime = Constants.SystemStatus.DefaultTime.MinRefreshTime;
                                dblTimeout = Constants.SystemStatus.DefaultTime.MinTimeout;
                                bForce = Constants.SystemStatus.DefaultForce;
                            }

                            DateTime dteLastRequestReceived = DateTime.MinValue;

                            if (InnerCodeTest == Constants.SystemStatus.CodeTest.Off || InnerCodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                            {
                                var regService = _currentRegistryKey.CreateSubKey(Constants.SystemStatus.REG_LOCATION + "\\" + strClientName + "\\" + strServiceName, RegistryKeyPermissionCheck.ReadSubTree);
                                if (regService != null)
                                {
                                    string strLastRequestReceived = regService.GetValue("LastRequestReceived", "");

                                    if (!string.IsNullOrEmpty(strLastRequestReceived))
                                    {
                                        if (!DateTime.TryParse(strLastRequestReceived, out dteLastRequestReceived))
                                        {
                                            dteLastRequestReceived = DateTime.MinValue;
                                        }
                                    }

                                    if (DateTime.Now > dteLastRequestReceived.AddSeconds(dblMinRefreshTime) || bForce)
                                    {
                                        _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "CanSendRequest - True, greater than min refresh time interval.");
                                        bRC = true;
                                    }
                                    else
                                    {
                                        _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "CanSendRequest - False, less than or equal to min refresh time interval.");
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                        }
                        return bRC;
                    }
                    else
                    {
                        if (CodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { strServiceName, strClientName, CodeTest }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public bool CanWrite(string strServiceName, string strClientName, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strServiceName, strClientName, CodeTest }))
            {
                try
                {
                    if (CodeTest != Constants.SystemStatus.CodeTest.BypassReturnFalse && CodeTest != Constants.SystemStatus.CodeTest.BypassReturnTrue)
                    {
                        Constants.SystemStatus.CodeTest InnerCodeTest = CodeTest;
                        if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnTrue)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnTrue;
                        }
                        else if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnFalse)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnFalse;
                        }
                        bool bRC = false;
                        try
                        {
                            if (!GetRegistryConstants(out double dblMinRefreshTime, out double dblTimeout, out bool bForce))
                            {
                                dblMinRefreshTime = Constants.SystemStatus.DefaultTime.MinRefreshTime;
                                dblTimeout = Constants.SystemStatus.DefaultTime.MinTimeout;
                                bForce = Constants.SystemStatus.DefaultForce;
                            }

                            DateTime dteLastWrite = DateTime.MinValue;

                            if (InnerCodeTest == Constants.SystemStatus.CodeTest.Off || InnerCodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                            {
                                var regService = _currentRegistryKey.CreateSubKey(Constants.SystemStatus.REG_LOCATION + "\\" + strClientName + "\\" + strServiceName, RegistryKeyPermissionCheck.ReadSubTree);
                                if (regService != null)
                                {

                                    string strLastWrite = regService.GetValue("LastWrite", "");

                                    if (!string.IsNullOrEmpty(strLastWrite))
                                    {
                                        if (!DateTime.TryParse(strLastWrite, out dteLastWrite))
                                        {
                                            dteLastWrite = DateTime.MinValue;
                                        }
                                    }

                                    if (DateTime.Now > dteLastWrite.AddSeconds(dblMinRefreshTime) || bForce)
                                    {
                                        _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "CanWrite - True, greater than min refresh time interval.");
                                        bRC = true;
                                    }
                                    else
                                    {
                                        _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "CanWrite - False, less than or equal to min refresh time interval.");
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                        }
                        return bRC;
                    }
                    else
                    {
                        if (CodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { strServiceName, strClientName, CodeTest }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public bool SendRequest(ICurrentServiceController currentSC, string strClientName, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { currentSC, strClientName, CodeTest }))
            {
                try
                {
                    if (CodeTest != Constants.SystemStatus.CodeTest.BypassReturnFalse && CodeTest != Constants.SystemStatus.CodeTest.BypassReturnTrue)
                    {
                        Constants.SystemStatus.CodeTest InnerCodeTest = CodeTest;
                        if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnTrue)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnTrue;
                        }
                        else if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnFalse)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnFalse;
                        }
                        DateTime dteLastRequestSent = DateTime.MinValue;
                        bool bRC = false;

                        try
                        {
                            if (!GetRegistryConstants(out double dblMinRefreshTime, out double dblTimeout, out bool bForce))
                            {
                                dblMinRefreshTime = Constants.SystemStatus.DefaultTime.MinRefreshTime;
                                dblTimeout = Constants.SystemStatus.DefaultTime.MinTimeout;
                                bForce = Constants.SystemStatus.DefaultForce;
                            }

                            if (InnerCodeTest == Constants.SystemStatus.CodeTest.Off || InnerCodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                            {
                                var regService = _currentRegistryKey.CreateSubKey(Constants.SystemStatus.REG_LOCATION + "\\" + strClientName + "\\" + currentSC.ServiceName, RegistryKeyPermissionCheck.ReadWriteSubTree);
                                if (regService != null)
                                {
                                    if (CanSendRequest(currentSC.ServiceName, strClientName, InnerCodeTest))
                                    {
                                        regService.SetValue("LastRequestSent", DateTime.Now.ToString(Constants.SystemStatus.DateFormat));
                                        _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "SendRequest - Request Sent.");
                                        bRC = true;
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                        }
                        if (bRC)
                        {
                            currentSC.ExecuteCommand(Constants.SystemStatus.DUMP_SVC_INFO);
                            System.Threading.Thread.Yield();
                        }
                        return bRC;
                    }
                    else
                    {
                        if (CodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { currentSC, strClientName, CodeTest }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public bool SetStatus(string strServiceName, string strClientName, List<DatabaseInfo> clientDBs, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strServiceName, strClientName, clientDBs, CodeTest }))
            {
                try
                {
                    if (CodeTest != Constants.SystemStatus.CodeTest.BypassReturnFalse && CodeTest != Constants.SystemStatus.CodeTest.BypassReturnTrue)
                    {
                        Constants.SystemStatus.CodeTest InnerCodeTest = CodeTest;
                        if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnTrue)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnTrue;
                        }
                        else if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnFalse)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnFalse;
                        }
                        bool bRC = false;

                        try
                        {
                            if (!GetRegistryConstants(out double dblMinRefreshTime, out double dblTimeout, out bool bForce))
                            {
                                dblMinRefreshTime = Constants.SystemStatus.DefaultTime.MinRefreshTime;
                                dblTimeout = Constants.SystemStatus.DefaultTime.MinTimeout;
                                bForce = Constants.SystemStatus.DefaultForce;
                            }

                            if (InnerCodeTest == Constants.SystemStatus.CodeTest.Off || InnerCodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                            {
                                var regService = _currentRegistryKey.CreateSubKey(Constants.SystemStatus.REG_LOCATION + "\\" + strClientName + "\\" + strServiceName, RegistryKeyPermissionCheck.ReadWriteSubTree);
                                if (regService != null)
                                {

                                    if (CanWrite(strServiceName, strClientName, InnerCodeTest))
                                    {
                                        try
                                        {
                                            string strClientDBs = JsonConvert.SerializeObject(clientDBs);
                                            regService.SetValue("LastWrite", DateTime.Now.ToString(Constants.SystemStatus.DateFormat));
                                            regService.SetValue("Databases", strClientDBs);
                                        }
                                        catch (Exception ex)
                                        {
                                            _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                                        }
                                        _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "SetStatus - Wrote to Registry.");
                                        bRC = true;
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                        }
                        return bRC;
                    }
                    else
                    {
                        if (CodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { strServiceName, strClientName, clientDBs, CodeTest }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public bool ClearStatus(string strServiceName, string strClientName, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strServiceName, strClientName, CodeTest }))
            {
                try
                {
                    if (CodeTest != Constants.SystemStatus.CodeTest.BypassReturnFalse && CodeTest != Constants.SystemStatus.CodeTest.BypassReturnTrue)
                    {
                        Constants.SystemStatus.CodeTest InnerCodeTest = CodeTest;
                        if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnTrue)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnTrue;
                        }
                        else if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnFalse)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnFalse;
                        }
                        bool bRC = false;

                        try
                        {
                            if (!GetRegistryConstants(out double dblMinRefreshTime, out double dblTimeout, out bool bForce))
                            {
                                dblMinRefreshTime = Constants.SystemStatus.DefaultTime.MinRefreshTime;
                                dblTimeout = Constants.SystemStatus.DefaultTime.MinTimeout;
                                bForce = Constants.SystemStatus.DefaultForce;
                            }

                            if (InnerCodeTest == Constants.SystemStatus.CodeTest.Off || InnerCodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                            {
                                var regService = _currentRegistryKey.CreateSubKey(Constants.SystemStatus.REG_LOCATION + "\\" + strClientName + "\\" + strServiceName, RegistryKeyPermissionCheck.ReadWriteSubTree);
                                if (regService != null)
                                {
                                    if (CanWrite(strServiceName, strClientName, CodeTest))
                                    {
                                        regService.DeleteValue("LastWrite", false);
                                        regService.DeleteValue("LastRequestSent", false);
                                        regService.DeleteValue("LastRequestReceived", false);
                                        regService.DeleteValue("ConnectionString", false);
                                        regService.DeleteValue("DBVersion", false);
                                        regService.DeleteValue("Status", false);
                                        _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "ClearStatus - Deleted Values from Registry.");
                                        bRC = true;
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                        }
                        return bRC;
                    }
                    else
                    {
                        if (CodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { strServiceName, strClientName, CodeTest }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public bool GetStatus(string strServiceName, string strClientName, out string strDatabase, out string strConnectionString, out string strVersionInfoDB, out string strStatus, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off)
        {
            strDatabase = "";
            strConnectionString = "";
            strVersionInfoDB = "";
            strStatus = "";

            if (CodeTest != Constants.SystemStatus.CodeTest.BypassReturnFalse && CodeTest != Constants.SystemStatus.CodeTest.BypassReturnTrue)
            {
                Constants.SystemStatus.CodeTest InnerCodeTest = CodeTest;
                if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnTrue)
                {
                    InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnTrue;
                }
                else if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnFalse)
                {
                    InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnFalse;
                }
                bool bRC = false;

                try
                {
                    if (InnerCodeTest == Constants.SystemStatus.CodeTest.Off || InnerCodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                    {
                        var regService = _currentRegistryKey.CreateSubKey(Constants.SystemStatus.REG_LOCATION + "\\" + strClientName + "\\" + strServiceName, RegistryKeyPermissionCheck.ReadSubTree);
                        if (regService != null)
                        {
                            // strDatabase
                            string strLastWrite = regService.GetValue("LastWrite", "");
                            string strLastRequestSent = regService.GetValue("LastRequestSent", "");
                            string strLastRequestReceived = regService.GetValue("LastRequestReceived", "");
                            strConnectionString = regService.GetValue("ConnectionString", "");
                            strVersionInfoDB = regService.GetValue("DBVersion", "");
                            strStatus = regService.GetValue("Status", "");
                            _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "GetStatus - Read Values from Registry.");
                            bRC = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                }
                return bRC;
            }
            else
            {
                if (CodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool GetStatus(string strServiceName, string strClientName, out List<DatabaseInfo> dbiDatabases, Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off)
        {
            dbiDatabases = new List<DatabaseInfo>();

            if (CodeTest != Constants.SystemStatus.CodeTest.BypassReturnFalse && CodeTest != Constants.SystemStatus.CodeTest.BypassReturnTrue)
            {
                Constants.SystemStatus.CodeTest InnerCodeTest = CodeTest;
                if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnTrue)
                {
                    InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnTrue;
                }
                else if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnFalse)
                {
                    InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnFalse;
                }
                bool bRC = false;

                try
                {
                    if (InnerCodeTest == Constants.SystemStatus.CodeTest.Off || InnerCodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                    {
                        var regService = _currentRegistryKey.CreateSubKey(Constants.SystemStatus.REG_LOCATION + "\\" + strClientName + "\\" + strServiceName, RegistryKeyPermissionCheck.ReadSubTree);
                        if (regService != null)
                        {
                            // strDatabase
                            string strLastWrite = regService.GetValue("LastWrite", "");
                            string strLastRequestSent = regService.GetValue("LastRequestSent", "");
                            string strLastRequestReceived = regService.GetValue("LastRequestReceived", "");
                            string strDatabases = regService.GetValue("Databases", "");
                            _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "GetStatus - Read Values from Registry.");
                            if (strDatabases.Length > 0)
                            {
                                try
                                {
                                    dbiDatabases.AddRange(JsonConvert.DeserializeObject<DatabaseInfo[]>(strDatabases));
                                    bRC = true;
                                }
                                catch (Exception ex)
                                {
                                    _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                }
                return bRC;
            }
            else
            {
                if (CodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool VerifyRegistryAccess(Constants.SystemStatus.CodeTest CodeTest = Constants.SystemStatus.CodeTest.Off)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { CodeTest }))
            {
                try
                {
                    if (CodeTest != Constants.SystemStatus.CodeTest.BypassReturnFalse && CodeTest != Constants.SystemStatus.CodeTest.BypassReturnTrue)
                    {
                        Constants.SystemStatus.CodeTest InnerCodeTest = CodeTest;
                        if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnTrue)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnTrue;
                        }
                        else if (CodeTest == Constants.SystemStatus.CodeTest.InnerReturnFalse)
                        {
                            InnerCodeTest = Constants.SystemStatus.CodeTest.BypassReturnFalse;
                        }
                        bool bRC = false;

                        RegistrySecurity rs = new RegistrySecurity();

                        // Allow the current user to read and delete the key.
                        rs.AddAccessRule(new RegistryAccessRule("mark.hogan@accruent.com",
                            RegistryRights.ReadKey | RegistryRights.Delete,
                            InheritanceFlags.ContainerInherit,
                            PropagationFlags.None,
                            AccessControlType.Allow));

                        try
                        {
                            if (InnerCodeTest == Constants.SystemStatus.CodeTest.Off || InnerCodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                            {
                                var regService = _currentRegistryKey.CreateSubKey(Constants.SystemStatus.REG_LOCATION, RegistryKeyPermissionCheck.Default, rs);
                                if (regService != null)
                                {
                                    RegistrySecurity rsExisting = regService.GetAccessControl();
                                }
                            }
                            _logger?.DebugFormat(Constants.SystemStatus.LogFormat.General, "VerifyRegistryAccess - Verified.");
                            bRC = true;
                        }
                        catch (Exception ex)
                        {
                            _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                        }
                        return bRC;
                    }
                    else
                    {
                        if (CodeTest == Constants.SystemStatus.CodeTest.BypassReturnTrue)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }

                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { CodeTest }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public int CompareVersion(string Version1, string Version2)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { Version1, Version2 }))
            {
                try
                {
                    int iRC = 0;

                    Version1 = Version1.Replace(" ", "");
                    Version1 = Version1.Replace(",", ".");
                    Version2 = Version2.Replace(" ", "");
                    Version2 = Version2.Replace(",", ".");

                    List<string> lstVersion1 = Version1.Split('.').ToList();
                    List<string> lstVersion2 = Version2.Split('.').ToList();

                    while (lstVersion1.Count() < 4)
                        lstVersion1.Add("0");
                    while (lstVersion2.Count() < 4)
                        lstVersion2.Add("0");
                    for (int i = 0; i < lstVersion1.Count(); i++)
                    {
                        if (i < lstVersion2.Count())
                        {
                            if (int.TryParse(lstVersion1[i], out int iVer1))
                            {
                                if (int.TryParse(lstVersion2[i], out int iVer2))
                                {
                                    if (iVer1 > iVer2)
                                        return 1;
                                    else if (iVer1 < iVer2)
                                        return -1;
                                }
                            }
                        }
                    }

                    return iRC;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { Version1, Version2 }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public string MaskConnectionString(string strConnectionString)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strConnectionString }))
            {
                try
                {
                    string strMaskConnectionString = "";
                    try
                    {
                        if (strConnectionString.ToLower().Contains("password"))
                        {
                            foreach (string strItem in strConnectionString.Split(';'))
                            {
                                if (strMaskConnectionString.Length > 0)
                                    strMaskConnectionString += ";";
                                if (strItem.ToLower().Contains("password"))
                                {
                                    strMaskConnectionString += strItem.Split('=')[0] + "=************";
                                }
                                else
                                {
                                    strMaskConnectionString += strItem;
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger?.ErrorFormat(Constants.SystemStatus.LogFormat.Error, ex.Message, ex.StackTrace);
                    }
                    return strMaskConnectionString;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { strConnectionString }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

    }

}