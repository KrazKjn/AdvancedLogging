using System;
using System.Data.SqlClient;
using System.Reflection;
using AdvancedLogging.BE;
using AdvancedLogging.DAL;
using AdvancedLogging.DAL.Interfaces;
using AdvancedLogging.Logging;

namespace AdvancedLogging.BLL
{
    public class VersionInfoManager : IVersionInfoManager
    {
        public const string NotApplicable = "N/A";

        private readonly IVersionInfoDAL _versionDataAccess;
        private readonly IAssemblyHelper _assemblyHelper;

        public VersionInfoManager()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    _versionDataAccess = new VersionInfoDAL();
                    _assemblyHelper = new AssemblyHelper();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        /// <summary>
        /// Constructor to use for DI when running unit tests.
        /// </summary>
        public VersionInfoManager(IVersionInfoDAL infoDal, IAssemblyHelper assemblyHelper)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { infoDal, assemblyHelper }))
            {
                try
                {
                    _versionDataAccess = infoDal;
                    _assemblyHelper = assemblyHelper;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { infoDal, assemblyHelper }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }


        public VersionDetails GetVersionDetails(Assembly assembly, string dbConnectionString)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { assembly, dbConnectionString }))
            {
                try
                {
                    if (string.IsNullOrEmpty(dbConnectionString))
                        return GetVersionDetails(assembly);
                    else
                        return GetVersionDetails(assembly, new SqlConnectionStringBuilder(dbConnectionString));
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { assembly, dbConnectionString }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        public VersionDetails GetVersionDetails(Assembly assembly, SqlConnectionStringBuilder ConnectionString = null)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { assembly, ConnectionString }))
            {
                try
                {
                    var versionDetails = GetVersionDetails(assembly);

                    if (ConnectionString != null)
                    {
                        var versionInfo = _versionDataAccess.GetDatabaseVersion(ConnectionString);
                        versionDetails.Database = $"{versionInfo.DataBaseVersion}.{versionInfo.DataBaseBuild}";
                    }

                    return versionDetails;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { assembly, ConnectionString }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public VersionDetails GetVersionDetails(Assembly assembly)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { assembly }))
            {
                try
                {
                    var versionDetails = new VersionDetails();
                    if (assembly == null)
                    {
                        return versionDetails;
                    }

                    versionDetails.Software = _assemblyHelper.GetFormattedVersion(assembly);
                    versionDetails.Database = NotApplicable;

                    return versionDetails;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { assembly }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

    }
}
