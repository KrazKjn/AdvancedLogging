using System;
using AdvancedLogging.BLL.Interfaces;
using AdvancedLogging.Logging;

namespace AdvancedLogging.BLL
{
    public class SecurityHelperFactory : ISecurityHelperFactory
    {
        private ISecurityHelperDataAccess dal;

        public SecurityHelperFactory(ISecurityHelperDataAccess dalInterface)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { dalInterface }))
            {
                try
                {
                    dal = dalInterface;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { dalInterface }, null, true, ExOuter);
                    throw;
                }
            }
        }

        public ISecurityHelper CreateSecurityHelper(string userName)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { userName }))
            {
                try
                {
                    return new SecurityHelper(userName, dal);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { userName }, null, true, ExOuter);
                    throw;
                }
            }
        }

        public ISecurityHelper CreateSecurityHelper(Int64 secPrimaryId)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { secPrimaryId }))
            {
                try
                {
                    return new SecurityHelper(secPrimaryId, dal);
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { secPrimaryId }, null, true, ExOuter);
                    throw;
                }
            }
        }
    }
}
