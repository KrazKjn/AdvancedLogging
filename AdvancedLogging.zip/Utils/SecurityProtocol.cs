using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using AdvancedLogging.Logging;

namespace AdvancedLogging.Utils
{
    public class SecurityProtocol
    {
        /// <summary>
        /// Specifies the security protocols that are supported by the Schannel securitypackage.
        /// </summary>
        [Flags]
        public enum SecurityProtocolTypeCustom
        {
            // Summary:
            //     Specifies the system default security protocol.
            SystemDefault = 0,
            // Summary:
            //     Specifies the Transport Layer Security (TLS) 1.0 security protocol.
            Tls = SecurityProtocolType.Tls,
            // Summary:
            //     Specifies the Transport Layer Security (TLS) 1.1 security protocol.
            Tls11 = 768, // missing on Framework 4.0
            // Summary:
            //     Specifies the Transport Layer Security (TLS) 1.2 security protocol.
            Tls12 = 3072, // missing on Framework 4.0
            // Summary:
            //     Specifies the Transport Layer Security (TLS) 1.3 security protocol.
            Tls13 = 12288,
            // Summary:
            //     Specifies the Secure Socket Layer (SSL) 3.0 security protocol.
            Ssl3 = SecurityProtocolType.Ssl3
        }

        private static SecurityProtocolTypeCustom m_spAvailableSecurityProtocols = SecurityProtocolTypeCustom.SystemDefault;

        public static SecurityProtocolTypeCustom AvailableSecurityProtocols
        {
            get { return m_spAvailableSecurityProtocols; }
            set { m_spAvailableSecurityProtocols = value; }
        }

        public static void EnableAllTlsSupport(bool bForceRetry = false)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { bForceRetry }))
            {
                try
                {
                    if (AvailableSecurityProtocols != (SecurityProtocolTypeCustom)ServicePointManager.SecurityProtocol || bForceRetry)
                    {
                        List<SecurityProtocolTypeCustom> arrSecurityProtocols = new List<SecurityProtocolTypeCustom>() { SecurityProtocolTypeCustom.Tls,
                            SecurityProtocolTypeCustom.Tls11,
                            SecurityProtocolTypeCustom.Tls12,
                            SecurityProtocolTypeCustom.Tls13,
                            SecurityProtocolTypeCustom.Ssl3 };

                        string strErrorMsg = "";
                        Exception exLast = null;
                        AvailableSecurityProtocols = SecurityProtocolTypeCustom.SystemDefault;
                        foreach (SecurityProtocolTypeCustom sp in arrSecurityProtocols)
                        {
                            try
                            {
                                ServicePointManager.SecurityProtocol = (SecurityProtocolType)sp;
                                AvailableSecurityProtocols = AvailableSecurityProtocols | sp;
                                vAutoLogFunction.WriteDebugFormat(LoggingUtils.DebugPrintLevel[CLog.Log_FunctionHeaderMethod] + 2, "SecurityProtocol {0} is Available.", sp.ToString());
#if DEBUG
                                LogToNT(string.Format("SecurityProtocol {0} is Available.", sp.ToString()));
#endif
                            }
                            catch (System.NotSupportedException)
                            {
                                // Ignore this Exception since the system does not support the selected SecurityProtocolType
                                vAutoLogFunction.WriteErrorFormat("SecurityProtocol {0} is NOT Available.", sp.ToString());
#if DEBUG
                                LogToNT(string.Format("SecurityProtocol {0} is NOT Available.", sp.ToString()));
#endif
                            }
                            catch (Exception ex)
                            {
                                exLast = ex;
                                if (strErrorMsg.Length > 0)
                                    strErrorMsg += Environment.NewLine;
                                strErrorMsg = "Enable " + sp.ToString() + " failed." + Environment.NewLine + ex.Message;
                                vAutoLogFunction.WriteError(strErrorMsg);
                            }
                        }
                        try
                        {
                            ServicePointManager.SecurityProtocol = (SecurityProtocolType)AvailableSecurityProtocols;
                            vAutoLogFunction.WriteDebug(LoggingUtils.DebugPrintLevel[CLog.Log_FunctionHeaderMethod] + 2, "SecurityProtocol is Set to Max Available.");
                        }
                        catch (Exception ex)
                        {
                            exLast = ex;
                            if (strErrorMsg.Length > 0)
                                strErrorMsg += Environment.NewLine;
                            strErrorMsg = "Enable Max Value of " + ((int)AvailableSecurityProtocols).ToString() + " failed." + Environment.NewLine + ex.Message;
                            vAutoLogFunction.WriteError(strErrorMsg);
                        }
                        if (strErrorMsg != "")
                        {
                            try
                            {
                                using (EventLog eventLog = new EventLog("Application"))
                                {
                                    eventLog.Source = "Application";
                                    StackTrace t = new StackTrace();
                                    StackFrame[] arrFrames = t.GetFrames();
                                    string strMsg = "Process Info:" + Environment.NewLine;
                                    for (int i = arrFrames.Length - 1; i >= 0; i--)
                                    {
                                        if (!CLog.FunctionFullName(arrFrames[i].GetMethod()).Contains("ctor"))
                                            strMsg += CLog.FunctionFullName(arrFrames[i].GetMethod()) + Environment.NewLine;
                                    }
                                    eventLog.WriteEntry(strMsg + strErrorMsg + Environment.NewLine + exLast?.ToString(), EventLogEntryType.Error, 1, 1);
                                }
                            }
                            catch (Exception) { }
                        }
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { bForceRetry }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public static void LogSecurityProtocol(CLog Logger = null)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { Logger }))
            {
                try
                {
                    if (ServicePointManager.SecurityProtocol == (SecurityProtocolType)SecurityProtocolTypeCustom.SystemDefault)
                    {
                        vAutoLogFunction.WriteLog("Security Protocol: System Default is enabled.");
                    }
                    else
                    {
                        List<SecurityProtocolTypeCustom> arrSecurityProtocols = new List<SecurityProtocolTypeCustom>() { SecurityProtocolTypeCustom.Tls,
                           SecurityProtocolTypeCustom.Tls11,
                           SecurityProtocolTypeCustom.Tls12,
                           SecurityProtocolTypeCustom.Tls13,
                           SecurityProtocolTypeCustom.Ssl3 };
                        foreach (SecurityProtocolTypeCustom sp in arrSecurityProtocols)
                        {
                            try
                            {
                                if ((ServicePointManager.SecurityProtocol & (SecurityProtocolType)sp) == (SecurityProtocolType)sp)
                                {
                                    vAutoLogFunction.WriteLogFormat("Security Protocol: {0} is enabled.", sp.ToString());
                                }
                                else
                                {
                                    vAutoLogFunction.WriteLogFormat("Security Protocol: {0} not enabled.", sp.ToString());
                                }
                            }
                            catch (Exception ex)
                            {
                                vAutoLogFunction.WriteErrorFormat(ex.Message);
                            }
                        }
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { Logger }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public static void EnableTlsSupport(SecurityProtocolTypeCustom secprotocols)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { secprotocols }))
            {
                try
                {
                    if (ServicePointManager.SecurityProtocol != (SecurityProtocolType)secprotocols)
                    {
                        ServicePointManager.SecurityProtocol = (SecurityProtocolType)secprotocols;
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { secprotocols }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        public static void EnableDefaultTlsSupport()
        {
            using (var vAutoLogFunction = new AutoLogFunction())
            {
                try
                {
                    if (ServicePointManager.SecurityProtocol != (SecurityProtocolType)SecurityProtocolTypeCustom.SystemDefault)
                    {
                        ServicePointManager.SecurityProtocol = (SecurityProtocolType)SecurityProtocolTypeCustom.SystemDefault;
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        private static void LogToNT(string strMsg)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strMsg }))
            {
                try
                {
                    StackTrace t = new StackTrace();
                    StackFrame[] arrFrames = t.GetFrames();
                    string strCallPath = "Process Info:" + Environment.NewLine;
                    for (int i = arrFrames.Length - 1; i >= 0; i--)
                    {
                        if (!CLog.FunctionFullName(arrFrames[i].GetMethod()).Contains("ctor"))
                            strCallPath += CLog.FunctionFullName(arrFrames[i].GetMethod()) + Environment.NewLine;
                    }

                    using (EventLog eventLog = new EventLog("Application"))
                    {
                        eventLog.Source = "Application";
                        eventLog.WriteEntry(strMsg, EventLogEntryType.Information, 0, 0);
                        eventLog.WriteEntry(strCallPath, EventLogEntryType.Information, 0, 0);
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { strMsg }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
    }
}
