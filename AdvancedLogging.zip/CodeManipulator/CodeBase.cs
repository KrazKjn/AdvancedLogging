﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeManipulator
{
    class CodeBase
    {
        public class ProgressChangedEventArgs : EventArgs
        {
            public string FileName { get; private set; }
            public string ItemName { get; private set; }
            public int Current { get; private set; }
            public int Total { get; private set; }
            public ProgressChangedEventArgs(string _FileName, string _ItemName, int _Value, int _Total)
            {
                FileName = _FileName;
                ItemName = _ItemName;
                Current = _Value;
                Total = _Total;
            }
        }
        public event EventHandler<ProgressChangedEventArgs> ProgressChanged;

        protected void UpdateProgress(string _FileName, string _ItemName, int _Current, int _Total)
        {
            if (ProgressChanged != null)
            {
                ProgressChangedEventArgs e = new ProgressChangedEventArgs(_FileName, _ItemName, _Current, _Total);
                ProgressChanged(this, e);
            }
        }
        public bool ProgressEventsEnabled
        {
            get
            {
                return (ProgressChanged != null);
            }
        }
    }
}
