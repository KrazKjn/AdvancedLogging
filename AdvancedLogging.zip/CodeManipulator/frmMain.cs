﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Formatting;
using System.ServiceModel.Syndication;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Windows.Forms;
using Trinet.Core.IO.Ntfs;
using log4net;
using System.Configuration;

namespace CodeManipulator
{
    public partial class frmMain : Form
    {
        public enum CodeItems
        {
            None = 0,
            Constructor = 0x1,
            Method = 0x2,
            RetrySql = 0x4,
            RetryHttp = 0x8,
            AutoLog = 0x10,
            TryCatch = 0x20,
            Property = 0x40,
            Class = 0x80,
            ModifyEmptyBody = 0x100
        }
        private List<string> m_lstFoldersToSkip = null;
        private System.Collections.Specialized.StringCollection m_colProcessFiles = new System.Collections.Specialized.StringCollection();
        private Dictionary<string, bool> m_dicHttpsMethods = new Dictionary<string, bool>();
        private Dictionary<string, bool> m_dicSqlMethods = new Dictionary<string, bool>();

        private bool m_bSaveAsStream = false;
        private List<string> m_lstLogName = new List<string>();
        public frmMain()
        {
            InitializeComponent();
            m_lstFoldersToSkip = new List<string>() { "bin", "obj", "images", "backup", "css", "ig_common", "scripts" };
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (chkRecurseFolders.Checked)
            {
                switch (MessageBox.Show("Recurse all folders?", Text, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question))
                {
                    case DialogResult.No:
                        chkRecurseFolders.Checked = false;
                        break;
                    case DialogResult.Cancel:
                        return;
                }
            }
            Cursor = Cursors.WaitCursor;
            lvwFiles.Items.Clear();
            CodeItems ci = CodeItems.None;
            if (chkFixConstructors.Checked)
                ci = ci | CodeItems.Constructor;
            if (chkFixMethods.Checked)
                ci = ci | CodeItems.Method;
            if (chkFixProperties.Checked)
                ci = ci | CodeItems.Property;
            if (chkFixBaseClass.Checked)
                ci = ci | CodeItems.Class;
            if (chkAutoReTrySQL.Checked)
                ci = ci | CodeItems.RetrySql;
            if (chkAutoReTryHttp.Checked)
                ci = ci | CodeItems.RetryHttp;
            if (chkAddAutoLog.Checked)
                ci = ci | CodeItems.AutoLog;
            if (chkAddTryCatch.Checked)
                ci = ci | CodeItems.TryCatch;
            if (chkProcessEmptyFunctions.Checked)
                ci = ci | CodeItems.ModifyEmptyBody;
            m_colProcessFiles.Clear();
            if (File.Exists(Path.Combine(txtFolder.Text, "AutoLogManagement.txt")))
            {
                m_colProcessFiles.AddRange(File.ReadAllLines(Path.Combine(txtFolder.Text, "AutoLogManagement.txt")));
            }
            SearchForFilesInFolder(txtFolder.Text, ci, chkBackup.Checked, chkRecurseFolders.Checked, false);
            tsslStatus.Text = "Ready!";
            Cursor = Cursors.Default;
        }

        private void SearchForFilesInFolder(string strFolderName, CodeItems ci, bool bBackup = false, bool bRecurseFolders = false, bool bShowFile = false)
        {
            List<string> FileExtenstions = new List<string>() { ".cs", ".vb" };
            SearchForFilesInFolder(new DirectoryInfo(strFolderName), FileExtenstions, ci, bBackup, bRecurseFolders, bShowFile);
        }

        private void SearchForFilesInFolder(DirectoryInfo diFolder, List<string> SearchString, CodeItems ci, bool bBackup = false, bool bRecurseFolders = false, bool bShowFile = false)
        {
            ListViewGroup lvg = lvwFiles.Groups.Add(diFolder.FullName, diFolder.FullName);
            foreach (FileInfo fiSelected in diFolder.GetFiles())
            {
                if (!SearchString.Any(p => p == fiSelected.Extension))
                    continue;

                CodeItems lci = ci;
                if (fiSelected.Name.ToLower() == "HttpWebExtensions.cs".ToLower())
                    lci = ci ^ CodeItems.RetryHttp;
                if (fiSelected.Name.ToLower() == "SqlExtensions.cs".ToLower())
                    lci = ci ^ CodeItems.RetrySql;
                if (fiSelected.Name.ToLower() == "AutoLogFunction.cs".ToLower() ||
                    fiSelected.Name.ToLower() == "ICLog.cs".ToLower() ||
                    fiSelected.Name.ToLower() == "CLog.cs".ToLower())
                    continue;

                bool bProcessed = false;
                //try
                //{
                //    string strStatus = File.ReadAllText(fiSelected.FullName + ":Status");
                //    bProcessed = (strStatus == "<Status>Processed</Status>");
                //}
                //catch (Exception ex)
                //{

                //}
                if (fiSelected.AlternateDataStreamExists("Status"))
                {
                    Debug.WriteLine("Found Status stream:");

                    AlternateDataStreamInfo s = fiSelected.GetAlternateDataStream("Status", FileMode.Open);
                    using (TextReader reader = s.OpenText())
                    {
                        Debug.WriteLine(reader.ReadToEnd());
                    }

                    // Delete the stream:
                    //s.Delete();
                }
                bProcessed = m_colProcessFiles.Contains(fiSelected.FullName.Substring(txtFolder.Text.Trim().Length + 1));
#if _ORIG
                tsslStatus.Text = "Processing: " + fiSelected.FullName + "...";
                if (ProcessFile(fiSelected, lci, bBackup, bShowFile))
                {
                    fiSelected.Refresh();
                    ListViewItem lvi = lvwFiles.Items.Add(fiSelected.FullName, "cs");
                    lvi.Group = lvg;
                    lvi.SubItems.Add(fiSelected.LastWriteTime.ToShortDateString() + " " + fiSelected.LastWriteTime.ToShortTimeString());
                    try
                    {
                        fiSelected.Refresh();
                        lvi.SubItems.Add(fiSelected.Length.ToString("#,##0"));
                        lvi.SubItems.Add(bProcessed ? "Udpated" : "Not Updated");
                    }
                    catch (Exception ex)
                    {

                    }
                    Application.DoEvents();
                }
#else
                if (fiSelected.Length > 0)
                {
                    ListViewItem lvi = lvwFiles.Items.Add(fiSelected.FullName, fiSelected.Extension.Replace(".", ""));
                    lvi.Group = lvg;
                    lvi.SubItems.Add(fiSelected.LastWriteTime.ToShortDateString() + " " + fiSelected.LastWriteTime.ToShortTimeString());
                    try
                    {
                        fiSelected.Refresh();
                        lvi.SubItems.Add(fiSelected.Length.ToString("#,##0"));
                        lvi.SubItems.Add(bProcessed ? "Updated" : "Not Updated");
                    }
                    catch (Exception ex)
                    {

                    }
                    tsslTotalFiles.Text = lvwFiles.Items.Count.ToString("#,##0") + " Files";
                }
                Application.DoEvents();
#endif
            }
            if (bRecurseFolders)
            {
                foreach (DirectoryInfo diSelected in diFolder.GetDirectories())
                {
                    if (!m_lstFoldersToSkip.Any(p => p == diSelected.Name.ToLower()))
                    {
                        SearchForFilesInFolder(diSelected.FullName, ci, bBackup, bRecurseFolders, bShowFile);
                    }
                }
            }
        }
#if SAMPLECODE
        private static Compilation CreateTestCompilation() // String programText)
        {
            // creation of the syntax tree for every file
            DirectoryInfo di = new DirectoryInfo(Environment.CurrentDirectory);
            while (!File.Exists(@"Program.cs") && di.Parent != null)
            {
                Environment.CurrentDirectory = di.Parent.FullName;
                di = new DirectoryInfo(Environment.CurrentDirectory);
            }
            String programPath = @"Program.cs";
            String programText = File.ReadAllText(programPath);
            SyntaxTree programTree = CSharpSyntaxTree.ParseText(programText).WithFilePath(programPath);
            //SyntaxTree programTree = CSharpSyntaxTree.ParseText(programText);
            String rewriterPath = @"InitializerRewriter.cs";
            String rewriterText = File.ReadAllText(rewriterPath);
            SyntaxTree rewriterTree = CSharpSyntaxTree.ParseText(rewriterText).WithFilePath(rewriterPath);
            //SyntaxTree rewriterTree = CSharpSyntaxTree.ParseText(rewriterText);
            SyntaxTree[] sourceTrees = { programTree, rewriterTree };
            // gathering the assemblies
            MetadataReference mscorlib = MetadataReference.CreateFromFile(typeof(object).GetTypeInfo().Assembly.Location);
            MetadataReference codeAnalysis = MetadataReference.CreateFromFile(typeof(SyntaxTree).GetTypeInfo().Assembly.Location);
            MetadataReference csharpCodeAnalysis = MetadataReference.CreateFromFile(typeof(CSharpSyntaxTree).GetTypeInfo().Assembly.Location);
            MetadataReference[] references = { mscorlib, codeAnalysis, csharpCodeAnalysis };
            // compilation
            return CSharpCompilation.Create("ConsoleApplication",
                sourceTrees,
                references,
                new CSharpCompilationOptions(OutputKind.ConsoleApplication));
        }
        public void MainTest(String programText, String strFolder = "")
        {
            Compilation test = CreateTestCompilation(); // programText);
            foreach (SyntaxTree sourceTree in test.SyntaxTrees)
            {
                // creation of the semantic model
                SemanticModel model = test.GetSemanticModel(sourceTree);
                // initialization of our rewriter class
                InitializerRewriter rewriter = new InitializerRewriter(model);
                // analysis of the tree
                SyntaxNode newSource = rewriter.Visit(sourceTree.GetRoot());
                if (!Directory.Exists(@"../new_src"))
                    Directory.CreateDirectory(@"../new_src");
                // if we changed the tree we save a new file
                if (newSource != sourceTree.GetRoot())
                {
                    File.WriteAllText(Path.Combine(@"../new_src", Path.GetFileName(sourceTree.FilePath)), newSource.ToFullString());
                }
            }
        }
#endif
        private void btnFolder_Click(object sender, EventArgs e)
        {
            fbdCode.RootFolder = Environment.SpecialFolder.MyComputer;
            fbdCode.Description = "Find Code Folder";
            if (txtFolder.Text.Length > 0)
            {
                if (Directory.Exists(txtFolder.Text))
                {
                    fbdCode.SelectedPath = txtFolder.Text;
                }
            }
            if (fbdCode.ShowDialog() == DialogResult.OK)
            {
                Cursor = Cursors.WaitCursor;
                txtFolder.Text = fbdCode.SelectedPath;
                Cursor = Cursors.Default;
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            String[] arrTest = new string[] { "Test", "Test2"};

            txtFolder.Text = Properties.Settings.Default.Directory;
            chkBackup.Checked = Properties.Settings.Default.Backup;
            chkRecurseFolders.Checked = Properties.Settings.Default.RecurseFolders;
            chkAddAutoLog.Checked = Properties.Settings.Default.AddAutoLog;
            chkAddTryCatch.Checked = Properties.Settings.Default.AddTryCatch;
            chkFixConstructors.Checked = Properties.Settings.Default.FixConstructors;
            chkFixMethods.Checked = Properties.Settings.Default.FixMethods;
            chkAutoReTrySQL.Checked = Properties.Settings.Default.AutoReTrySQL;
            chkAutoReTryHttp.Checked = Properties.Settings.Default.AutoReTryHttp;
            chkFixProperties.Checked = Properties.Settings.Default.FixProperties;
            chkFixBaseClass.Checked = Properties.Settings.Default.FixClass;

            Debug.WriteLine("HttpWebExtension Functions ...");
            foreach (var method in typeof(AdvancedLogging.DAL.HttpWebExtensions).GetMethods())
            {
                var parameters = method.GetParameters();
                var parameterDescriptions = string.Join(", ", method.GetParameters().Select(x => x.ParameterType + " " + x.Name).ToArray());

                Debug.WriteLine("{0} {1} ({2})", method.ReturnType, method.Name, parameterDescriptions);
                if (method.GetParameters().Any(x => x.Name.ToLower().Contains("retries")))
                {
                    if (!m_dicHttpsMethods.ContainsKey(method.Name))
                        m_dicHttpsMethods.Add(method.Name, true);
                }
            }
            foreach (var method in typeof(AdvancedLogging.DAL.HttpClientExtensions).GetMethods())
            {
                var parameters = method.GetParameters();
                var parameterDescriptions = string.Join(", ", method.GetParameters().Select(x => x.ParameterType + " " + x.Name).ToArray());

                Debug.WriteLine("{0} {1} ({2})", method.ReturnType, method.Name, parameterDescriptions);
                if (method.GetParameters().Any(x => x.Name.ToLower().Contains("retries")))
                {
                    if (!m_dicHttpsMethods.ContainsKey(method.Name))
                        m_dicHttpsMethods.Add(method.Name, true);
                }
            }
            Debug.WriteLine("SqlExtension Functions ...");
            foreach (var method in typeof(AdvancedLogging.DAL.SqlExtensions).GetMethods())
            {
                var parameters = method.GetParameters();
                var parameterDescriptions = string.Join(", ", method.GetParameters().Select(x => x.ParameterType + " " + x.Name).ToArray());

                Debug.WriteLine("{0} {1} ({2})", method.ReturnType, method.Name, parameterDescriptions);
                if (method.GetParameters().Any(x => x.Name.ToLower().Contains("retries")))
                {
                    if (!m_dicSqlMethods.ContainsKey(method.Name))
                        m_dicSqlMethods.Add(method.Name, true);
                }
            }
            // Test System.Reflection.MethodBase.GetCurrentMethod() Cost
            Stopwatch sw = new Stopwatch();
            int i = 0;
            int iCount = 100000;
            System.Reflection.MethodBase mb = null;
            sw.Start();
            for (i = 0; i < iCount; i++)
            {
                mb = System.Reflection.MethodBase.GetCurrentMethod();
            }
            sw.Stop();
            Debug.WriteLine("Calling GetCurrentMethod() " + iCount.ToString() + " time = " + sw.ElapsedTicks.ToString() + "; Total MS: " + ((double)sw.ElapsedTicks / TimeSpan.TicksPerMillisecond).ToString());
            Debug.WriteLine("  Tickets per call " + ((double)sw.ElapsedTicks / iCount).ToString());

            sw.Reset();
            sw.Start();
            for (i = 0; i < iCount; i++)
            {
                //mb = System.Reflection.MethodBase.GetCurrentMethod();
            }
            sw.Stop();
            Debug.WriteLine("Calling Nothing " + iCount.ToString() + " time = " + sw.ElapsedTicks.ToString() + "; Total MS: " + ((double)sw.ElapsedTicks / TimeSpan.TicksPerMillisecond).ToString());
            Debug.WriteLine("  Tickets per call " + ((double)sw.ElapsedTicks / iCount).ToString());
            TestMethodbase(System.Reflection.MethodBase.GetCurrentMethod());
        }

        private void TestMethodbase(System.Reflection.MethodBase method)
        {
            StackFrame sf = new StackFrame(1, true);
            Debug.WriteLine(sf.GetMethod());
            Debug.WriteLine(method);
            Debug.WriteLine("Same: " + (sf.GetMethod() == method));
        }

        private void Common_CheckedChanged(object sender, EventArgs e)
        {
            btnProcess.Enabled = (((chkAddAutoLog.Checked || chkAddTryCatch.Checked) && (chkFixConstructors.Checked || chkFixMethods.Checked || chkFixBaseClass.Checked) || chkAutoReTryHttp.Checked || chkAutoReTrySQL.Checked) && lvwFiles.CheckedItems.Count > 0);
        }

        private void txtFolder_TextChanged(object sender, EventArgs e)
        {
            btnSearch.Enabled = Directory.Exists(txtFolder.Text);
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;

            tspbSelectedFiles.Maximum = lvwFiles.CheckedItems.Count;
            tspbSelectedFiles.Value = 0;
            m_lstLogName.Clear();

            CodeItems ci = CodeItems.None;
            if (chkFixConstructors.Checked)
                ci = ci | CodeItems.Constructor;
            if (chkFixMethods.Checked)
                ci = ci | CodeItems.Method;
            if (chkFixProperties.Checked)
                ci = ci | CodeItems.Property;
            if (chkFixBaseClass.Checked)
                ci = ci | CodeItems.Class;
            if (chkAutoReTrySQL.Checked)
                ci = ci | CodeItems.RetrySql;
            if (chkAutoReTryHttp.Checked)
                ci = ci | CodeItems.RetryHttp;
            if (chkAddAutoLog.Checked)
                ci = ci | CodeItems.AutoLog;
            if (chkAddTryCatch.Checked)
                ci = ci | CodeItems.TryCatch;

            if (File.Exists(Path.Combine(txtFolder.Text, "AutoLogManagement.txt")))
            {
                m_colProcessFiles.Clear();
                m_colProcessFiles.AddRange(File.ReadAllLines(Path.Combine(txtFolder.Text, "AutoLogManagement.txt")));
            }
            foreach (ListViewItem lviChecked in lvwFiles.CheckedItems)
            {
                FileInfo fiSelected = new FileInfo(lviChecked.Text);
                tsslStatus.Text = "Scanning: " + fiSelected.FullName + " for ILog Declaration ...";
                CodeItems lci = ci;
                if (fiSelected.Name.ToLower() == "HttpWebExtensions.cs".ToLower())
                    lci = ci ^ CodeItems.RetryHttp;
                if (fiSelected.Name.ToLower() == "SqlExtensions.cs".ToLower())
                    lci = ci ^ CodeItems.RetrySql;
                if (fiSelected.Name.ToLower() == "AutoLogFunction.cs".ToLower() ||
                    fiSelected.Name.ToLower() == "ICLog.cs".ToLower() ||
                    fiSelected.Name.ToLower() == "CLog.cs".ToLower())
                    continue;
                lviChecked.EnsureVisible();
                lviChecked.Selected = true;
                if (fiSelected.Extension == ".vb")
                {
                    CodeVisualBasic codeVB = new CodeVisualBasic(m_colProcessFiles, m_lstLogName, m_dicHttpsMethods, m_dicSqlMethods, txtFolder.Text, m_bSaveAsStream);
                    codeVB.ProgressChanged += CodeVB_ProgressChanged;
                    codeVB.WalkTree = true;
                    if (codeVB.ProcessFile(fiSelected, lci, chkBackup.Checked, false, true))
                    {
                        fiSelected.Refresh();

                        tspbSelectedFiles.Value++;
                        Application.DoEvents();
                    }
                    codeVB.ProgressChanged -= CodeVB_ProgressChanged;
                    tssbFileStatus.Visible = false;
                }
                else if (fiSelected.Extension == ".cs")
                {
                    CodeCSharp codeCS = new CodeCSharp(m_colProcessFiles, m_lstLogName, m_dicHttpsMethods, m_dicSqlMethods, txtFolder.Text, m_bSaveAsStream);
                    codeCS.ProgressChanged += CodeVB_ProgressChanged;
                    if (codeCS.ProcessFile(fiSelected, lci, chkBackup.Checked, false, true))
                    //if (ProcessFile(fiSelected, lci, chkBackup.Checked, false, true))
                    {
                        fiSelected.Refresh();

                        tspbSelectedFiles.Value++;
                        Application.DoEvents();
                    }
                    codeCS.ProgressChanged -= CodeVB_ProgressChanged;
                    tssbFileStatus.Visible = false;
                }
            }
            tspbSelectedFiles.Value = 0;
            foreach (ListViewItem lviChecked in lvwFiles.CheckedItems)
            {
                FileInfo fiSelected = new FileInfo(lviChecked.Text);
                tsslStatus.Text = "Processing: " + fiSelected.FullName + "...";
                CodeItems lci = ci;
                if (fiSelected.Name.ToLower() == "HttpWebExtensions.cs".ToLower())
                    lci = ci ^ CodeItems.RetryHttp;
                if (fiSelected.Name.ToLower() == "SqlExtensions.cs".ToLower())
                    lci = ci ^ CodeItems.RetrySql;
                if (fiSelected.Name.ToLower() == "AutoLogFunction.cs".ToLower() ||
                    fiSelected.Name.ToLower() == "ICLog.cs".ToLower() ||
                    fiSelected.Name.ToLower() == "CLog.cs".ToLower())
                    continue;
                lviChecked.EnsureVisible();
                lviChecked.Selected = true;
                if (m_colProcessFiles.Contains(fiSelected.FullName.Substring(txtFolder.Text.Trim().Length + 1)))
                {
                    Debug.WriteLine("Already processed!");
                }
                else
                {
                    if (fiSelected.Extension == ".vb")
                    {
                        CodeVisualBasic codeVB = new CodeVisualBasic(m_colProcessFiles, m_lstLogName, m_dicHttpsMethods, m_dicSqlMethods, txtFolder.Text, m_bSaveAsStream);
                        codeVB.ProgressChanged += CodeVB_ProgressChanged;
                        codeVB.WalkTree = true;
                        if (codeVB.ProcessFile(fiSelected, lci, chkBackup.Checked, false))
                        {
                            fiSelected.Refresh();

                            lviChecked.Checked = false;
                            lviChecked.SubItems[3].Text = "Updated";
                        }
                        tspbSelectedFiles.Value++;
                        Application.DoEvents();
                        codeVB.ProgressChanged -= CodeVB_ProgressChanged;
                        tssbFileStatus.Visible = false;
                    }
                    else if (fiSelected.Extension == ".cs")
                    {
                        CodeCSharp codeCS = new CodeCSharp(m_colProcessFiles, m_lstLogName, m_dicHttpsMethods, m_dicSqlMethods, txtFolder.Text, m_bSaveAsStream);
                        codeCS.ProgressChanged += CodeVB_ProgressChanged;
                        if (codeCS.ProcessFile(fiSelected, lci, chkBackup.Checked, false))
                        //if (ProcessFile(fiSelected, lci, chkBackup.Checked, false))
                        {
                            fiSelected.Refresh();

                            lviChecked.Checked = false;
                            lviChecked.SubItems[3].Text = "Updated";
                        }
                        tspbSelectedFiles.Value++;
                        Application.DoEvents();
                        codeCS.ProgressChanged -= CodeVB_ProgressChanged;
                        tssbFileStatus.Visible = false;
                    }
                }
                lviChecked.Selected = false;
            }
            if (File.Exists(Path.Combine(txtFolder.Text, "AutoLogManagement.txt")))
            {
                File.Delete(Path.Combine(txtFolder.Text, "AutoLogManagement.txt"));
            }
            File.WriteAllLines(Path.Combine(txtFolder.Text, "AutoLogManagement.txt"), m_colProcessFiles.Cast<string>());

            tsslStatus.Text = "Ready!";
            Cursor = Cursors.Default;
        }

        private void CodeVB_ProgressChanged(object sender, CodeVisualBasic.ProgressChangedEventArgs e)
        {
            if (!tssbFileStatus.Visible)
                tssbFileStatus.Visible = true;
            if (tssbFileStatus.Maximum != e.Total)
                tssbFileStatus.Maximum = e.Total;
            if (e.Current <= tssbFileStatus.Maximum)
                tssbFileStatus.Value = e.Current;
            tssbFileStatus.ToolTipText = "Processing " + e.ItemName + " ...";
            Debug.WriteLine(string.Format("Processing {0} - {1} - {2}%", e.FileName, e.ItemName, (e.Current * 100.0 / e.Total).ToString("#0.00")));
        }

        private void lvwFiles_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            if (!lvwFiles.Enabled)
                return;
            tsslSelectedFiles.Text = lvwFiles.CheckedItems.Count.ToString("#,##0") + " Files Selected";
            Common_CheckedChanged(sender, null);
        }

        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            mnuFileSaveConfiguration.PerformClick();
        }

        private void mnuFilesSelectAll_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem lvi in lvwFiles.Items)
            {
                lvi.Selected = true;
            }
        }

        private void mnuFilesCheckSelected_Click(object sender, EventArgs e)
        {
            lvwFiles.Enabled = false;
            foreach (ListViewItem lvi in lvwFiles.SelectedItems)
            {
                lvi.Checked = true;
            }
            lvwFiles.Enabled = true;
            Common_CheckedChanged(sender, null);
        }

        private void mnuFilesClear_Click(object sender, EventArgs e)
        {
            lvwFiles.SelectedItems.Clear();
            lvwFiles.Enabled = false;
            foreach (ListViewItem lvi in lvwFiles.CheckedItems)
            {
                lvi.Checked = false;
            }
            lvwFiles.Enabled = true;
            Common_CheckedChanged(sender, null);
        }

        private void lvwFiles_MouseDown(object sender, MouseEventArgs e)
        {
            ListViewHitTestInfo lvhti = lvwFiles.HitTest(e.Location);
            if (lvhti != null)
            {
                if (lvhti.Item != null)
                {
                    mnuFilesResetUpdate.Enabled = (lvhti.Item.SubItems[3].Text == "Updated");
                    mnuFilesResetUpdate.Tag = lvhti.Item;
                }
            }
        }

        private void mnuFilesResetUpdate_Click(object sender, EventArgs e)
        {
            if (mnuFilesResetUpdate.Tag is ListViewItem)
            {
                ListViewItem lvi = mnuFilesResetUpdate.Tag as ListViewItem;
                lvi.SubItems[3].Text = "Not Updated";
                string strTemp = lvi.Text.Substring(txtFolder.Text.Trim().Length + 1);
                while (m_colProcessFiles.Contains(strTemp))
                    m_colProcessFiles.Remove(strTemp);
                if (File.Exists(Path.Combine(txtFolder.Text, "AutoLogManagement.txt")))
                {
                    File.Delete(Path.Combine(txtFolder.Text, "AutoLogManagement.txt"));
                }
                File.WriteAllLines(Path.Combine(txtFolder.Text, "AutoLogManagement.txt"), m_colProcessFiles.Cast<string>());
            }
        }

        private void mnuViewRetryFunctions_Click(object sender, EventArgs e)
        {
            frmRetryFunctions frmRetry = new frmRetryFunctions();

            frmRetry.HttpsMethods = m_dicHttpsMethods;
            frmRetry.SqlMethods = m_dicSqlMethods;
            if (frmRetry.ShowDialog() == DialogResult.OK)
            {
                m_dicHttpsMethods = frmRetry.HttpsMethods;
                m_dicSqlMethods = frmRetry.SqlMethods;
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mnuFileSaveConfiguration_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.Directory = txtFolder.Text;
            Properties.Settings.Default.Backup = chkBackup.Checked;
            Properties.Settings.Default.RecurseFolders = chkRecurseFolders.Checked;
            Properties.Settings.Default.AddAutoLog = chkAddAutoLog.Checked;
            Properties.Settings.Default.AddTryCatch = chkAddTryCatch.Checked;
            Properties.Settings.Default.FixConstructors = chkFixConstructors.Checked;
            Properties.Settings.Default.FixMethods = chkFixMethods.Checked;
            Properties.Settings.Default.AutoReTrySQL = chkAutoReTrySQL.Checked;
            Properties.Settings.Default.AutoReTryHttp = chkAutoReTryHttp.Checked;
            Properties.Settings.Default.FixProperties = chkFixProperties.Checked;
            Properties.Settings.Default.FixClass = chkFixBaseClass.Checked;
            Properties.Settings.Default.SqlMethods = new System.Collections.Specialized.StringCollection();
            //for (int i = 0; i < m_dicHttpsMethods.Count; i++)
            //{
            //    Properties.Settings.Default.SqlMethods.Add(m_dicHttpsMethods.Keys.i[i] m_dicHttpsMethods[i]);
            //}
            //m_dicSqlMethods
            Properties.Settings.Default.Upgrade();
            Properties.Settings.Default.Save();
        }

        private void mnuFilesOpen_Click(object sender, EventArgs e)
        {
            if (lvwFiles.SelectedItems.Count > 0)
            {
                FileInfo fiSelected = new FileInfo(lvwFiles.SelectedItems[0].Text);
                Process p = new Process();
                p.StartInfo.FileName = "notepad.exe";
                p.StartInfo.Arguments = fiSelected.FullName;
                p.Start();
            }
        }

        private void cmsFiles_Opening(object sender, CancelEventArgs e)
        {
            mnuFilesOpen.Enabled = (lvwFiles.SelectedItems.Count > 0);
        }
    }
}
