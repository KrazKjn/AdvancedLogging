﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.VisualBasic;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeManipulator
{
    public class VBDeeperWalker : VisualBasicSyntaxWalker
    {
        static int Tabs = 0;
        //NOTE: Make sure you invoke the base constructor with 
        //the correct SyntaxWalkerDepth. Otherwise VisitToken()
        //will never get run.
        public VBDeeperWalker() : base(SyntaxWalkerDepth.Token)
        {
        }
        public override void Visit(SyntaxNode node)
        {
            Tabs++;
            string indents = new String('\t', Tabs);
            string output = indents + node.Kind();
            if (output.Contains("Block"))
            {
                Debug.WriteLine("Block");
            }
            else
                output += " [" + node.ToString() + "]";
            Debug.WriteLine(output);
            base.Visit(node);
            Tabs--;
        }

        public override void VisitToken(SyntaxToken token)
        {
            string indents = new String('\t', Tabs);
            string output = indents + token;
            Debug.WriteLine(output);
            base.VisitToken(token);
        }
    }
}
