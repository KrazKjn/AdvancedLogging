﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using static CodeManipulator.frmMain;
using Trinet.Core.IO.Ntfs;
using System.Windows.Forms;

namespace CodeManipulator
{
    class CodeCSharp : CodeBase
    {
        private System.Collections.Specialized.StringCollection m_colProcessFiles = new System.Collections.Specialized.StringCollection();
        private List<string> m_lstLogName = new List<string>();
        private List<string> m_lstDetailedLoggingFunctions = new List<string>();
        private Dictionary<string, bool> m_dicHttpsMethods = new Dictionary<string, bool>();
        private Dictionary<string, bool> m_dicSqlMethods = new Dictionary<string, bool>();
        private bool m_bSaveAsStream = false;
        private string m_strFolder = "";

        public List<string> ListLogName
        {
            get { return m_lstLogName; }
            set { m_lstLogName = value; }
        }
        public List<string> DetailedLoggingFunctions
        {
            get { return m_lstDetailedLoggingFunctions; }
            set { m_lstDetailedLoggingFunctions = value; }
        }
        public Dictionary<string, bool> HttpsMethods
        {
            get { return m_dicHttpsMethods; }
            set { m_dicHttpsMethods = value; }
        }
        public Dictionary<string, bool> SqlMethods
        {
            get { return m_dicSqlMethods; }
            set { m_dicSqlMethods = value; }
        }
        public System.Collections.Specialized.StringCollection ProcessFiles
        {
            get { return m_colProcessFiles; }
            set { m_colProcessFiles = value; }
        }
        public bool SaveAsStream
        {
            get { return m_bSaveAsStream; }
            set { m_bSaveAsStream = value; }
        }
        public string Folder
        {
            get { return m_strFolder; }
            set { m_strFolder = value; }
        }
        private bool m_bWalkTree = false;

        public bool WalkTree
        {
            get { return m_bWalkTree = false; }
            set { m_bWalkTree = value; }
        }

        public CodeCSharp(System.Collections.Specialized.StringCollection _ProcessFiles, List<string> _ListLogName, Dictionary<string, bool> _HttpsMethods, Dictionary<string, bool> _SqlMethods, string _Folder, bool _SaveAsStream)
        {
            ProcessFiles = _ProcessFiles;
            ListLogName = _ListLogName;
            HttpsMethods = _HttpsMethods;
            SqlMethods = _SqlMethods;
            Folder = _Folder;
            SaveAsStream = _SaveAsStream;
        }
        public bool ProcessFile(FileInfo fi, CodeItems ci, bool bBackup = false, bool bShowFile = false, bool bScanForILog = false)
        {
            bool bAddAutoLog = ((ci & CodeItems.AutoLog) == CodeItems.AutoLog);
            bool bTryCatch = ((ci & CodeItems.TryCatch) == CodeItems.TryCatch);
            bool bConstructor = (ci & CodeItems.Constructor) == CodeItems.Constructor;
            bool bMethod = (ci & CodeItems.Method) == CodeItems.Method;
            bool bProperty = (ci & CodeItems.Property) == CodeItems.Property;
            bool bClass = (ci & CodeItems.Class) == CodeItems.Class;
            bool bRetryHttp = (ci & CodeItems.RetryHttp) == CodeItems.RetryHttp;
            bool bRetrySql = (ci & CodeItems.RetrySql) == CodeItems.RetrySql;

            if (!(((bAddAutoLog || bTryCatch) && (bConstructor || bMethod || bProperty || bClass)) ||
                bRetryHttp ||
                bRetrySql))
                throw new ArgumentException("Must select (AddAutoLog and/or TryCatch AND Constructor and/or Method) or Retry Http or Retry Sql.");
            if (fi.Exists)
            {
                bool bUpdated = false;

                Encoding encFile = GetEncoding(fi.FullName);
                String strProgramText = File.ReadAllText(fi.FullName, encFile);
                SyntaxTree tree = CSharpSyntaxTree.ParseText(strProgramText);
                CompilationUnitSyntax root = tree.GetCompilationUnitRoot();
                List<string> lstIzenda = new List<string>() { "Izenda", "AdHoc", "AdHocContext", "Driver" };
                var compilation = CSharpCompilation.Create("Sample", new[] { tree });
                var semanticModel = compilation.GetSemanticModel(tree, true);

                Debug.WriteLine(tree.Length);
                Debug.WriteLine(root.Language);
                if (WalkTree)
                {
                	var walker = new CSharpDeeperWalker();
	                walker.Visit(tree.GetRoot());
                }
                if (root.Language == "C#")
                {
                    var members = tree.GetRoot().DescendantNodes().OfType<MemberDeclarationSyntax>();
                    List<string> lstUsings = new List<string>();
                    if (bTryCatch)
                        lstUsings.Add("System");
                    if (bAddAutoLog)
                        lstUsings.Add("AdvancedLogging.Logging");
                    if (bRetryHttp || bRetrySql)
                        lstUsings.Add("AdvancedLogging.DAL");
                    string fullItemName = "";
                    foreach (var member in members)
                    {
                        if (member is NamespaceDeclarationSyntax)
                        {
                            var NameSpace = member as NamespaceDeclarationSyntax;

                            //NameSpace.Usings
                        }
                        else if (member is ClassDeclarationSyntax)
                        {
                            ClassDeclarationSyntax cds = member as ClassDeclarationSyntax;
                            for (int i = cds.Members.Count - 1; i >= 0; i--)
                            {
                                if (cds.Members[i] is FieldDeclarationSyntax)
                                {
                                    FieldDeclarationSyntax fds = cds.Members[i] as FieldDeclarationSyntax;

                                    //if (fds.Declaration.Type is ILog || fds.Declaration.Type.ToString().ToLower().Contains("ilog"))
                                    if (fds.Declaration.GetType() is ILog || fds.Declaration.Type.ToString().ToLower().Contains("ilog"))
                                    {
                                        if (!m_lstLogName.Contains(fds.Declaration.Variables[0].Identifier.Text))
                                            m_lstLogName.Add(fds.Declaration.Variables[0].Identifier.Text);
                                        strProgramText = strProgramText.Replace(fds.ToFullString(), "");
                                    }
                                }
                            }
                            if (bScanForILog)
                                return true;
                        }
                    }
                    int iCount = 0;
                    foreach (var member in members)
                    {
                        if (member is PropertyDeclarationSyntax)
                        {
                            if ((ci & CodeItems.Property) != CodeItems.Property)
                                continue;

                            var property = member as PropertyDeclarationSyntax;
                            fullItemName = property.Identifier.Text;
                            Debug.WriteLine("Property: " + fullItemName);
                            //if (property.Type is ILog || property.Type.ToString().ToLower().Contains("ilog"))
                            if (property.GetType() is ILog || property.Type.ToString().ToLower().Contains("ilog"))
                            {
                                if (!m_lstLogName.Contains(property.Identifier.Text))
                                    m_lstLogName.Add(property.Identifier.Text);
                                strProgramText = strProgramText.Replace(property.ToFullString(), "");
                                //cds.Members.RemoveAt(i);
                            }
                            else
                            {
                                // Do stuff with the symbol here
                                if (property.AccessorList == null)
                                {
                                    Debug.WriteLine("Skipping Auto Property: " + property.Identifier + ".");
                                }
                                else
                                {
                                    SyntaxList<AccessorDeclarationSyntax> accessors = property.AccessorList.Accessors;

                                    AccessorDeclarationSyntax getter = accessors.FirstOrDefault(ad => ad.Kind() == SyntaxKind.GetAccessorDeclaration);
                                    AccessorDeclarationSyntax setter = accessors.FirstOrDefault(ad => ad.Kind() == SyntaxKind.SetAccessorDeclaration);
                                    if (getter == null && setter == null)
                                        continue;
                                    if (getter == null)
                                    {
                                        Debug.WriteLine("Skipping Auto Implimented 'get'.");
                                    }
                                    else
                                    {
                                        if (getter.Body == null)
                                        {
                                            Debug.WriteLine("Skipping Auto Implimented 'get'.");
                                        }
                                        else
                                        {
                                            //fullItemName = getter.ToString().Replace(getter.Body.ToString(), "");
                                            Debug.WriteLine("Function [Get]: " + fullItemName);
                                            if (ProcessBody(ref root, member, getter.Body, ref strProgramText, ref lstUsings, ci))
                                            {
                                                bUpdated = true;
                                            }
                                        }
                                    }
                                    if (setter == null)
                                    {
                                        Debug.WriteLine("Skipping Auto Implimented 'set'.");
                                    }
                                    else
                                    {
                                        if (setter.Body == null)
                                        {
                                            Debug.WriteLine("Skipping Auto Implimented 'set'.");
                                        }
                                        else
                                        {
                                            //fullItemName = setter.ToString().Replace(setter.Body.ToString(), "");
                                            Debug.WriteLine("Function [Set]: " + fullItemName);
                                            if (ProcessBody(ref root, member, setter.Body, ref strProgramText, ref lstUsings, ci))
                                            {
                                                bUpdated = true;
                                            }
                                        }
                                    }
                                }
                                var fullMethodName = property.Identifier.ToFullString();
                            }
                        }
                        else if (member is ConstructorDeclarationSyntax ||
                                    member is MethodDeclarationSyntax)
                        {
                            ConstructorDeclarationSyntax constructor = null;
                            MethodDeclarationSyntax method = null;
                            /*
                                if (member is ClassDeclarationSyntax)
                                if (member is ConstructorDeclarationSyntax)
                                if (member is MethodDeclarationSyntax)
                                if (member is PropertyDeclarationSyntax)
                                if (member is FieldDeclarationSyntax)
                                if (member is NamespaceDeclarationSyntax)
                                if (member is EnumDeclarationSyntax)
                                if (member is EnumMemberDeclarationSyntax)
                                if (member is EventFieldDeclarationSyntax)
                                if (member is DelegateDeclarationSyntax)
                                if (member is InterfaceDeclarationSyntax)
                            */
                            if (member is ConstructorDeclarationSyntax)
                            {
                                if ((ci & CodeItems.Constructor) != CodeItems.Constructor)
                                    continue;

                                constructor = member as ConstructorDeclarationSyntax;
                                Debug.WriteLine("Method: " + constructor.Identifier);

                                if (constructor.Body == null)
                                    continue;
                                fullItemName = constructor.ToString().Replace(constructor.Body.ToString(), "");
                                Debug.WriteLine("Function: " + fullItemName);
                                if (ProcessBody(ref root, member, constructor.Body, ref strProgramText, ref lstUsings, ci))
                                {
                                    bUpdated = true;
                                }
                            }
                            else if (member is MethodDeclarationSyntax)
                            {
                                if ((ci & CodeItems.Method) != CodeItems.Method)
                                    continue;

                                method = member as MethodDeclarationSyntax;
                                fullItemName = method.Identifier.Text;
                                Debug.WriteLine("Method: " + fullItemName);

                                if (method.Body == null)
                                    continue;

                                fullItemName = method.ToString().Replace(method.Body.ToString(), "");
                                Debug.WriteLine("Function: " + fullItemName);
                                if (ProcessBody(ref root, member, method.Body, ref strProgramText, ref lstUsings, ci))
                                {
                                    bUpdated = true;
                                }
                            }
                        }
                        else
                        {
                            Debug.WriteLine(member.GetType().FullName);
                            if (member is NamespaceDeclarationSyntax)
                            { }
                            else if (member is InterfaceDeclarationSyntax)
                            { }
                            else if (member is ClassDeclarationSyntax)
                            {
                                ClassDeclarationSyntax cds = member as ClassDeclarationSyntax;
                                if (cds.BaseList != null)
                                {
                                    if ((ci & CodeItems.Class) == CodeItems.Class)
                                    {

                                        if (cds.BaseList.ToString().Contains(" ServiceBase"))
                                        {
                                            strProgramText = strProgramText.Replace(" ServiceBase", " WinServiceBase");
                                            if (!lstUsings.Contains("AdvancedLogging.BLL"))
                                                lstUsings.Add("AdvancedLogging.BLL");
                                            if (!m_lstLogName.Contains("Log"))
                                                m_lstLogName.Add("Log");
                                        }
                                        if (cds.BaseList.ToString().Contains("System.Web.HttpApplication"))
                                        {
                                            strProgramText = strProgramText.Replace("System.Web.HttpApplication", "WebServiceBase");
                                            if (!lstUsings.Contains("AdvancedLogging.BLL"))
                                                lstUsings.Add("AdvancedLogging.BLL");
                                        }
                                        if (cds.BaseList.ToString().Contains("System.Web.UI.Page"))
                                        {
                                            strProgramText = strProgramText.Replace("System.Web.UI.Page", "BasePage");
                                        }
                                    }
                                    for (int i = cds.Members.Count - 1; i >= 0; i--)
                                    {
                                        if (cds.Members[i] is FieldDeclarationSyntax)
                                        {
                                            FieldDeclarationSyntax fds = cds.Members[i] as FieldDeclarationSyntax;

                                            //if (fds.Declaration.Type is ILog || fds.Declaration.Type.ToString().ToLower().Contains("ilog"))
                                            if (fds.Declaration.GetType() is ILog || fds.Declaration.Type.ToString().ToLower().Contains("ilog"))
                                            {
                                                if (!m_lstLogName.Contains(fds.Declaration.Variables[0].Identifier.Text))
                                                    m_lstLogName.Add(fds.Declaration.Variables[0].Identifier.Text);
                                                strProgramText = strProgramText.Replace(fds.ToFullString(), "");
                                                //cds.Members.RemoveAt(i);
                                            }
                                            // Do stuff with the symbol here
                                        }
                                    }
                                }
                            }
                            else if (member is FieldDeclarationSyntax)
                            {
                                FieldDeclarationSyntax fds = member as FieldDeclarationSyntax;

                                //if (fds.Declaration.Type is ILog)
                                if (fds.Declaration.GetType() is ILog)
                                {
                                    //m_dicLogName.Add(fds.Declaration.Id)
                                    //cds.Members.Remove(vMember);
                                }
                            }
                            else if (member is EnumDeclarationSyntax)
                            { }
                            else if (member is EnumMemberDeclarationSyntax)
                            { }
                            else if (member is EventFieldDeclarationSyntax)
                            { }
                            else if (member is DelegateDeclarationSyntax)
                            { }
                        }
                        iCount++;
                        UpdateProgress(fi.FullName, "Code", iCount, members.Count());
                        Application.DoEvents();
                    }
                    if (bRetryHttp)
                    {
                        if (m_dicHttpsMethods.Keys.Any(strProgramText.Contains))
                        {
                            foreach (string strKey in m_dicHttpsMethods.Keys)
                            {
                                if (!m_dicHttpsMethods[strKey])
                                    continue;
                                string strHttpCommand = "." + strKey + "(";
                                int iPos = 0;
                                int iItems = 0;
                                if (ProgressEventsEnabled)
                                {
                                    while (iPos > -1)
                                    {
                                        iPos = strProgramText.IndexOf(strHttpCommand, iPos + 1);
                                        if (iPos > -1)
                                        {
                                            int iPosClose = strProgramText.IndexOf(")", iPos);

                                            if (strProgramText.Substring(iPos, iPosClose - iPos).Contains(">("))
                                            {
                                                iPosClose = strProgramText.IndexOf(")", iPosClose + 1);
                                            }
                                            if (!strProgramText.Substring(iPos, iPosClose - iPos).Contains("MaxAutoRetriesHttp"))
                                            {
                                                if (strProgramText.Substring(iPos, iPosClose - iPos + 1) == strHttpCommand + ")")
                                                {
                                                    iPos += "ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp)".Length;
                                                }
                                                else
                                                {
                                                    iPos += ", ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp)".Length;
                                                }
                                                iItems++;
                                            }
                                        }
                                    }
                                }
                                iPos = 0;
                                while (iPos > -1)
                                {
                                    iPos = strProgramText.IndexOf(strHttpCommand, iPos + 1);
                                    if (iPos > -1)
                                    {
                                        int iPosClose = strProgramText.IndexOf(")", iPos);

                                        if (strProgramText.Substring(iPos, iPosClose - iPos).Contains(">("))
                                        {
                                            iPosClose = strProgramText.IndexOf(")", iPosClose + 1);
                                        }
                                        if (!strProgramText.Substring(iPos, iPosClose - iPos).Contains("MaxAutoRetriesHttp"))
                                        {
                                            if (strProgramText.Substring(iPos, iPosClose - iPos + 1) == strHttpCommand + ")")
                                            {
                                                strProgramText = strProgramText.Replace(strProgramText.Substring(iPos, iPosClose - iPos + 1), strProgramText.Substring(iPos, iPosClose - iPos) + "ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp)");
                                                iPos += "ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp)".Length;
                                            }
                                            else
                                            {
                                                strProgramText = strProgramText.Replace(strProgramText.Substring(iPos, iPosClose - iPos + 1), strProgramText.Substring(iPos, iPosClose - iPos) + ", ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp)");
                                                iPos += ", ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp)".Length;
                                            }
                                            iCount++;
                                            UpdateProgress(fi.FullName, "Http", iCount, iItems);
                                            Application.DoEvents();
                                            bUpdated = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (bRetrySql)
                    {
                        //if (strProgramText.Contains(".ExecuteNonQuery(")
                        //    || strProgramText.Contains(".ExecuteReader(")
                        //    || strProgramText.Contains(".ExecuteScalar(")
                        //    || strProgramText.Contains(".Fill("))
                        //{
                        //    foreach (string strSqlCommand in new string[] { ".ExecuteNonQuery(", ".ExecuteReader(", ".ExecuteScalar(", ".Fill(" })

                        if (m_dicSqlMethods.Keys.Any(strProgramText.Contains))
                        {
                            foreach (string strKey in m_dicSqlMethods.Keys)
                            {
                                if (!m_dicSqlMethods[strKey])
                                    continue;
                                string strSqlCommand = "." + strKey + "(";
                                int iPos = 0;
                                int iItems = 0;
                                if (ProgressEventsEnabled)
                                {
                                    while (iPos > -1)
                                    {
                                        iPos = strProgramText.IndexOf(strSqlCommand, iPos + 1);
                                        if (iPos > -1)
                                        {
                                            //                . - iPos = 250
                                            //                  
                                            //       SqlHelper.ExecuteScalar
                                            if (strProgramText.Substring(iPos - "Helper".Length, "Helper".Length).ToLower() == "Helper".ToLower())
                                            {
                                                // Skip Processing "*Helper"
                                                Debug.WriteLine("Skip Processing '*Helper'");
                                            }
                                            else if (strProgramText.Substring(iPos - "x => x.".Length, "x => x.".Length).Contains(" => "))
                                            {
                                                // x => x.ExecuteReader
                                                // Skip Processing "*Helper"
                                                Debug.WriteLine("Skip Processing '*Helper'");
                                            }
                                            // SqlHelperStatic.ExecuteScalar
                                            // SqlHelperStatic.ExecuteScalar
                                            else if (strProgramText.Substring(iPos - "SqlHelperStatic".Length, "SqlHelperStatic".Length) == "SqlHelperStatic")
                                            {
                                                // Skip Processing "SqlHelperStatic"
                                                Debug.WriteLine("Skip Processing 'SqlHelperStatic'");
                                            }
                                            // Izenda.AdHoc.AdHocContext.Driver
                                            else if (lstIzenda.Any(strProgramText.Substring(iPos - "Izenda.AdHoc.AdHocContext.Driver".Length, "Izenda.AdHoc.AdHocContext.Driver".Length).Contains))
                                            {
                                                // Skip Processing "Izenda"
                                                Debug.WriteLine("Skip Processing ''");
                                            }
                                            else
                                            {
                                                int iPosClose = strProgramText.IndexOf(")", iPos);
                                                if (!strProgramText.Substring(iPos, iPosClose - iPos).Contains("MaxAutoRetriesSql"))
                                                {
                                                    if (strProgramText.Substring(iPos, iPosClose - iPos + 1) == strSqlCommand + ")")
                                                    {
                                                        iPos += "ApplicationSettings.MaxAutoRetriesSql, ApplicationSettings.AutoRetrySleepMsSql, ApplicationSettings.AutoTimeoutIncrementSecondsSql)".Length;
                                                    }
                                                    else
                                                    {
                                                        iPos += ", ApplicationSettings.MaxAutoRetriesSql, ApplicationSettings.AutoRetrySleepMsSql, ApplicationSettings.AutoTimeoutIncrementSecondsSql)".Length;
                                                    }
                                                    iItems++;
                                                }
                                            }
                                        }
                                    }
                                }
                                iPos = 0;
                                while (iPos > -1)
                                {
                                    iPos = strProgramText.IndexOf(strSqlCommand, iPos + 1);
                                    if (iPos > -1)
                                    {
                                        //                . - iPos = 250
                                        //                  
                                        //       SqlHelper.ExecuteScalar
                                        if (strProgramText.Substring(iPos - "Helper".Length, "Helper".Length).ToLower() == "Helper".ToLower())
                                        {
                                            // Skip Processing "*Helper"
                                            Debug.WriteLine("Skip Processing '*Helper'");
                                        }
                                        else if (strProgramText.Substring(iPos - "x => x.".Length, "x => x.".Length).Contains(" => "))
                                        {
                                            // x => x.ExecuteReader
                                            // Skip Processing "*Helper"
                                            Debug.WriteLine("Skip Processing '*Helper'");
                                        }
                                        // SqlHelperStatic.ExecuteScalar
                                        // SqlHelperStatic.ExecuteScalar
                                        else if (strProgramText.Substring(iPos - "SqlHelperStatic".Length, "SqlHelperStatic".Length) == "SqlHelperStatic")
                                        {
                                            // Skip Processing "SqlHelperStatic"
                                            Debug.WriteLine("Skip Processing 'SqlHelperStatic'");
                                        }
                                        // Izenda.AdHoc.AdHocContext.Driver
                                        else if (lstIzenda.Any(strProgramText.Substring(iPos - "Izenda.AdHoc.AdHocContext.Driver".Length, "Izenda.AdHoc.AdHocContext.Driver".Length).Contains))
                                        {
                                            // Skip Processing "Izenda"
                                            Debug.WriteLine("Skip Processing ''");
                                        }
                                        else
                                        {
                                            int iPosClose = strProgramText.IndexOf(")", iPos);
                                            if (!strProgramText.Substring(iPos, iPosClose - iPos).Contains("MaxAutoRetriesSql"))
                                            {
                                                if (strProgramText.Substring(iPos, iPosClose - iPos + 1) == strSqlCommand + ")")
                                                {
                                                    strProgramText = strProgramText.Replace(strProgramText.Substring(iPos, iPosClose - iPos + 1), strProgramText.Substring(iPos, iPosClose - iPos) + "ApplicationSettings.MaxAutoRetriesSql, ApplicationSettings.AutoRetrySleepMsSql, ApplicationSettings.AutoTimeoutIncrementSecondsSql)");
                                                    iPos += "ApplicationSettings.MaxAutoRetriesSql, ApplicationSettings.AutoRetrySleepMsSql, ApplicationSettings.AutoTimeoutIncrementSecondsSql)".Length;
                                                }
                                                else
                                                {
                                                    strProgramText = strProgramText.Replace(strProgramText.Substring(iPos, iPosClose - iPos + 1), strProgramText.Substring(iPos, iPosClose - iPos) + ", ApplicationSettings.MaxAutoRetriesSql, ApplicationSettings.AutoRetrySleepMsSql, ApplicationSettings.AutoTimeoutIncrementSecondsSql)");
                                                    iPos += ", ApplicationSettings.MaxAutoRetriesSql, ApplicationSettings.AutoRetrySleepMsSql, ApplicationSettings.AutoTimeoutIncrementSecondsSql)".Length;
                                                }
                                                iCount++;
                                                UpdateProgress(fi.FullName, "Sql", iCount, iItems);
                                                Application.DoEvents();
                                                bUpdated = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (bUpdated)
                    {
                        if (bBackup)
                        {
                            if (!Directory.Exists(Path.Combine(fi.DirectoryName, "backup")))
                            {
                                Directory.CreateDirectory(Path.Combine(fi.DirectoryName, "backup"));
                            }
                            fi.CopyTo(Path.Combine(fi.DirectoryName, "backup", fi.Name), true);
                        }

                        bool bCtrlKD = false;
                        if (bCtrlKD)
                        {
                            SyntaxTree treeNew = CSharpSyntaxTree.ParseText(strProgramText);
                            SyntaxNode rootNew = treeNew.GetRoot().NormalizeWhitespace();
                            strProgramText = rootNew.ToFullString();
                            Debug.WriteLine(strProgramText);

                            //Microsoft.CodeAnalysis.Host.HostServices hs = new 
                            //Microsoft.CodeAnalysis.Workspace workspace = Microsoft.CodeAnalysis.Workspace.GetWorkspaceRegistration("");
                            //var formattedResult = Formatter.Format(treeNew.GetRoot(), workspace);
                        }

                        File.WriteAllText(fi.FullName, strProgramText, encFile);
                        //try
                        //{
                        //    File.WriteAllText(fi.FullName + ":Status", "<Status>Processed</Status>");
                        //}
                        //catch (Exception ex)
                        //{

                        //}
                        if (!m_colProcessFiles.Contains(fi.FullName.Substring(Folder.Trim().Length + 1)))
                            m_colProcessFiles.Add(fi.FullName.Substring(Folder.Trim().Length + 1));
                        if (fi.AlternateDataStreamExists("Status"))
                        {
                            Debug.WriteLine("Found Status stream:");

                            AlternateDataStreamInfo s = fi.GetAlternateDataStream("Status", FileMode.Open);
                            using (TextReader reader = s.OpenText())
                            {
                                Debug.WriteLine(reader.ReadToEnd());
                            }
                            if (m_bSaveAsStream)
                            {
                                // Delete the stream:
                                s.Delete();

                                s = fi.GetAlternateDataStream("Status", FileMode.OpenOrCreate);
                                using (StreamWriter sw = new StreamWriter(s.OpenWrite()))
                                {
                                    sw.WriteLine("<Status>Processed</Status>");
                                }
                            }
                        }
                        else if (m_bSaveAsStream)
                        {
                            AlternateDataStreamInfo s = fi.GetAlternateDataStream("Status", FileMode.OpenOrCreate);
                            using (StreamWriter sw = new StreamWriter(s.OpenWrite()))
                            {
                                sw.WriteLine("<Status>Processed</Status>");
                            }
                        }
                    }
                }
                if (bShowFile && File.Exists(fi.FullName))
                {
                    Process p = new Process();
                    p.StartInfo.FileName = "notepad.exe";
                    p.StartInfo.Arguments = fi.FullName;
                    p.Start();
                }

                return bUpdated;
            }
            else
            {
                return false;
            }
        }
        private bool ProcessBody(ref CompilationUnitSyntax root, MemberDeclarationSyntax member, BlockSyntax oBody, ref string strProgramText, ref List<string> lstUsings, CodeItems ci, bool AddLineLogging = false)
        {
            bool bUpdated = false;
            bool bAddAutoLog = ((ci & CodeItems.AutoLog) == CodeItems.AutoLog);
            bool bTryCatch = ((ci & CodeItems.TryCatch) == CodeItems.TryCatch);
            bool bConstructor = (ci & CodeItems.Constructor) == CodeItems.Constructor;
            bool bMethod = (ci & CodeItems.Method) == CodeItems.Method;
            bool bProperty = (ci & CodeItems.Property) == CodeItems.Property;

            if (oBody.Statements.Count == 0)
                return bUpdated;
            var body = oBody.ToString();
#if DEBUG
            if (AddLineLogging)
            {
                // Line for Line Debug Statements Testing
                string strTempReplacement = "";
                foreach (var vStatement in oBody.Statements)
                {
                    strTempReplacement += "vAutoLogFunction.WriteDebug(\"" + vStatement.ToString().Replace("\"", "\\\"") + "\");" + Environment.NewLine;
                    strTempReplacement += vStatement.ToString() + Environment.NewLine;
                }
                Debug.WriteLine(strTempReplacement);
            }
#endif
            if ((ci & CodeItems.ModifyEmptyBody) == CodeItems.ModifyEmptyBody)
            {
                if (body.Replace(" ", "").Replace(Environment.NewLine, "") == (oBody.OpenBraceToken.ToString() + oBody.CloseBraceToken.ToString()))
                    return bUpdated;
            }

            String strReplaceFind = "";
            String strReplaceWith = "";
            String strVariables = "";
#if INDENT_SPACES
            Int16 iBaseIndent = 3;
            string strBaseIndent = "    ";
#else
            Int16 iBaseIndent = 3;
            string strBaseIndent = "\t";
#endif

            if (member is ConstructorDeclarationSyntax)
            {
                ConstructorDeclarationSyntax constructor = member as ConstructorDeclarationSyntax;
                if (constructor != null)
                {
                    if (constructor.ParameterList != null)
                    {
                        foreach (var vParameter in constructor.ParameterList.Parameters)
                        {
                            if (vParameter.Modifiers != null)
                            {
                                // Need to exclude OUT parameters
                                if (vParameter.Modifiers.Any(p => p.Text == "out"))
                                    continue;
                            }
                            if (strVariables == "")
                                strVariables = "new " + oBody.OpenBraceToken.ToString() + " ";
                            else
                                strVariables += ", ";
                            strVariables += vParameter.Identifier.Value;
                            Debug.WriteLine((vParameter.Identifier.Value));
                        }

                        if (strVariables != "")
                            strVariables += " " + oBody.CloseBraceToken.ToString() + "";
                    }
                }
            }
            else if (member is MethodDeclarationSyntax)
            {
                MethodDeclarationSyntax method = member as MethodDeclarationSyntax;
                if (method.ParameterList != null)
                {
                    foreach (var vParameter in method.ParameterList.Parameters)
                    {
                        if (vParameter.Modifiers != null)
                        {
                            // Need to exclude OUT parameters
                            if (vParameter.Modifiers.Any(p => p.Text == "out"))
                                continue;
                        }
                        if (strVariables == "")
                            strVariables = "new " + oBody.OpenBraceToken.ToString() + " ";
                        else
                            strVariables += ", ";
                        strVariables += vParameter.Identifier.Value;
                        Debug.WriteLine((vParameter.Identifier.Value));
                    }

                    if (strVariables != "")
                        strVariables += " " + oBody.CloseBraceToken.ToString() + "";
                }
            }
            else if (member is PropertyDeclarationSyntax)
            {
                iBaseIndent = 4;
            }
            strReplaceFind = body;
            string strBody = body;
            if (bTryCatch && !body.Replace(" ", "").Contains("catch(ExceptionExOuter)")) //! body.Replace(" ", "").Replace(Environment.NewLine, "").StartsWith(oBody.OpenBraceToken.ToString() + "try"))
            {
                if (body.Replace(" ", "").Replace(Environment.NewLine, "").StartsWith(oBody.OpenBraceToken.ToString() + "using(varvAutoLogFunction=newAutoLogFunction"))
                {
                    if (oBody.Statements[0] is UsingStatementSyntax)
                    {
                        bool bAddTry = true;
                        UsingStatementSyntax uss = (UsingStatementSyntax)oBody.Statements[0];
                        if (uss.Statement is BlockSyntax)
                        {
                            BlockSyntax bs = (BlockSyntax)uss.Statement;
                            Debug.WriteLine(bs.Statements[0].ToString());
                            bAddTry = !(bs.Statements[0].ToString().StartsWith("try") && bs.Statements[0].ToString().Replace(" ", "").Contains("catch(ExceptionExOuter)"));
                        }
                        else if (uss.Statement.ToString().Replace(" ", "").Replace(Environment.NewLine, "").StartsWith(oBody.OpenBraceToken.ToString() + "try"))
                        {
                            bAddTry = false;
                        }
                        if (bAddTry)
                        {
                            Debug.WriteLine("Stop");
                            strReplaceWith = oBody.OpenBraceToken.ToString() + Environment.NewLine;
                            strReplaceWith += Indention(iBaseIndent, strBaseIndent) + "try" + Environment.NewLine;
                            string strUSS = uss.Statement.ToString().Replace(Environment.NewLine, Environment.NewLine + Indention(1, strBaseIndent)) + Environment.NewLine;
                            foreach (string strLogName in m_lstLogName)
                            {
                                if (strUSS.Contains(strLogName))
                                {
                                    foreach (string strToken in new string[] { ".", "?." })
                                    {
                                        strUSS = strUSS.Replace(strLogName + strToken + "Info(", "vAutoLogFunction.WriteLog(");
                                        strUSS = strUSS.Replace(strLogName + strToken + "Warn(", "vAutoLogFunction.WriteWarn(");
                                        strUSS = strUSS.Replace(strLogName + strToken + "Error(", "vAutoLogFunction.WriteError(");
                                        strUSS = strUSS.Replace(strLogName + strToken + "Debug(", "vAutoLogFunction.WriteDebug(");
                                        strUSS = strUSS.Replace(strLogName + strToken + "InfoFormat(", "vAutoLogFunction.WriteLogFormat(");
                                        strUSS = strUSS.Replace(strLogName + strToken + "WarnFormat(", "vAutoLogFunction.WriteWarnFormat(");
                                        strUSS = strUSS.Replace(strLogName + strToken + "ErrorFormat(", "vAutoLogFunction.WriteErrorFormat(");
                                        strUSS = strUSS.Replace(strLogName + strToken + "DebugFormat(", "vAutoLogFunction.WriteDebugFormat(");
                                    }
                                }
                            }
                            strReplaceWith += Indention(iBaseIndent, strBaseIndent) + strUSS;
                            strReplaceWith += Indention(iBaseIndent, strBaseIndent) + "catch (Exception ExOuter)" + Environment.NewLine;
                            strReplaceWith += Indention(iBaseIndent, strBaseIndent) + oBody.OpenBraceToken.ToString() + Environment.NewLine;
                            if (strVariables.Length == 0)
                                strReplaceWith += Indention(iBaseIndent + 2, strBaseIndent) + "vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), bError:true, _ex:ExOuter);" + Environment.NewLine;
                            else
                                strReplaceWith += Indention(iBaseIndent + 2, strBaseIndent) + "vAutoLogFunction.LogFunction(" + strVariables + "System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);" + Environment.NewLine;
                            strReplaceWith += Indention(iBaseIndent + 2, strBaseIndent) + "throw;" + Environment.NewLine;
                            strReplaceWith += Indention(iBaseIndent, strBaseIndent) + oBody.CloseBraceToken.ToString() + Environment.NewLine;
                            strReplaceWith += Indention(iBaseIndent - 1, strBaseIndent) + oBody.CloseBraceToken.ToString();
                            strReplaceWith = strBody.Replace(uss.Statement.ToString(), strReplaceWith);
                            strBody = strReplaceWith;
                        }
                    }
                    Debug.WriteLine("Stop");
                }
                else
                {
                    strReplaceWith = oBody.OpenBraceToken.ToString() + Environment.NewLine;
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + "try" + Environment.NewLine;
                    strBody = strBody.Replace(Environment.NewLine, Environment.NewLine + Indention(1, strBaseIndent)) + Environment.NewLine;
                    foreach (string strLogName in m_lstLogName)
                    {
                        if (strBody.Contains(strLogName))
                        {
                            foreach (string strToken in new string[] { ".", "?." })
                            {
                                if (bAddAutoLog)
                                {
                                    strBody = strBody.Replace(strLogName + strToken + "Info(", "vAutoLogFunction.WriteLog(");
                                    strBody = strBody.Replace(strLogName + strToken + "Warn(", "vAutoLogFunction.WriteWarn(");
                                    strBody = strBody.Replace(strLogName + strToken + "Error(", "vAutoLogFunction.WriteError(");
                                    strBody = strBody.Replace(strLogName + strToken + "Debug(", "vAutoLogFunction.WriteDebug(");
                                    strBody = strBody.Replace(strLogName + strToken + "InfoFormat(", "vAutoLogFunction.WriteLogFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "WarnFormat(", "vAutoLogFunction.WriteWarnFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "ErrorFormat(", "vAutoLogFunction.WriteErrorFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "DebugFormat(", "vAutoLogFunction.WriteDebugFormat(");
                                }
                                else
                                {
                                    strBody = strBody.Replace(strLogName + strToken + "Info(", "LoggingUtils.WriteLog(");
                                    strBody = strBody.Replace(strLogName + strToken + "Warn(", "LoggingUtils.WriteWarn(");
                                    strBody = strBody.Replace(strLogName + strToken + "Error(", "LoggingUtils.WriteError(");
                                    strBody = strBody.Replace(strLogName + strToken + "Debug(", "LoggingUtils.WriteDebug(");
                                    strBody = strBody.Replace(strLogName + strToken + "InfoFormat(", "LoggingUtils.WriteLogFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "WarnFormat(", "LoggingUtils.WriteWarnFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "ErrorFormat(", "LoggingUtils.WriteErrorFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "DebugFormat(", "LoggingUtils.WriteDebugFormat(");
                                }
                            }
                        }
                    }
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + strBody;
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + "catch (Exception ExOuter)" + Environment.NewLine;
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + oBody.OpenBraceToken.ToString() + Environment.NewLine;
                    if (bAddAutoLog)
                    {
                        strReplaceWith += Indention(iBaseIndent + 1, strBaseIndent) + "vAutoLogFunction.LogFunction(" + strVariables + ", System.Reflection.MethodBase.GetCurrentMethod(), bError:true, _ex:ExOuter);" + Environment.NewLine;
                    }
                    else
                    {
                        strReplaceWith += Indention(iBaseIndent + 1, strBaseIndent) + "LoggingUtils.LogFunction(" + strVariables + ", System.Reflection.MethodBase.GetCurrentMethod(), bError:true, _ex:ExOuter);" + Environment.NewLine;
                    }
                    strReplaceWith += Indention(iBaseIndent + 1, strBaseIndent) + "throw;" + Environment.NewLine;
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + oBody.CloseBraceToken.ToString() + Environment.NewLine;
                    strReplaceWith += Indention(iBaseIndent - 1, strBaseIndent) + oBody.CloseBraceToken.ToString();
                    strBody = strReplaceWith;
                }
            }
            if (bAddAutoLog && !body.Replace(" ", "").Replace(Environment.NewLine, "").StartsWith(oBody.OpenBraceToken.ToString() + "using(varvAutoLogFunction=newAutoLogFunction"))
            {
                if (body.Contains("AutoLogFunction("))
                {
                    // Add strReplaceWith inside existing AutoLogFunction(
                    Debug.WriteLine("Stop");
                }
                else
                {
                    strReplaceWith = oBody.OpenBraceToken.ToString() + Environment.NewLine;
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + "using (var vAutoLogFunction = new AutoLogFunction(" + strVariables + "))" + Environment.NewLine;
                    strBody = strBody.Replace(Environment.NewLine, Environment.NewLine + Indention(1, strBaseIndent)) + Environment.NewLine;
                    foreach (string strLogName in m_lstLogName)
                    {
                        if (strBody.Contains(strLogName))
                        {
                            foreach (string strToken in new string[] { ".", "?." })
                            {
                                if (bAddAutoLog)
                                {
                                    strBody = strBody.Replace(strLogName + strToken + "Info(", "vAutoLogFunction.WriteLog(");
                                    strBody = strBody.Replace(strLogName + strToken + "Warn(", "vAutoLogFunction.WriteWarn(");
                                    strBody = strBody.Replace(strLogName + strToken + "Error(", "vAutoLogFunction.WriteError(");
                                    strBody = strBody.Replace(strLogName + strToken + "Debug(", "vAutoLogFunction.WriteDebug(");
                                    strBody = strBody.Replace(strLogName + strToken + "InfoFormat(", "vAutoLogFunction.WriteLogFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "WarnFormat(", "vAutoLogFunction.WriteWarnFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "ErrorFormat(", "vAutoLogFunction.WriteErrorFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "DebugFormat(", "vAutoLogFunction.WriteDebugFormat(");
                                }
                                else
                                {
                                    strBody = strBody.Replace(strLogName + strToken + "Info(", "LoggingUtils.WriteLog(");
                                    strBody = strBody.Replace(strLogName + strToken + "Warn(", "LoggingUtils.WriteWarn(");
                                    strBody = strBody.Replace(strLogName + strToken + "Error(", "LoggingUtils.WriteError(");
                                    strBody = strBody.Replace(strLogName + strToken + "Debug(", "LoggingUtils.WriteDebug(");
                                    strBody = strBody.Replace(strLogName + strToken + "InfoFormat(", "LoggingUtils.WriteLogFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "WarnFormat(", "LoggingUtils.WriteWarnFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "ErrorFormat(", "LoggingUtils.WriteErrorFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "DebugFormat(", "LoggingUtils.WriteDebugFormat(");
                                }
                            }
                        }
                    }
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + strBody;
                    strReplaceWith += Indention(iBaseIndent - 1, strBaseIndent) + oBody.CloseBraceToken.ToString();
                }
            }
            else if (strReplaceWith.Length > 0)
            {
                if (body.Replace(" ", "").Replace(Environment.NewLine, "").StartsWith(oBody.OpenBraceToken.ToString() + "using(varvAutoLogFunction=newAutoLogFunction"))
                {
                    Debug.WriteLine("Stop");
                }
            }

            if (strReplaceWith.Length > 0)
            {
                foreach (string strUsing in lstUsings)
                {
                    NameSyntax uMHSUtils = SyntaxFactory.IdentifierName(strUsing);

                    string strUsingStatement = "using " + uMHSUtils.ToFullString() + ";";

                    if (!root.Usings.Any(x => x.ToFullString() == strUsingStatement) &&
                        !strProgramText.Contains(strUsingStatement))
                    {
                        UsingDirectiveSyntax obj = SyntaxFactory.UsingDirective(uMHSUtils);
                        var newusing = root.Usings.Add(obj);
                        String strUsings = "";
                        if (root.Usings.Count > 0)
                            strUsings += "using " + root.Usings[root.Usings.Count - 1].Name + ";" + Environment.NewLine;

                        Debug.WriteLine("Adding: " + strUsingStatement + " ...");
                        if (strUsings.Length > 0)
                        {
                            strProgramText = strProgramText.Replace(strUsings, strUsings + strUsingStatement + Environment.NewLine);
                        }
                        else
                        {
                            strProgramText = strUsingStatement + Environment.NewLine + Environment.NewLine + strProgramText;
                        }
                    }
                    else
                    {
                        if (!root.Usings.ToString().Contains(strUsingStatement) && !strProgramText.Contains(strUsingStatement))
                        {
                            Debugger.Break();
                        }
                    }
                }
                strProgramText = strProgramText.Replace(strReplaceFind, strReplaceWith);
                bUpdated = true;

                Debug.WriteLine("Find:     " + strReplaceFind);
                Debug.WriteLine("Replace:  " + strReplaceWith);
            }
            return bUpdated;
        }

        private string Indention(int iLevels, string strIndentString = "")
        {
            if (iLevels == 0 || strIndentString == "")
                return "";
            string strNewIndent = "";
            foreach (char ch in strIndentString)
            {
                strNewIndent += new string(ch, iLevels);
            }
            return strNewIndent;
        }
		
        private static Encoding GetEncoding(string filename)
        {
            // This is a direct quote from MSDN:  
            // The CurrentEncoding value can be different after the first
            // call to any Read method of StreamReader, since encoding
            // autodetection is not done until the first call to a Read method.

            using (var reader = new StreamReader(filename, Encoding.Default, true))
            {
                if (reader.Peek() >= 0) // you need this!
                    reader.Read();

                return reader.CurrentEncoding;
            }
        }
    }
}
