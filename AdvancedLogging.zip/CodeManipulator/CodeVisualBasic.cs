﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.VisualBasic;
using Microsoft.CodeAnalysis.VisualBasic.Syntax;
using static CodeManipulator.frmMain;
using Trinet.Core.IO.Ntfs;
using System.Windows.Forms;

namespace CodeManipulator
{
    class CodeVisualBasic : CodeBase
    {
        private System.Collections.Specialized.StringCollection m_colProcessFiles = new System.Collections.Specialized.StringCollection();
        private List<string> m_lstLogName = new List<string>();
        private List<string> m_lstDetailedLoggingFunctions = new List<string>();
        private Dictionary<string, bool> m_dicHttpsMethods = new Dictionary<string, bool>();
        private Dictionary<string, bool> m_dicSqlMethods = new Dictionary<string, bool>();
        private bool m_bSaveAsStream = false;
        private string m_strFolder = "";

        public List<string> ListLogName
        {
            get { return m_lstLogName; }
            set { m_lstLogName = value; }
        }
        public List<string> DetailedLoggingFunctions
        {
            get { return m_lstDetailedLoggingFunctions; }
            set { m_lstDetailedLoggingFunctions = value; }
        }
        public Dictionary<string, bool> HttpsMethods
        {
            get { return m_dicHttpsMethods; }
            set { m_dicHttpsMethods = value; }
        }
        public Dictionary<string, bool> SqlMethods
        {
            get { return m_dicSqlMethods; }
            set { m_dicSqlMethods = value; }
        }
        public System.Collections.Specialized.StringCollection ProcessFiles
        {
            get { return m_colProcessFiles; }
            set { m_colProcessFiles = value; }
        }
        public bool SaveAsStream
        {
            get { return m_bSaveAsStream; }
            set { m_bSaveAsStream = value; }
        }
        public string Folder
        {
            get { return m_strFolder; }
            set { m_strFolder = value; }
        }
        private bool m_bWalkTree = false;

        public bool WalkTree
        {
            get { return m_bWalkTree = false; }
            set { m_bWalkTree = value; }
        }

        public CodeVisualBasic(System.Collections.Specialized.StringCollection _ProcessFiles, List<string> _ListLogName, Dictionary<string, bool> _HttpsMethods, Dictionary<string, bool> _SqlMethods, string _Folder, bool _SaveAsStream)
        {
            ProcessFiles = _ProcessFiles;
            ListLogName = _ListLogName;
            HttpsMethods = _HttpsMethods;
            SqlMethods = _SqlMethods;
            Folder = _Folder;
            SaveAsStream = _SaveAsStream;
        }
        public bool ProcessFile(FileInfo fi, CodeItems ci, bool bBackup = false, bool bShowFile = false, bool bScanForILog = false)
        {
            bool bAddAutoLog = ((ci & CodeItems.AutoLog) == CodeItems.AutoLog);
            bool bTryCatch = ((ci & CodeItems.TryCatch) == CodeItems.TryCatch);
            bool bConstructor = (ci & CodeItems.Constructor) == CodeItems.Constructor;
            bool bMethod = (ci & CodeItems.Method) == CodeItems.Method;
            bool bProperty = (ci & CodeItems.Property) == CodeItems.Property;
            bool bClass = (ci & CodeItems.Class) == CodeItems.Class;
            bool bRetryHttp = (ci & CodeItems.RetryHttp) == CodeItems.RetryHttp;
            bool bRetrySql = (ci & CodeItems.RetrySql) == CodeItems.RetrySql;

            if (!(((bAddAutoLog || bTryCatch) && (bConstructor || bMethod || bProperty || bClass)) ||
                bRetryHttp ||
                bRetrySql))
                throw new ArgumentException("Must select (AddAutoLog and/or TryCatch AND Constructor and/or Method) or Retry Http or Retry Sql.");
            if (fi.Exists)
            {
                bool bUpdated = false;

                Encoding encFile = GetEncoding(fi.FullName);
                String strProgramText = File.ReadAllText(fi.FullName, encFile);
                SyntaxTree tree = VisualBasicSyntaxTree.ParseText(strProgramText);
                CompilationUnitSyntax root = tree.GetCompilationUnitRoot();
                List<string> lstIzenda = new List<string>() { "Izenda", "AdHoc", "AdHocContext", "Driver" };
                var compilation = VisualBasicCompilation.Create("Sample", new[] { tree });
                var semanticModel = compilation.GetSemanticModel(tree, true);

                Debug.WriteLine(tree.Length);
                Debug.WriteLine(root.Language);
                if (WalkTree)
                {
                    var walker = new VBDeeperWalker();
                    walker.Visit(tree.GetRoot());
                }
                if (root.Language == "Visual Basic")
                {
                    var members = tree.GetRoot().DescendantNodes().OfType<StatementSyntax>();
                    List<string> lstUsings = new List<string>();
                    if (bTryCatch)
                        lstUsings.Add("System");
                    if (bAddAutoLog)
                        lstUsings.Add("AdvancedLogging.Logging");
                    if (bRetryHttp || bRetrySql)
                        lstUsings.Add("AdvancedLogging.DAL");
                    string fullItemName = "";

                    foreach (var member in members)
                    {
                        if (member is NamespaceBlockSyntax)
                        {
                            var NameSpace = member as NamespaceBlockSyntax;

                            //NameSpace.Usings
                        }
                        else if (member is ImportsStatementSyntax)
                        {
                            var importsStatements = member as ImportsStatementSyntax;
#if DEBUG
                            ImportsCollector ic = new ImportsCollector();
                            ic.Visit(root);
                            foreach(var statement in ic.Imports)
                            {
                                Debug.WriteLine(statement);
                            }
#endif							
                            //NameSpace.Usings
                        }
                        else if (member is Microsoft.CodeAnalysis.VisualBasic.Syntax.ClassBlockSyntax) // ClassDeclarationSyntax)
                        {
                            ClassBlockSyntax cds = member as ClassBlockSyntax;
                            fullItemName = cds.ClassStatement.Identifier.Text;
                            for (int i = cds.Members.Count - 1; i >= 0; i--)
                            {
                                if (cds.Members[i] is FieldDeclarationSyntax)
                                {
                                    FieldDeclarationSyntax fds = cds.Members[i] as FieldDeclarationSyntax;

                                    if (fds.IsType("ILog"))
                                    {
                                        // Fix This - Check this
                                        //if (!m_lstLogName.Contains(cds.ClassStatement.Identifier.Text))
                                        //    m_lstLogName.Add(cds.ClassStatement.Identifier.Text);
                                        strProgramText = strProgramText.Replace(fds.ToFullString(), "");
                                    }
                                }
                            }
                            if (bScanForILog)
                                return true;
                        }
                    }
                    int iCount = 0;
                    foreach (var member in members)
                    {
                        if (member is PropertyBlockSyntax)
                        {
                            if ((ci & CodeItems.Property) != CodeItems.Property)
                                continue;

                            var property = member as PropertyBlockSyntax;
                            fullItemName = property.PropertyStatement.Identifier.Text;
                            Debug.WriteLine("Property: " + fullItemName);

                            if (property.IsType("ILog"))
                            {
                                // Fix This
                                if (!m_lstLogName.Contains(property.PropertyStatement.Identifier.Text))
                                    m_lstLogName.Add(property.PropertyStatement.Identifier.Text);
                                strProgramText = strProgramText.Replace(property.ToFullString(), "");
                            }
                            else
                            {
                                // Do stuff with the symbol here
                                if (property.Accessors == null)
                                {
                                    Debug.WriteLine("Skipping Auto Property: " + property.ToString() + ".");
                                }
                                else
                                {
                                    SyntaxList<AccessorBlockSyntax> accessors = property.Accessors;

                                    AccessorBlockSyntax getter = accessors.FirstOrDefault(ad => ad.Kind() == SyntaxKind.GetAccessorBlock);
                                    AccessorBlockSyntax setter = accessors.FirstOrDefault(ad => ad.Kind() == SyntaxKind.SetAccessorBlock);
                                    if (getter == null && setter == null)
                                        continue;
                                    if (getter == null)
                                    {
                                        Debug.WriteLine("Skipping Auto Implimented 'get'.");
                                    }
                                    else
                                    {
                                        //if (getter.FullSpan == null)
                                        if (getter.Statements == null || getter.Statements.Count == 0)
                                        {
                                            Debug.WriteLine("Skipping Auto Implimented 'get'.");
                                        }
                                        else
                                        {
                                            //fullItemName = getter.ToString().Replace(getter.FullSpan.ToString(), "");
                                            //fullItemName = property.PropertyStatement.Identifier.Text + " (Get)";
                                            Debug.WriteLine("Function [Get]: " + fullItemName);
                                            
                                            if (ProcessBody(ref root, member, getter.Statements, ref strProgramText, ref lstUsings, ci, DetailedLoggingFunctions.Any(p => p == fullItemName)))
                                            {
                                                bUpdated = true;
                                            }
                                        }
                                    }
                                    if (setter == null)
                                    {
                                        Debug.WriteLine("Skipping Auto Implimented 'set'.");
                                    }
                                    else
                                    {
                                        if (setter.Statements == null || setter.Statements.Count == 0)
                                        {
                                            Debug.WriteLine("Skipping Auto Implimented 'set'.");
                                        }
                                        else
                                        {
                                            //fullItemName = setter.ToString().Replace(setter.Statements.ToString(), "");
                                            //fullItemName = property.PropertyStatement.Identifier.Text + " (Set)";
                                            Debug.WriteLine("Function [Set]: " + fullItemName);
                                            if (ProcessBody(ref root, member, setter.Statements, ref strProgramText, ref lstUsings, ci, DetailedLoggingFunctions.Any(p => p == fullItemName)))
                                            {
                                                bUpdated = true;
                                            }
                                        }
                                    }
                                }
                                var fullMethodName = property.ToFullString();
                            }
                        }
                        else if (member is ConstructorBlockSyntax ||
                                    member is MethodBlockSyntax)
                        {
                            ConstructorBlockSyntax constructor = null;
                            MethodBlockSyntax method = null;
                            /*
                                if (member is ClassDeclarationSyntax)
                                if (member is ConstructorDeclarationSyntax)
                                if (member is MethodDeclarationSyntax)
                                if (member is PropertyDeclarationSyntax)
                                if (member is FieldDeclarationSyntax)
                                if (member is NamespaceDeclarationSyntax)
                                if (member is EnumDeclarationSyntax)
                                if (member is EnumMemberDeclarationSyntax)
                                if (member is EventFieldDeclarationSyntax)
                                if (member is DelegateDeclarationSyntax)
                                if (member is InterfaceDeclarationSyntax)
                            */
                            if (member is ConstructorBlockSyntax)
                            {
                                if ((ci & CodeItems.Constructor) != CodeItems.Constructor)
                                    continue;

                                constructor = member as ConstructorBlockSyntax;
                                Debug.WriteLine("Constructor: " + constructor.ToFullString()); //.Identifier);
                                if (constructor.ToString().Contains("Private Sub InitializeComponent()"))
                                {
                                    Debug.WriteLine("Stop");
                                }

                                if (constructor.Statements == null || constructor.Statements.Count == 0)
                                    continue;
                                fullItemName = constructor.ToString().Replace(constructor.Statements.ToString(), "");
                                Debug.WriteLine("Function: " + fullItemName);
                                if (ProcessBody(ref root, member, constructor.Statements, ref strProgramText, ref lstUsings, ci, DetailedLoggingFunctions.Any(p => p == fullItemName)))
                                {
                                    bUpdated = true;
                                }
                            }
                            else if (member is MethodBlockSyntax)
                            {
                                if ((ci & CodeItems.Method) != CodeItems.Method)
                                    continue;

                                method = member as MethodBlockSyntax;
                                fullItemName = method.SubOrFunctionStatement.Identifier.Text;
                                Debug.WriteLine("Method: " + fullItemName);
                                if (method.ToString().Contains("Private Sub InitializeComponent()"))
                                {
                                    Debug.WriteLine("Stop");
                                }

                                if (method.Statements == null || method.Statements.Count == 0)
                                    continue;

                                foreach (var node in method.ChildNodes())
                                {
                                    Debug.WriteLine(node.ToString());
                                    foreach (var node1 in node.ChildNodes())
                                    {
                                        Debug.WriteLine(node1.ToString());
                                        foreach (var node2 in node1.ChildNodes())
                                        {
                                            Debug.WriteLine(node2.ToString());
                                        }
                                    }
                                }
                                Debug.WriteLine("Function: " + fullItemName);
                                if (ProcessBody(ref root, member, method.Statements, ref strProgramText, ref lstUsings, ci, DetailedLoggingFunctions.Any(p => p == fullItemName)))
                                {
                                    bUpdated = true;
                                }
                            }
                        }
                        else
                        {
                            Debug.WriteLine(member.GetType().FullName);
                            if (member is NamespaceBlockSyntax)
                            { }
                            else if (member is InterfaceBlockSyntax)
                            { }
                            else if (member is ClassBlockSyntax)
                            {
                                ClassBlockSyntax cds = member as ClassBlockSyntax;
                                if (cds.Inherits != null)
                                {
                                    if ((ci & CodeItems.Class) == CodeItems.Class)
                                    {
                                        if (cds.Inherits.ToString().Contains(" ServiceBase"))
                                        {
                                            strProgramText = strProgramText.Replace(" ServiceBase", " WinServiceBase");
                                            if (!lstUsings.Contains("AdvancedLogging.BLL"))
                                                lstUsings.Add("AdvancedLogging.BLL");
                                            if (!m_lstLogName.Contains("Log"))
                                                m_lstLogName.Add("Log");
                                        }
                                        if (cds.Inherits.ToString().Contains("System.Web.HttpApplication"))
                                        {
                                            strProgramText = strProgramText.Replace("System.Web.HttpApplication", "WebServiceBase");
                                            if (!lstUsings.Contains("AdvancedLogging.BLL"))
                                                lstUsings.Add("AdvancedLogging.BLL");
                                        }
                                        if (cds.Inherits.ToString().Contains("System.Web.UI.Page"))
                                        {
                                            strProgramText = strProgramText.Replace("System.Web.UI.Page", "BasePage");
                                        }
                                    }
                                    for (int i = cds.Members.Count - 1; i >= 0; i--)
                                    {
                                        if (cds.Members[i] is FieldDeclarationSyntax)
                                        {
                                            FieldDeclarationSyntax fds = cds.Members[i] as FieldDeclarationSyntax;

                                            if (fds.IsType("ILog"))
                                            {
                                                // Fix This
                                                //if (!m_lstLogName.Contains(fds.Declaration.Variables[0].Identifier.Text))
                                                //    m_lstLogName.Add(fds.Declaration.Variables[0].Identifier.Text);
                                                strProgramText = strProgramText.Replace(fds.ToFullString(), "");
                                            }
                                            // Do stuff with the symbol here
                                        }
                                    }
                                }
                            }
                            else if (member is FieldDeclarationSyntax)
                            {
                                FieldDeclarationSyntax fds = member as FieldDeclarationSyntax;

                                if (fds.IsType("ILog"))
                                {
                                    //m_dicLogName.Add(fds.Declaration.Id)
                                    //cds.Members.Remove(vMember);
                                }
                            }
                            else if (member is EnumBlockSyntax)
                            { }
                            else if (member is EnumMemberDeclarationSyntax)
                            { }
                            else if (member is Microsoft.CodeAnalysis.VisualBasic.Syntax.EventBlockSyntax)
                            { }
                            else if (member is Microsoft.CodeAnalysis.VisualBasic.Syntax.DelegateStatementSyntax)
                            { }
                        }
                        iCount++;
                        UpdateProgress(fi.FullName, "Code", iCount, members.Count());
                        Application.DoEvents();
                    }
                    if (bRetryHttp)
                    {
                        if (m_dicHttpsMethods.Keys.Any(strProgramText.Contains))
                        {
                            foreach (string strKey in m_dicHttpsMethods.Keys)
                            {
                                if (!m_dicHttpsMethods[strKey])
                                    continue;
                                string strHttpCommand = "." + strKey + "(";
                                int iPos = 0;
                                int iItems = 0;
                                if (ProgressEventsEnabled)
                                {
                                    while (iPos > -1)
                                    {
                                        iPos = strProgramText.IndexOf(strHttpCommand, iPos + 1);
                                        if (iPos > -1)
                                        {
                                            int iPosClose = strProgramText.IndexOf(")", iPos);

                                            if (strProgramText.Substring(iPos, iPosClose - iPos).Contains(">("))
                                            {
                                                iPosClose = strProgramText.IndexOf(")", iPosClose + 1);
                                            }
                                            if (!strProgramText.Substring(iPos, iPosClose - iPos).Contains("MaxAutoRetriesHttp"))
                                            {
                                                if (strProgramText.Substring(iPos, iPosClose - iPos + 1) == strHttpCommand + ")")
                                                {
                                                    iPos += "ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp)".Length;
                                                }
                                                else
                                                {
                                                    iPos += ", ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp)".Length;
                                                }
                                                iItems++;
                                            }
                                        }
                                    }
                                }
                                iPos = 0;
                                while (iPos > -1)
                                {
                                    iPos = strProgramText.IndexOf(strHttpCommand, iPos + 1);
                                    if (iPos > -1)
                                    {
                                        int iPosClose = strProgramText.IndexOf(")", iPos);

                                        if (strProgramText.Substring(iPos, iPosClose - iPos).Contains(">("))
                                        {
                                            iPosClose = strProgramText.IndexOf(")", iPosClose + 1);
                                        }
                                        if (!strProgramText.Substring(iPos, iPosClose - iPos).Contains("MaxAutoRetriesHttp"))
                                        {
                                            if (strProgramText.Substring(iPos, iPosClose - iPos + 1) == strHttpCommand + ")")
                                            {
                                                strProgramText = strProgramText.Replace(strProgramText.Substring(iPos, iPosClose - iPos + 1), strProgramText.Substring(iPos, iPosClose - iPos) + "ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp)");
                                                iPos += "ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp)".Length;
                                            }
                                            else
                                            {
                                                strProgramText = strProgramText.Replace(strProgramText.Substring(iPos, iPosClose - iPos + 1), strProgramText.Substring(iPos, iPosClose - iPos) + ", ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp)");
                                                iPos += ", ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp)".Length;
                                            }
                                            iCount++;
                                            UpdateProgress(fi.FullName, "Http", iCount, iItems);
                                            Application.DoEvents();
                                            bUpdated = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (bRetrySql)
                    {
                        //if (strProgramText.Contains(".ExecuteNonQuery(")
                        //    || strProgramText.Contains(".ExecuteReader(")
                        //    || strProgramText.Contains(".ExecuteScalar(")
                        //    || strProgramText.Contains(".Fill("))
                        //{
                        //    foreach (string strSqlCommand in new string[] { ".ExecuteNonQuery(", ".ExecuteReader(", ".ExecuteScalar(", ".Fill(" })

                        if (m_dicSqlMethods.Keys.Any(strProgramText.Contains))
                        {
                            foreach (string strKey in m_dicSqlMethods.Keys)
                            {
                                if (!m_dicSqlMethods[strKey])
                                    continue;
                                string strSqlCommand = "." + strKey + "(";
                                int iPos = 0;
                                int iItems = 0;
                                if (ProgressEventsEnabled)
                                {
                                    while (iPos > -1)
                                    {
                                        iPos = strProgramText.IndexOf(strSqlCommand, iPos + 1);
                                        if (iPos > -1)
                                        {
                                            //                . - iPos = 250
                                            //                  
                                            //       SqlHelper.ExecuteScalar
                                            if (strProgramText.Substring(iPos - "Helper".Length, "Helper".Length).ToLower() == "Helper".ToLower())
                                            {
                                                // Skip Processing "*Helper"
                                                Debug.WriteLine("Skip Processing '*Helper'");
                                            }
                                            else if (strProgramText.Substring(iPos - "x => x.".Length, "x => x.".Length).Contains(" => "))
                                            {
                                                // x => x.ExecuteReader
                                                // Skip Processing "*Helper"
                                                Debug.WriteLine("Skip Processing '*Helper'");
                                            }
                                            // SqlHelperStatic.ExecuteScalar
                                            // SqlHelperStatic.ExecuteScalar
                                            else if (strProgramText.Substring(iPos - "SqlHelperStatic".Length, "SqlHelperStatic".Length) == "SqlHelperStatic")
                                            {
                                                // Skip Processing "SqlHelperStatic"
                                                Debug.WriteLine("Skip Processing 'SqlHelperStatic'");
                                            }
                                            // Izenda.AdHoc.AdHocContext.Driver
                                            else if (lstIzenda.Any(strProgramText.Substring(iPos - "Izenda.AdHoc.AdHocContext.Driver".Length, "Izenda.AdHoc.AdHocContext.Driver".Length).Contains))
                                            {
                                                // Skip Processing "Izenda"
                                                Debug.WriteLine("Skip Processing ''");
                                            }
                                            else
                                            {
                                                int iPosClose = strProgramText.IndexOf(")", iPos);
                                                if (!strProgramText.Substring(iPos, iPosClose - iPos).Contains("MaxAutoRetriesSql"))
                                                {
                                                    if (strProgramText.Substring(iPos, iPosClose - iPos + 1) == strSqlCommand + ")")
                                                    {
                                                        iPos += "ApplicationSettings.MaxAutoRetriesSql, ApplicationSettings.AutoRetrySleepMsSql, ApplicationSettings.AutoTimeoutIncrementSecondsSql)".Length;
                                                    }
                                                    else
                                                    {
                                                        iPos += ", ApplicationSettings.MaxAutoRetriesSql, ApplicationSettings.AutoRetrySleepMsSql, ApplicationSettings.AutoTimeoutIncrementSecondsSql)".Length;
                                                    }
                                                    iItems++;
                                                }
                                            }
                                        }
                                    }
                                }
                                iPos = 0;
                                while (iPos > -1)
                                {
                                    iPos = strProgramText.IndexOf(strSqlCommand, iPos + 1);
                                    if (iPos > -1)
                                    {
                                        //                . - iPos = 250
                                        //                  
                                        //       SqlHelper.ExecuteScalar
                                        if (strProgramText.Substring(iPos - "Helper".Length, "Helper".Length).ToLower() == "Helper".ToLower())
                                        {
                                            // Skip Processing "*Helper"
                                            Debug.WriteLine("Skip Processing '*Helper'");
                                        }
                                        else if (strProgramText.Substring(iPos - "x => x.".Length, "x => x.".Length).Contains(" => "))
                                        {
                                            // x => x.ExecuteReader
                                            // Skip Processing "*Helper"
                                            Debug.WriteLine("Skip Processing '*Helper'");
                                        }
                                        // SqlHelperStatic.ExecuteScalar
                                        // SqlHelperStatic.ExecuteScalar
                                        else if (strProgramText.Substring(iPos - "SqlHelperStatic".Length, "SqlHelperStatic".Length) == "SqlHelperStatic")
                                        {
                                            // Skip Processing "SqlHelperStatic"
                                            Debug.WriteLine("Skip Processing 'SqlHelperStatic'");
                                        }
                                        // Izenda.AdHoc.AdHocContext.Driver
                                        else if (lstIzenda.Any(strProgramText.Substring(iPos - "Izenda.AdHoc.AdHocContext.Driver".Length, "Izenda.AdHoc.AdHocContext.Driver".Length).Contains))
                                        {
                                            // Skip Processing "Izenda"
                                            Debug.WriteLine("Skip Processing ''");
                                        }
                                        else
                                        {
                                            int iPosClose = strProgramText.IndexOf(")", iPos);
                                            if (!strProgramText.Substring(iPos, iPosClose - iPos).Contains("MaxAutoRetriesSql"))
                                            {
                                                if (strProgramText.Substring(iPos, iPosClose - iPos + 1) == strSqlCommand + ")")
                                                {
                                                    strProgramText = strProgramText.Replace(strProgramText.Substring(iPos, iPosClose - iPos + 1), strProgramText.Substring(iPos, iPosClose - iPos) + "ApplicationSettings.MaxAutoRetriesSql, ApplicationSettings.AutoRetrySleepMsSql, ApplicationSettings.AutoTimeoutIncrementSecondsSql)");
                                                    iPos += "ApplicationSettings.MaxAutoRetriesSql, ApplicationSettings.AutoRetrySleepMsSql, ApplicationSettings.AutoTimeoutIncrementSecondsSql)".Length;
                                                }
                                                else
                                                {
                                                    strProgramText = strProgramText.Replace(strProgramText.Substring(iPos, iPosClose - iPos + 1), strProgramText.Substring(iPos, iPosClose - iPos) + ", ApplicationSettings.MaxAutoRetriesSql, ApplicationSettings.AutoRetrySleepMsSql, ApplicationSettings.AutoTimeoutIncrementSecondsSql)");
                                                    iPos += ", ApplicationSettings.MaxAutoRetriesSql, ApplicationSettings.AutoRetrySleepMsSql, ApplicationSettings.AutoTimeoutIncrementSecondsSql)".Length;
                                                }
                                                iCount++;
                                                UpdateProgress(fi.FullName, "Sql", iCount, iItems);
                                                Application.DoEvents();
                                                bUpdated = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (bUpdated)
                    {
                        if (bBackup)
                        {
                            if (!Directory.Exists(Path.Combine(fi.DirectoryName, "backup")))
                            {
                                Directory.CreateDirectory(Path.Combine(fi.DirectoryName, "backup"));
                            }
                            fi.CopyTo(Path.Combine(fi.DirectoryName, "backup", fi.Name), true);
                        }

                        bool bCtrlKD = false;
                        if (bCtrlKD)
                        {
                            SyntaxTree treeNew = VisualBasicSyntaxTree.ParseText(strProgramText);
                            SyntaxNode rootNew = treeNew.GetRoot().NormalizeWhitespace();
                            strProgramText = rootNew.ToFullString();
                            Debug.WriteLine(strProgramText);

                            //Microsoft.CodeAnalysis.Host.HostServices hs = new 
                            //Microsoft.CodeAnalysis.Workspace workspace = Microsoft.CodeAnalysis.Workspace.GetWorkspaceRegistration("");
                            //var formattedResult = Formatter.Format(treeNew.GetRoot(), workspace);
                        }

                        File.WriteAllText(fi.FullName, strProgramText, encFile);
                        //try
                        //{
                        //    File.WriteAllText(fi.FullName + ":Status", "<Status>Processed</Status>");
                        //}
                        //catch (Exception ex)
                        //{

                        //}
                        if (!m_colProcessFiles.Contains(fi.FullName.Substring(Folder.Trim().Length + 1)))
                            m_colProcessFiles.Add(fi.FullName.Substring(Folder.Trim().Length + 1));
                        if (fi.AlternateDataStreamExists("Status"))
                        {
                            Debug.WriteLine("Found Status stream:");

                            AlternateDataStreamInfo s = fi.GetAlternateDataStream("Status", FileMode.Open);
                            using (TextReader reader = s.OpenText())
                            {
                                Debug.WriteLine(reader.ReadToEnd());
                            }
                            if (m_bSaveAsStream)
                            {
                                // Delete the stream:
                                s.Delete();

                                s = fi.GetAlternateDataStream("Status", FileMode.OpenOrCreate);
                                using (StreamWriter sw = new StreamWriter(s.OpenWrite()))
                                {
                                    sw.WriteLine("<Status>Processed</Status>");
                                }
                            }
                        }
                        else if (m_bSaveAsStream)
                        {
                            AlternateDataStreamInfo s = fi.GetAlternateDataStream("Status", FileMode.OpenOrCreate);
                            using (StreamWriter sw = new StreamWriter(s.OpenWrite()))
                            {
                                sw.WriteLine("<Status>Processed</Status>");
                            }
                        }
                    }
                }
                if (bShowFile && File.Exists(fi.FullName))
                {
                    Process p = new Process();
                    p.StartInfo.FileName = "notepad.exe";
                    p.StartInfo.Arguments = fi.FullName;
                    p.Start();
                }

                return bUpdated;
            }
            else
            {
                return false;
            }
        }
        //private bool ProcessBody(ref CompilationUnitSyntax root, StatementSyntax member, StatementSyntax oBody, ref SyntaxList<StatementSyntax> strProgramText, ref List<string> lstImports, CodeItems ci)
        //{
        //    return ProcessBody(ref root, member, oBody, strProgramText.ToFullString(), ref lstImports, ci);
        //}
        private bool ProcessBody(ref CompilationUnitSyntax root, StatementSyntax member, SyntaxList<StatementSyntax> oBody, ref string strProgramText, ref List<string> lstImports, CodeItems ci, bool AddLineLogging = false)
        {
            bool bUpdated = false;

            bool bAddAutoLog = ((ci & CodeItems.AutoLog) == CodeItems.AutoLog);
            bool bTryCatch = ((ci & CodeItems.TryCatch) == CodeItems.TryCatch);
            bool bConstructor = (ci & CodeItems.Constructor) == CodeItems.Constructor;
            bool bMethod = (ci & CodeItems.Method) == CodeItems.Method;
            bool bProperty = (ci & CodeItems.Property) == CodeItems.Property;

            if (oBody.Count == 0)
                return bUpdated;
            var body = oBody.ToString();
#if DEBUG
            if (AddLineLogging)
            {
                // Line for Line Debug Statements Testing
                string strTempReplacement = "";
                foreach (var vStatement in oBody)
                {
                    strTempReplacement += "vAutoLogFunction.WriteDebug(\"" + vStatement.ToString().Replace("\"", "\\\"") + "\");" + Environment.NewLine;
                    strTempReplacement += vStatement.ToString() + Environment.NewLine;
                }
                Debug.WriteLine(strTempReplacement);
            }
#endif
            if ((ci & CodeItems.ModifyEmptyBody) == CodeItems.ModifyEmptyBody)
            {
                if (body.Replace(" ", "").Replace(Environment.NewLine, "") == "")
                    return bUpdated;
            }

            String strReplaceFind = "";
            String strReplaceWith = "";
            String strVariables = "";
#if INDENT_SPACES
            Int16 iBaseIndent = 3;
            string strBaseIndent = "    ";
#else
            Int16 iBaseIndent = 3;
            string strBaseIndent = "    ";
#endif

            if (member is ConstructorBlockSyntax)
            {
                ConstructorBlockSyntax constructor = member as ConstructorBlockSyntax;
                if (constructor != null)
                {
                    if (constructor.BlockStatement.ParameterList != null && constructor.BlockStatement.ParameterList.Parameters != null && constructor.BlockStatement.ParameterList.Parameters.Count > 0)
                    {
                        foreach (var vParameter in constructor.BlockStatement.ParameterList.Parameters)
                        {
                            if (strVariables == "")
                                strVariables = "New With { ";
                            else
                                strVariables += ", ";
                            strVariables += vParameter.Identifier.ToString();
                            Debug.WriteLine((vParameter.Identifier.ToString()));
                        }

                        if (strVariables != "")
                            strVariables += " }";
                    }
                }
            }
            else if (member is MethodStatementSyntax)
            {
                MethodStatementSyntax method = member as MethodStatementSyntax;
                if (method.ParameterList != null)
                {
                    foreach (var vParameter in method.ParameterList.Parameters)
                    {
                        if (strVariables == "")
                            strVariables = "New With { ";
                        else
                            strVariables += ", ";
                        strVariables += vParameter.Identifier.ToString();
                        Debug.WriteLine((vParameter.Identifier.ToString()));
                    }

                    if (strVariables != "")
                        strVariables += " }";

                }
            }
            else if (member is MethodBlockSyntax)
            {
                MethodBlockSyntax method = member as MethodBlockSyntax;
                Debug.WriteLine("Method: " + method.ToString());
                if (method.ToString().Contains("Private Sub InitializeComponent()"))
                {
                    Debug.WriteLine("Stop");
                }
                if (method.Statements != null && method.Statements.Count > 0)
                {
                    if (method.BlockStatement.ParameterList != null)
                    {
                        foreach (var vParameter in method.BlockStatement.ParameterList.Parameters)
                        {
                            if (strVariables == "")
                                strVariables = "New With { ";
                            else
                                strVariables += ", ";
                            strVariables += vParameter.Identifier.ToString();
                            Debug.WriteLine((vParameter.Identifier.ToString()));
                        }

                        if (strVariables != "")
                            strVariables += " }";
                    }
                }
            }
            else if (member is PropertyStatementSyntax)
            {
                iBaseIndent = 4;
            }
            else if (member is PropertyBlockSyntax)
            {
                iBaseIndent = 4;
            }
            strReplaceFind = body;
            string strBody = body;
            if (bTryCatch && !body.Replace(" ", "").Contains("CatchExOuterAsException"))
            {
                if (body.Replace(" ", "").Replace(Environment.NewLine, "").StartsWith("UsingvAutoLogFunctionAsNewAutoLogFunction"))
                {
                    Debug.WriteLine(oBody[0].GetType().Name);
                    if (oBody[0] is ImportsStatementSyntax)
                    {
                        bool bAddTry = true;
                        ImportsStatementSyntax uss = (ImportsStatementSyntax)oBody[0];
                        //if (uss.ImportsClauses.Statement is BlockSyntax)
                        {
                        //    BlockSyntax bs = (BlockSyntax)uss.Statement;
                        //    Debug.WriteLine(bs.Statements[0].ToString());
                        //    bAddTry = !(bs.Statements[0].ToString().StartsWith("Try") && bs.Statements[0].ToString().Replace(" ", "").Contains("CatchExOuterAsException)"));
                        }
                        //else if (uss.Statement.ToString().Replace(" ", "").Replace(Environment.NewLine, "").StartsWith(oBody.OpenBraceToken.ToString() + "Try"))
                        {
                            bAddTry = false;
                        }
                        if (bAddTry)
                        {
                            Debug.WriteLine("Stop");
                            //    strReplaceWith = oBody.OpenBraceToken.ToString() + Environment.NewLine;
                            //    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + "Try" + Environment.NewLine;
                            //    string strUSS = uss.Statement.ToString().Replace(Environment.NewLine, Environment.NewLine + Indention(1, strBaseIndent)) + Environment.NewLine;
                            //    foreach (string strLogName in m_lstLogName)
                            //    {
                            //        if (strUSS.Contains(strLogName))
                            //        {
                            //            foreach (string strToken in new string[] { ".", "?." })
                            //            {
                            //                strUSS = strUSS.Replace(strLogName + strToken + "Info(", "vAutoLogFunction.WriteLog(");
                            //                strUSS = strUSS.Replace(strLogName + strToken + "Warn(", "vAutoLogFunction.WriteWarn(");
                            //                strUSS = strUSS.Replace(strLogName + strToken + "Error(", "vAutoLogFunction.WriteError(");
                            //                strUSS = strUSS.Replace(strLogName + strToken + "Debug(", "vAutoLogFunction.WriteDebug(");
                            //                strUSS = strUSS.Replace(strLogName + strToken + "InfoFormat(", "vAutoLogFunction.WriteLogFormat(");
                            //                strUSS = strUSS.Replace(strLogName + strToken + "WarnFormat(", "vAutoLogFunction.WriteWarnFormat(");
                            //                strUSS = strUSS.Replace(strLogName + strToken + "ErrorFormat(", "vAutoLogFunction.WriteErrorFormat(");
                            //                strUSS = strUSS.Replace(strLogName + strToken + "DebugFormat(", "vAutoLogFunction.WriteDebugFormat(");
                            //            }
                            //        }
                            //    }
                            //    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + strUSS;
                            //    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + "Catch ExOuter As Exception" + Environment.NewLine;
                            //    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + oBody.OpenBraceToken.ToString() + Environment.NewLine;
                            //    if (strVariables.Length == 0)
                            //        strReplaceWith += Indention(iBaseIndent + 2, strBaseIndent) + "vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), bError:=true, _ex:=ExOuter)" + Environment.NewLine;
                            //    else
                            //        strReplaceWith += Indention(iBaseIndent + 2, strBaseIndent) + "vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod()" + strVariables + ", true, ExOuter)" + Environment.NewLine;
                            //    strReplaceWith += Indention(iBaseIndent + 2, strBaseIndent) + "Throw" + Environment.NewLine;
                            //    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + "End Try" + Environment.NewLine;
                            //    strReplaceWith += Indention(iBaseIndent - 1, strBaseIndent) + "End Using";
                            //    strReplaceWith = strBody.Replace(uss.Statement.ToString(), strReplaceWith);
                            //    strBody = strReplaceWith;
                        }
                    }
                    Debug.WriteLine("Stop");
                }
                else
                {
                    strReplaceWith = Environment.NewLine;
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + "Try" + Environment.NewLine;
                    strBody = strBody.Replace(Environment.NewLine, Environment.NewLine + Indention(1, strBaseIndent)) + Environment.NewLine;
                    foreach (string strLogName in m_lstLogName)
                    {
                        if (strBody.Contains(strLogName))
                        {
                            foreach (string strToken in new string[] { ".", "?." })
                            {
                                if (bAddAutoLog)
                                {
                                    strBody = strBody.Replace(strLogName + strToken + "Info(", "vAutoLogFunction.WriteLog(");
                                    strBody = strBody.Replace(strLogName + strToken + "Warn(", "vAutoLogFunction.WriteWarn(");
                                    strBody = strBody.Replace(strLogName + strToken + "Error(", "vAutoLogFunction.WriteError(");
                                    strBody = strBody.Replace(strLogName + strToken + "Debug(", "vAutoLogFunction.WriteDebug(");
                                    strBody = strBody.Replace(strLogName + strToken + "InfoFormat(", "vAutoLogFunction.WriteLogFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "WarnFormat(", "vAutoLogFunction.WriteWarnFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "ErrorFormat(", "vAutoLogFunction.WriteErrorFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "DebugFormat(", "vAutoLogFunction.WriteDebugFormat(");
                                }
                                else
                                {
                                    strBody = strBody.Replace(strLogName + strToken + "Info(", "LoggingUtils.WriteLog(");
                                    strBody = strBody.Replace(strLogName + strToken + "Warn(", "LoggingUtils.WriteWarn(");
                                    strBody = strBody.Replace(strLogName + strToken + "Error(", "LoggingUtils.WriteError(");
                                    strBody = strBody.Replace(strLogName + strToken + "Debug(", "LoggingUtils.WriteDebug(");
                                    strBody = strBody.Replace(strLogName + strToken + "InfoFormat(", "LoggingUtils.WriteLogFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "WarnFormat(", "LoggingUtils.WriteWarnFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "ErrorFormat(", "LoggingUtils.WriteErrorFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "DebugFormat(", "LoggingUtils.WriteDebugFormat(");
                                }
                            }
                        }
                    }
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + strBody;
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + "Catch ExOuter As Exception" + Environment.NewLine;
                    if (bAddAutoLog)
                    {
                        strReplaceWith += Indention(iBaseIndent + 1, strBaseIndent) + "vAutoLogFunction.LogFunction(" + strVariables + ", System.Reflection.MethodBase.GetCurrentMethod(), bError:=true, _ex:=ExOuter)" + Environment.NewLine;
                    }
                    else
                    {
                        strReplaceWith += Indention(iBaseIndent + 1, strBaseIndent) + "LoggingUtils.LogFunction(" + strVariables + ", System.Reflection.MethodBase.GetCurrentMethod(), bError:=true, _ex:=ExOuter)" + Environment.NewLine;
                    }
                    strReplaceWith += Indention(iBaseIndent + 1, strBaseIndent) + "Throw" + Environment.NewLine;
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + "End Try";
                    strBody = strReplaceWith;
                }
            }
            if (bAddAutoLog && !body.Replace(" ", "").Replace(Environment.NewLine, "").StartsWith("UsingvAutoLogFunctionAsNewAutoLogFunction"))
            {
                if (body.Contains("AutoLogFunction("))
                {
                    // Add strReplaceWith inside existing AutoLogFunction(
                    Debug.WriteLine("Stop");
                }
                else
                {
                    strReplaceWith = ""; // Environment.NewLine;
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + "Using vAutoLogFunction As New AutoLogFunction(" + strVariables + ")"; // + Environment.NewLine;
                    strBody = strBody.Replace(Environment.NewLine, Environment.NewLine + Indention(1, strBaseIndent)) + Environment.NewLine;
                    foreach (string strLogName in m_lstLogName)
                    {
                        if (strBody.Contains(strLogName))
                        {
                            foreach (string strToken in new string[] { ".", "?." })
                            {
                                if (bAddAutoLog)
                                {
                                    strBody = strBody.Replace(strLogName + strToken + "Info(", "vAutoLogFunction.WriteLog(");
                                    strBody = strBody.Replace(strLogName + strToken + "Warn(", "vAutoLogFunction.WriteWarn(");
                                    strBody = strBody.Replace(strLogName + strToken + "Error(", "vAutoLogFunction.WriteError(");
                                    strBody = strBody.Replace(strLogName + strToken + "Debug(", "vAutoLogFunction.WriteDebug(");
                                    strBody = strBody.Replace(strLogName + strToken + "InfoFormat(", "vAutoLogFunction.WriteLogFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "WarnFormat(", "vAutoLogFunction.WriteWarnFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "ErrorFormat(", "vAutoLogFunction.WriteErrorFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "DebugFormat(", "vAutoLogFunction.WriteDebugFormat(");
                                }
                                else
                                {
                                    strBody = strBody.Replace(strLogName + strToken + "Info(", "LoggingUtils.WriteLog(");
                                    strBody = strBody.Replace(strLogName + strToken + "Warn(", "LoggingUtils.WriteWarn(");
                                    strBody = strBody.Replace(strLogName + strToken + "Error(", "LoggingUtils.WriteError(");
                                    strBody = strBody.Replace(strLogName + strToken + "Debug(", "LoggingUtils.WriteDebug(");
                                    strBody = strBody.Replace(strLogName + strToken + "InfoFormat(", "LoggingUtils.WriteLogFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "WarnFormat(", "LoggingUtils.WriteWarnFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "ErrorFormat(", "LoggingUtils.WriteErrorFormat(");
                                    strBody = strBody.Replace(strLogName + strToken + "DebugFormat(", "LoggingUtils.WriteDebugFormat(");
                                }
                            }
                        }
                    }
                    strReplaceWith += Indention(iBaseIndent, strBaseIndent) + strBody;
                    strReplaceWith += Indention(iBaseIndent - 1, strBaseIndent) + "End Using";
                }
            }
            else if (strReplaceWith.Length > 0)
            {
                if (body.Replace(" ", "").Replace(Environment.NewLine, "").StartsWith("UsingvAutoLogFunctionAsNewAutoLogFunction"))
                {
                    Debug.WriteLine("Stop");
                }
            }

            if (strReplaceWith.Length > 0)
            {
                foreach (string strUsing in lstImports)
                {
                    NameSyntax uMHSUtils = SyntaxFactory.IdentifierName(strUsing);

                    string strUsingStatement = "Imports " + uMHSUtils.ToFullString();

                    if (!root.Imports.Any(x => x.ToFullString() == strUsingStatement) &&
                        !strProgramText.Contains(strUsingStatement))
                    {
                        //ImportsStatementSyntax obj = SyntaxFactory.ImportsStatement("Imports", uMHSUtils);
                        //ImportsStatementSyntax obj2 = SyntaxFactory.ImportsStatement(SyntaxFactory.SingletonSeparatedList<ImportsClauseSyntax>(SyntaxFactory.SimpleImportsClause(SyntaxFactory.ParseName("System.Runtime.InteropServices"))));
                        ImportsStatementSyntax obj = SyntaxFactory.ImportsStatement(SyntaxFactory.SingletonSeparatedList<ImportsClauseSyntax>(SyntaxFactory.SimpleImportsClause(SyntaxFactory.ParseName(uMHSUtils.ToString()))));
                        var newusing = root.Imports.Add(obj);
                        String strUsings = "";
                        if (root.Imports.Count > 0)
                            strUsings += root.Imports[root.Imports.Count - 1].ToString() + Environment.NewLine; //.Name

                        Debug.WriteLine("Adding: " + strUsingStatement + " ...");
                        if (strUsings.Length > 0)
                        {
                            strProgramText = strProgramText.Replace(strUsings, strUsings + strUsingStatement + Environment.NewLine);
                        }
                        else
                        {
                            strProgramText = strUsingStatement + Environment.NewLine + Environment.NewLine + strProgramText;
                        }
                    }
                    else
                    {
                        if (!root.Imports.ToString().Contains(strUsingStatement) && !strProgramText.Contains(strUsingStatement))
                        {
                            Debugger.Break();
                        }
                    }
                }
                if (strProgramText.Contains("\t" + strReplaceFind + Environment.NewLine))
                {
                    strProgramText = strProgramText.Replace("\t" + strReplaceFind + Environment.NewLine, strReplaceWith.Remove(0, 1) + Environment.NewLine);
                }
                else if (strProgramText.Contains("    " + strReplaceFind + Environment.NewLine))
                {
                    strProgramText = strProgramText.Replace("    " + strReplaceFind + Environment.NewLine, strReplaceWith.Substring(4) + Environment.NewLine);
                }
                else
                {
                    strProgramText = strProgramText.Replace(strReplaceFind + Environment.NewLine, strReplaceWith + Environment.NewLine);
                }
                bUpdated = true;

                Debug.WriteLine("Find:     " + strReplaceFind);
                Debug.WriteLine("Replace:  " + strReplaceWith);
            }
            return bUpdated;
        }

        private string Indention(int iLevels, string strIndentString = "")
        {
            if (iLevels == 0 || strIndentString == "")
                return "";
            string strNewIndent = "";
            foreach (char ch in strIndentString)
            {
                strNewIndent += new string(ch, iLevels);
            }
            return strNewIndent;
        }
		
        private static Encoding GetEncoding(string filename)
        {
            // This is a direct quote from MSDN:  
            // The CurrentEncoding value can be different after the first
            // call to any Read method of StreamReader, since encoding
            // autodetection is not done until the first call to a Read method.

            using (var reader = new StreamReader(filename, Encoding.Default, true))
            {
                if (reader.Peek() >= 0) // you need this!
                    reader.Read();

                return reader.CurrentEncoding;
            }
        }
    }
}
