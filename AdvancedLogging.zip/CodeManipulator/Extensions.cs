﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis.VisualBasic.Syntax;

namespace CodeManipulator
{
    static class Extensions
    {
        public static bool IsType(this FieldDeclarationSyntax fds, Type _Type)
        {
            foreach (VariableDeclaratorSyntax declarator in fds.Declarators)
            {
                // If at least one starting character is uppercase, must register an action
                if (declarator.Names.Any(p => p.Identifier.ToString().ToLower() == _Type.Name.ToLower()))
                    return true;
            }
            return false;
        }
        public static bool IsType(this FieldDeclarationSyntax fds, String _Type)
        {
            foreach (VariableDeclaratorSyntax declarator in fds.Declarators)
            {
                // If at least one starting character is uppercase, must register an action
                if (declarator.Names.Any(p => p.Identifier.ToString().ToLower().Contains(_Type.ToLower())))
                    return true;
            }
            return false;
        }
        //
        public static bool IsType(this PropertyStatementSyntax pss, String _Type)
        {
            if (pss.AsClause is null)
            {
                foreach (AttributeListSyntax declarator in pss.AttributeLists)
                {
                    // If at least one starting character is uppercase, must register an action
                    if (declarator.Attributes.Any(p => p.Name.ToString().ToLower().Contains(_Type.ToLower())))
                        return true;
                }
            }
            else
                return pss.AsClause.ToString().Contains(_Type.ToLower());
            return false;
        }
        public static bool IsType(this PropertyBlockSyntax pbs, String _Type)
        {
            foreach (AccessorBlockSyntax declarator in pbs.Accessors)
            {
                // If at least one starting character is uppercase, must register an action
                if (declarator.ToString().ToLower().Contains(_Type.ToLower()))
                    return true;
            }
            return false;
        }
    }
}
