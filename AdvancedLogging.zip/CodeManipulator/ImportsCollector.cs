﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.VisualBasic.Syntax;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeManipulator
{
    class ImportsCollector : SyntaxWalker
    {
        public readonly List<ImportsStatementSyntax> Imports = new List<ImportsStatementSyntax>();

        public override void Visit(SyntaxNode node) //MembersImportsClauseSyntax
        {
            //if (node..Name.GetText() == "System" || node.Name.GetText().StartsWith("System."))

            //if (node.Parent != null)
            //    Imports.Add(node.Parent);
            base.Visit(node);
        }
    }
}
