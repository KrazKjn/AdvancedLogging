﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeManipulator
{
    public class CSharpDeeperWalker : CSharpSyntaxWalker
    {
        static int Tabs = 0;
        //NOTE: Make sure you invoke the base constructor with 
        //the correct SyntaxWalkerDepth. Otherwise VisitToken()
        //will never get run.
        public CSharpDeeperWalker() : base(SyntaxWalkerDepth.Token)
        {
        }
        public override void Visit(SyntaxNode node)
        {
            Tabs++;
            string indents = new String('\t', Tabs);
            string output = indents + node.Kind();
            Debug.WriteLine(output);
            base.Visit(node);
            Tabs--;
        }

        public override void VisitToken(SyntaxToken token)
        {
            string indents = new String('\t', Tabs);
            string output = indents + token;
            Debug.WriteLine(output);
            base.VisitToken(token);
        }
    }
}
