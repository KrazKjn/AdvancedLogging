﻿namespace AdvancedLogging.BE
{
    public class DatabaseVersionInfo
    {
        /// <summary>
        /// Gets or sets the version information retrieved from the DB
        /// </summary>
        public string DataBaseVersion { get; set; }

        /// <summary>
        /// Gets or sets the build number for the database
        /// </summary>
        public int DataBaseBuild { get; set; }
    }
}
