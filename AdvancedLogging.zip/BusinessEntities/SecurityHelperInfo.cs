﻿namespace AdvancedLogging.BE
{
    public class SecurityHelperInfo
    {
        public string PrimaryKeyStr { get; set; }
        public string EncryptedPassword { get; set; }
        public HashType CurrentHash { get; set; }
        public HashType TargetHash { get; set; }

    }
}
