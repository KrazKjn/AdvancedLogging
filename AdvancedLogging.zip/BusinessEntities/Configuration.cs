﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

[assembly: CLSCompliant(true)]
namespace AdvancedLogging.BE
{

    /// <summary>
    /// A Application Name.
    /// </summary>
    public class Application
    {
        /// <summary>
        /// The value of the parameter.
        /// </summary>
        public string ApplicationName { get; set; }

        /// <summary>
        /// The value of the parameter.
        /// </summary>
        public string IsActive { get; set; }

        /// <summary>
        /// An optional description about what the application. Note -- this could be null/empty/missing.
        /// </summary>
        public string Description { get; set; }
    }

    /// <summary>
    /// A Client Name.
    /// </summary>
    public class Client
    {
        /// <summary>
        /// The value of the parameter.
        /// </summary>
        public string ClientName { get; set; }

        /// <summary>
        /// The value of the parameter.
        /// </summary>
        public string IsActive { get; set; }

        /// <summary>
        /// An optional description about what the client. Note -- this could be null/empty/missing.
        /// </summary>
        public string Description { get; set; }
    }

    /// <summary>
    /// A configuration parameter.
    /// </summary>
    public class ConfigurationParameter
    {
        /// <summary>
        /// The value of the parameter.
        /// </summary>
        public string Value { get; set; }

        /// <summary>
        /// An optional description about what the parameter is for. Note -- this could be null/empty/missing.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// An optional comment on where the value was inherited from.  
        /// If the value was specified instead of inherited, then this will be null/empty/missing.
        /// </summary>
        public string DefaultLevel { get; set; }
    }

    public class Configuration
    {
        /// <summary>
        /// The Client Name the configuration is for
        /// </summary>
        public string ClientName { get; set; }

        /// <summary>
        /// The Application Name the configuration is for
        /// </summary>
        public string ApplicationName { get; set; }

        /// <summary>
        /// A dictionary containing the configuration parameters keys and their value and some metadata.
        /// A key is a full key path.  A path always starts with a slash ("/") and the parts of a path
        /// are separated by a slash.  A key path ends in the key's name (no trailing slash). Path parts
        /// and key names may not have a slash as part of them.
        /// </summary>
        public Dictionary<string, ConfigurationParameter> Keys { get; set; }

    }
}
