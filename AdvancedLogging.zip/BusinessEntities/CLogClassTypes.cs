using System;
using System.IO;

namespace AdvancedLogging.BE
{
    public class CLogClassTypes
    {
        public class ConfigFileChangedEventArgs : EventArgs
        {
            public string FileName { get; private set; }
            public WatcherChangeTypes ChangeType { get; private set; }
            private ConfigFileChangedEventArgs() { }
            public ConfigFileChangedEventArgs(string _FileName, WatcherChangeTypes _ChangeType)
            {
                FileName = _FileName;
                ChangeType = _ChangeType;
            }
        }
        public class ConfigSettingChangedEventArgs : EventArgs
        {
            public string SettingName { get; private set; }
            public string OldValue { get; private set; }
            public string NewValue { get; private set; }
            public bool ValueAdded { get; private set; }
            public bool IsPassword { get; private set; }
            private ConfigSettingChangedEventArgs() { }

            public ConfigSettingChangedEventArgs(string _SettingName, string _OldValue, string _NewValue, bool _ValueAdded, bool _IsPassword)
            {
                SettingName = _SettingName;
                OldValue = _OldValue;
                NewValue = _NewValue;
                ValueAdded = _ValueAdded;
                IsPassword = _IsPassword;
            }
        }
    }
}
