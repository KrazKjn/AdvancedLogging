﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AdvancedLogging.BE.SystemStatusV1
{
    public class SystemService
    {
        public int ServiceId { get; set; }
        public string Name { get; set; }
        public string DisplayName { get; set; }
        public string Executable { get; set; }
        public string Parameters { get; set; }
        public string LogOnAccount { get; set; }
        public Client ClientInstance { get; set; }
        public System.ServiceProcess.ServiceControllerStatus Status { get; set; }
        public System.ServiceProcess.ServiceStartMode StartMode { get; set; }
        public string VersionInfo { get; set; }
        public List<DatabaseInfo> DataBases { get; set; }
    }
}
