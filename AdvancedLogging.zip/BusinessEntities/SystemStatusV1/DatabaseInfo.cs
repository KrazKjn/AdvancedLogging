﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AdvancedLogging.BE.SystemStatusV1
{
    public class DatabaseInfo
    {
        /// <summary>
        /// Add your own Applications here
        /// </summary>
        public enum DatabaseTypeClass
        {
            Application01,
            Application02,
            Application03
        }

        public enum DatabaseStateClass
        {
            InActive,
            Active
        }

        public string Name { get; set; }
        public DatabaseTypeClass DatabaseType { get; set; }
        public DatabaseStateClass DatabaseState { get; set; }
        public string ConnectionString { get; set; }
        public string VersionInfo { get; set; }

    }
}
