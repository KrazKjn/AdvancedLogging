﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AdvancedLogging.BE.SystemStatusV1
{
    public class Service
    {
        public enum ServiceTypeClass
        {
            WebService,
            WebApplication,
            SystemService
        }

        public string Name { get; set; }
        public Client client { get; set; }
        public ServiceTypeClass ServiceType { get; set; }
        public SystemService SystemService { get; set; }
        public WebService WebService { get; set; }
    }
}