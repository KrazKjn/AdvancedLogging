﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AdvancedLogging.BE.SystemStatusV1
{
    public class WebService
    {
        public enum ComponentTypeClass
        {
            WebService,
            WebApplication
        }

        public int WebServiceId { get; set; }
        public string Name { get; set; }
        public string URL { get; set; }
        public ComponentTypeClass ItemType { get; set; }
        public Client ClientInstance { get; set; }
        public string VersionInfo { get; set; }
        public List<DatabaseInfo> DataBases { get; set; }
    }
}
