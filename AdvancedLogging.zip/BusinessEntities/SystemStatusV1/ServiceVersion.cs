﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AdvancedLogging.BE.SystemStatusV1
{
    public class ServiceVersion
    {
        public int ServiceVersionId { get; set; }
        public string Name { get; set; }
        public string SupportedVersion { get; set; }
        public SettingsFile[] SettingsFiles { get; set; }
    }
}