﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AdvancedLogging.BE.SystemStatusV1
{
    public class Client
    {
        public int ClientId { get; set; }
        public string Name { get; set; }
        public string TenantName { get; set; }
    }
}