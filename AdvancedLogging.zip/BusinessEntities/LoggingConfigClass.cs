﻿using log4net;
using log4net.Appender;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AdvancedLogging.BE
{
    public class LoggerConfigClass
    {
        private ILog logger;
        private ILog loggerLocalErrorFile = null;
        private ILog loggerLocalRunFile = null;
        private int m_intMinutesAfterMidnight = 60;
        private int m_intDaysInterval = 1;
        private bool m_bAutoCleanUpLogFiles = true;
        private bool m_bRemotingLogging = false;
        private string m_strLogFileName = string.Empty;
        private string m_strServiceName = string.Empty;
        private string m_strServiceDisplayName = string.Empty;
        private string m_strClientName = string.Empty;
        private string m_strProcessName = string.Empty;
        private string m_strClientLogFileName = string.Empty;


        public string LogFileName
        {
            get { return m_strLogFileName; }
            set { m_strLogFileName = value; }
        }

        public string ServiceName
        {
            get { return m_strServiceName; }
            set { m_strServiceName = value; }
        }

        public string ServiceDisplayName
        {
            get { return m_strServiceDisplayName; }
            set { m_strServiceDisplayName = value; }
        }

        public string ClientName
        {
            get { return m_strClientName; }
            set { m_strClientName = value; }
        }

        public string ProcessName
        {
            get { return m_strProcessName; }
            set { m_strProcessName = value; }
        }

        public string ClientLogFileName
        {
            get { return m_strClientLogFileName; }
            set { m_strClientLogFileName = value; }
        }

        public bool AutoCleanUpLogFiles
        {
            get { return m_bAutoCleanUpLogFiles; }
            set { m_bAutoCleanUpLogFiles = value; }
        }

        /// <summary>
        /// Get or set the minutes after midnight when the auto clean up is executed.
        /// </summary>
        public int MinutesAfterMidnight
        {
            get { return m_intMinutesAfterMidnight; }
            set { m_intMinutesAfterMidnight = value; }
        }

        /// <summary>
        /// Get or set the days interval when the auto clean up is executed
        /// </summary>
        public int DaysInterval
        {
            get { return m_intDaysInterval; }
            set { m_intDaysInterval = value; }
        }

        /// <summary>
        /// Get or set the Logger referenced in the LoggerUtility functions.
        /// </summary>
        public ILog MyLogger
        {
            get { return logger; }
            set
            {
                logger = value;
                m_bRemotingLogging = (logger is RemotingAppender);
            }
        }

        /// <summary>
        /// Get or set the Logger referenced in the LoggerUtility functions.
        /// </summary>
        public ILog MyLoggerLocalErrorFile
        {
            get { return loggerLocalErrorFile; }
            set { loggerLocalErrorFile = value; }
        }

        /// <summary>
        /// Get or set the Logger referenced in the LoggerUtility functions.
        /// </summary>
        public ILog MyLoggerLocalRunFile
        {
            get { return loggerLocalRunFile; }
            set { loggerLocalRunFile = value; }
        }
    }
}