﻿namespace AdvancedLogging.BE
{
    public enum HashType { Unsecured, SHA2_256, SHA2_512 };
}
