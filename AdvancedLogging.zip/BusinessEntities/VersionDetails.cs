using System;

namespace AdvancedLogging.BE
{
    public class VersionDetails
    {
        public VersionDetails()
        {
            Software = string.Empty;
            Database = string.Empty;
        }
        /// <summary>
        /// Combines the application version information
        /// </summary>
        public string Software { get; set; }

        /// <summary>
        ///Combines the database version information
        /// </summary>
        public string Database { get; set; }
    }
}
