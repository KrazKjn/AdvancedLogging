using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using static AdvancedLogging.Logging.LoggingUtils;

namespace AdvancedLogging.Logging
{
    public static class LoggingExtensions
    {
        public static KeyValuePair<string, string>[] GetHeaders(this WebHeaderCollection webHeaderCollection)
        {
            string[] keys = webHeaderCollection.AllKeys;
            var keyVals = new KeyValuePair<string, string>[keys.Length];
            for (int i = 0; i < keys.Length; i++)
                keyVals[i] = new KeyValuePair<string, string>(keys[i], webHeaderCollection[keys[i]]);
            return keyVals;
        }
        private static string Serialize(this WebHeaderCollection webHeaderCollection)
        {
            var response = new System.Text.StringBuilder();
            foreach (string k in webHeaderCollection.Keys)
                response.AppendLine(k + ": " + webHeaderCollection[k]);
            return response.ToString();
        }
        #region Log Extensions
        public static void Log(this string _string, int iDebugLevel, string strLogPrefix = "", bool bError = false)
        {
            string strMessage = "";
            if (string.IsNullOrEmpty(_string))
            {
                strMessage = string.Format("\t{0}", "(NULL)");
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
            }
            else
            {
                strMessage = string.Format("String: {0}", _string);
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                strMessage = string.Format("\tCharacters: {0}", _string.Length);
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
            }
        }

        public static void Log(this WebRequest _WebRequest, int iDebugLevel, string strLogPrefix = "", bool bError = false)
        {
            string strMessage = "";
            if (_WebRequest == null)
            {
                strMessage = string.Format("\t{0}", "(NULL)");
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
            }
            else
            {
                strMessage = string.Format("Address: {0}", _WebRequest.RequestUri.ToString());
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                strMessage = string.Format("Timeout: {0}", _WebRequest.Timeout.ToString());
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                if (_WebRequest.Credentials != null)
                {
#if __IOS__
                    System.Net.NetworkCredential? nc = _WebRequest.Credentials?.GetCredential(_WebRequest.RequestUri, "");
#else
                    System.Net.NetworkCredential nc = _WebRequest.Credentials?.GetCredential(_WebRequest.RequestUri, "");
#endif
                    if (nc == null)
                    {
                        strMessage = "Credentials: None";
                        if (bError)
                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                        else
                            WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                    }
                    else
                    {
                        if (nc.Domain == "" && nc.UserName == "")
                            strMessage = "Credentials: None";
                        else
                            strMessage = string.Format("Credentials: {0}{1}", nc.Domain == "" ? "" : nc.Domain + "\\", nc.UserName);
                        if (bError)
                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                        else
                            WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                    }
                }
                if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_DumpComplexParameterValues])
                {
                    try
                    {
                        strMessage = string.Format("Object Data  : {0}", ObjectDumper.Dump(_WebRequest));
                        if (bError)
                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                        else
                            WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                    }
                    catch (Exception ex)
                    {
                        WriteErrorPrefixNoAutoLog(strLogPrefix, "Error 'Dumping' object of type [System.Net.WebRequest].", ex);
                    }
                }
            }
        }
        public static void Log(this HttpWebRequest _httpRequest, int iDebugLevel, string strLogPrefix = "", bool bError = false)
        {
            string strMessage = "";
            if (_httpRequest == null)
            {
                strMessage = string.Format("\t{0}", "(NULL)");
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
            }
            else
            {
                strMessage = string.Format("Address: {0}", _httpRequest.Address);
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                strMessage = string.Format("Timeout: {0}", _httpRequest.Timeout.ToString());
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                if (_httpRequest.Credentials != null)
                {
#if __IOS__
                    System.Net.NetworkCredential? nc = _httpRequest.Credentials?.GetCredential(_httpRequest.RequestUri, "");
#else
                    System.Net.NetworkCredential nc = _httpRequest.Credentials?.GetCredential(_httpRequest.RequestUri, "");
#endif
                    if (nc == null)
                    {
                        strMessage = "Credentials: None";
                        if (bError)
                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                        else
                            WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                    }
                    else
                    {
                        if (nc.Domain == "" && nc.UserName == "")
                            strMessage = "Credentials: None";
                        else
                            strMessage = string.Format("Credentials: {0}{1}", nc.Domain == "" ? "" : nc.Domain + "\\", nc.UserName);
                        if (bError)
                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                        else
                            WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                    }
                }
                if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_DumpComplexParameterValues])
                {
                    try
                    {
                        strMessage = string.Format("Object Data  : {0}", ObjectDumper.Dump(_httpRequest));
                        if (bError)
                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                        else
                            WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                    }
                    catch (Exception ex)
                    {
                        WriteErrorPrefixNoAutoLog(strLogPrefix, "Error 'Dumping' object of type [System.Net.HttpWebRequest].", ex);
                    }
                }
            }
        }
        public static void Log(this System.Security.Cryptography.X509Certificates.X509CertificateCollection _X509CertificateCollection, int iDebugLevel, string strLogPrefix = "", bool bError = false)
        {
            string strMessage = "";
            foreach (var vItem in _X509CertificateCollection)
            {
                strMessage = string.Format("Issuer: {0}", vItem.Issuer);
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                strMessage = string.Format("\tExpires: {0}", vItem.GetExpirationDateString());
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                strMessage = string.Format("\tSerial#: {0}", vItem.GetSerialNumberString());
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                strMessage = string.Format("\tSubject: {0}", vItem.Subject);
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
            }
        }
        public static void Log(this System.Diagnostics.Stopwatch _Stopwatch, int iDebugLevel, string strLogPrefix = "", bool bError = false)
        {
            string strMessage = "";
            if (_Stopwatch.IsRunning)
            {
                strMessage = string.Format("Elapsed: {0}", _Stopwatch.Elapsed.ToString());
            }
            else
            {
                strMessage = string.Format("Elapsed: Not Running");
            }
            if (bError)
                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
            else
                WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
        }
        public static void Log(this AdvancedLogging.Logging.CLog _CLog, int iDebugLevel, string strLogPrefix = "", bool bError = false)
        {
            string strMessage = "";
            strMessage = string.Format("FileName: {0}", _CLog.LogFile ?? "Not Configued");
            if (bError)
                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
            else
                WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
            if (_CLog.LogFile != null)
            {
                strMessage = string.Format("Level  : {0}", _CLog.Level?.ToString());
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                else
                    WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                if (_CLog.IsDebugEnabled)
                {
                    strMessage = string.Format("Debug Level: {0}", _CLog.LogLevel.ToString());
                    if (bError)
                        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                    else
                        WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                }
            }
            if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_DumpComplexParameterValues])
            {
                try
                {
                    strMessage = string.Format("Object Data  : {0}", ObjectDumper.Dump(_CLog));
                    if (bError)
                        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                    else
                        WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                }
                catch (Exception ex)
                {
                    WriteErrorPrefixNoAutoLog(strLogPrefix, "Error 'Dumping' object of type [AdvancedLogging.Logging.CLog].", ex);
                }
            }
        }
        public static void Log(this System.Data.SqlClient.SqlCommand _SqlCommand, int iDebugLevel, string strLogPrefix = "", bool bError = false)
        {
            string strMessage = "";
            if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_SqlCommand])
            {
                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, "\tCommandText: " + _SqlCommand.CommandText);
                else
                {
                    WriteDebugPrefixNoAutoLog(strLogPrefix, "\tCommandText: " + _SqlCommand.CommandText);
                }
            }
            if (_SqlCommand.Parameters != null)
            {
                if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_SqlParameters])
                {
                    if (_SqlCommand.Parameters.Count == 0)
                    {
                        if (bError)
                            WriteErrorPrefixNoAutoLog(strLogPrefix, "\tParameters: (None)");
                        else
                            WriteDebugPrefixNoAutoLog(strLogPrefix, "\tParameters: (None)");
                    }
                    else
                    {
                        foreach (SqlParameter item in _SqlCommand.Parameters)
                        {
                            if (item.Direction == ParameterDirection.Input || item.Direction == ParameterDirection.InputOutput)
                            {
                                if (bError)
                                    WriteErrorPrefixNoAutoLog(strLogPrefix, string.Format("\t({0}){1}: {2}", SqlDbTypeToString(item), item.ParameterName, (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString()));
                                else
                                    WriteDebugPrefixNoAutoLog(strLogPrefix, string.Format("\t({0}){1}: {2}", SqlDbTypeToString(item), item.ParameterName, (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString()));
                            }
                            else
                            {
                                if (bError)
                                    WriteErrorPrefixNoAutoLog(strLogPrefix, string.Format("\t({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString()));
                                else
                                    WriteDebugPrefixNoAutoLog(strLogPrefix, string.Format("\t({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString()));
                            }
                        }
                    }
                }
            }
            if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_DumpComplexParameterValues])
            {
                try
                {
                    strMessage = string.Format("Object Data  : {0}", ObjectDumper.Dump(_SqlCommand));
                    if (bError)
                        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                    else
                        WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                }
                catch (Exception ex)
                {
                    WriteErrorPrefixNoAutoLog(strLogPrefix, "Error 'Dumping' object of type [System.Data.SqlClient.SqlCommand].", ex);
                }
            }
        }
        public static void Log(this System.Data.DataRow _dataRow, int iDebugLevel, string strLogPrefix = "", bool bError = false)
        {
            string strMessage = "";
            if (_dataRow != null)
            {
                var cols = _dataRow.ItemArray.Select(i => "" + i) // Not i.ToString() so when i is null -> ""
                                .ToArray(); // For .NET35 and before, .NET4 Join takes IEnumerable

                strMessage = "{";

                for (int iCol = 0; iCol < cols.Count(); iCol++)
                {
                    strMessage += string.Format(" \"{0}\":\"{1}\",", iCol + 1, cols[iCol]);
                }
                strMessage = strMessage.TrimEnd(',');
                strMessage += " }";
                //strMessage = string.Join("|", cols);

                if (bError)
                    WriteErrorPrefixNoAutoLog(strLogPrefix, "\tRow Data: " + strMessage);
                else
                    WriteDebugPrefixNoAutoLog(strLogPrefix, "\tParameters: " + strMessage);
            }
        }
        public static void Log(this DateTime _dateTime, int iDebugLevel, string strLogPrefix = "", bool bError = false)
        {
            string strMessage = _dateTime.ToShortDateString() + " " + _dateTime.ToShortTimeString();

            if (bError)
                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
            else
                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
        }
        public static void Log(this object _object, int iDebugLevel, string strLogPrefix = "", bool bError = false)
        {
            string strMessage = _object.ToString();

            MemberInfo[] members = _object.GetType().GetMembers(BindingFlags.Public | BindingFlags.Instance);
            foreach (var memberInfo in members.Where(p => p.Name == "ToString"))
            {
                var methodInfo = memberInfo as MethodInfo;

                if (methodInfo == null)
                    continue;

                var type = methodInfo.ReturnType;
                if (type == typeof(string) && memberInfo.Name == "ToString")
                {
                    strMessage = (string)methodInfo.Invoke(_object, null);
                    break;
                }
            }

            if (bError)
                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
            else
                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
            if (!strMessage.Contains("\n"))
            {
                if (strMessage.ToCharArray().Count(p => p == '.') > 2)
                {
                    throw new NotImplementedException("Custom ToPrint not found!");
                }
            }
        }
        public static void Log(Exception _ex, int iDebugLevel, string strLogPrefix = "", bool bError = false)
        {
            if (_ex != null)
            {
                List<string> strMessage = new List<string>();

                strMessage.Add(new string('*', 120));
                strMessage.Add(string.Format("Exception Error: {0}", _ex.GetType().Name + ": " + _ex.Message));
                strMessage.Add(new string('*', 120));
                strMessage.Add("Source: " + _ex.Source);
                strMessage.Add("TargetSite: " + _ex.TargetSite);
                // {"Attempted to divide by zero."}
                foreach (string strItem in GetAllFootprints(_ex))
                {
                    strMessage.Add(strItem);
                }
                strMessage.Add(new string('*', 120));

                foreach (string strItem in strMessage)
                {
                    if (bError)
                        WriteErrorPrefixNoAutoLog(strLogPrefix, strItem);
                    else
                        WriteDebugPrefixNoAutoLog(strLogPrefix, strItem);
                }
            }
        }
        public static void Log(this System.Net.WebException _ex, int iDebugLevel, string strLogPrefix = "", bool bError = false)
        {
            if (_ex != null)
            {
                List<string> strMessage = new List<string>();

                strMessage.Add(new string('*', 120));
                strMessage.Add(string.Format("Exception Error: {0}", _ex.GetType().Name + ": " + _ex.Message));
                strMessage.Add(new string('*', 120));
                strMessage.Add("Source: " + _ex.Source);
                strMessage.Add("TargetSite: " + _ex.TargetSite);
                if (_ex.Status == WebExceptionStatus.ProtocolError)
                {
                    // protocol errors find the statuscode in the Response
                    // the enum statuscode can be cast to an int.
                    int code = (int)((HttpWebResponse)_ex.Response).StatusCode;
                    strMessage.Add("Status Code: " + code.ToString());
                    strMessage.Add("Status Description: " + ((HttpWebResponse)_ex.Response).StatusDescription);
                    strMessage.Add("Server: " + ((HttpWebResponse)_ex.Response).Server);
                    strMessage.Add("Method: " + ((HttpWebResponse)_ex.Response).Method);
                    strMessage.Add("Response Uri: " + ((HttpWebResponse)_ex.Response).ResponseUri.OriginalString);
                }
                // {"Attempted to divide by zero."}
                foreach (string strItem in GetAllFootprints(_ex))
                {
                    strMessage.Add(strItem);
                }
                strMessage.Add(new string('*', 120));

                foreach (string strItem in strMessage)
                {
                    if (bError)
                        WriteErrorPrefixNoAutoLog(strLogPrefix, strItem);
                    else
                        WriteDebugPrefixNoAutoLog(strLogPrefix, strItem);
                }
            }
        }
        #endregion

        public static bool HasMethod(this object objectToCheck, string methodName)
        {
            MethodInfo[] methodsOfLoggingExtensions = Type.GetType("AdvancedLogging.Logging.LoggingExtensions").GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static);
            foreach (var thisMethod in methodsOfLoggingExtensions.Where(p => p.Name.ToLower() == methodName.ToLower()))
            {
                ParameterInfo[] pi = thisMethod.GetParameters();
                if (pi.Count() > 0 && pi[0].ParameterType == objectToCheck.GetType())
                {
                    return true;
                }
            }
            BindingFlags flags = BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static;
            var type = objectToCheck.GetType();
            return type.GetMethod(methodName, flags) != null;
        }
        public static object ToType(this object source, Type dest)
        {
            return Convert.ChangeType(source, dest);
        }
    }
}