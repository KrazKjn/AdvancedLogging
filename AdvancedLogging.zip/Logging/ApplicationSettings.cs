﻿using AdvancedLogging.BE;
using System;
using System.Collections.Concurrent;
using System.Data.SqlClient;
using System.IO;
using System.Xml;

namespace AdvancedLogging.Logging
{
    public class ApplicationSettings
    {
        public class PropertyChangedEventArgs : EventArgs
        {
            public string Property { get; private set; }
            public object Value { get; private set; }
            public PropertyChangedEventArgs(string _Property, object _Value)
            {
                Property = _Property;
                Value = _Value;
            }
        }
#if __IOS__
        public static event EventHandler<PropertyChangedEventArgs>? PropertyChanged;

        private static ILoggerUtility? _loggerUtility;
        public static ILoggerUtility? LoggerUtility
#else
        public static event EventHandler<PropertyChangedEventArgs> PropertyChanged;

        private static ILoggerUtility _loggerUtility;
        public static ILoggerUtility LoggerUtility
#endif
        {
            get { return _loggerUtility; }
            set
            {
                _loggerUtility = value;
                LoggingUtils.LoggerUtility = value;
#pragma warning disable CS8604 // Possible null reference argument.
                PropertyChanged?.Invoke(null, new PropertyChangedEventArgs("LoggerUtility", _loggerUtility));
#pragma warning restore CS8604 // Possible null reference argument.
            }
        }

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        private static ICLog _log;
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

        public static ICLog Logger
        {
            get { return _log; }
            set
            {
                _log = value;
                LoggingUtils.Logger = value;
                // MJH
                // SqlHelperStatic.Log = value;
#pragma warning disable CS8604 // Possible null reference argument.
                PropertyChanged?.Invoke(null, new PropertyChangedEventArgs("Logger", value));
#pragma warning restore CS8604 // Possible null reference argument.
            }
        }

        private static ConcurrentDictionary<string, object> m_dicData = new ConcurrentDictionary<string, object>();

        public static ConcurrentDictionary<string, object> Data
        {
            get { return m_dicData; }
            set
            {
                m_dicData = value;
                PropertyChanged?.Invoke(null, new PropertyChangedEventArgs("Data", Data));
            }
        }

#if __IOS__
        private static ConcurrentDictionary<string, string>? m_dicSettingsLookup = null;
#else
        private static ConcurrentDictionary<string, string> m_dicSettingsLookup = null;
#endif
        public static ConcurrentDictionary<string, string> SettingsLookup
        {
            get
            {
                if (m_dicSettingsLookup == null)
                {
                    m_dicSettingsLookup = new ConcurrentDictionary<string, string>();
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_LogFile_v1, CLog.Log4net_LogFile, (ExistingKey, oldValue) => CLog.Log4net_LogFile);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_LoggingThreshold_v1, CLog.Log4net_LoggingThreshold, (ExistingKey, oldValue) => CLog.Log4net_LoggingThreshold);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_AutoLogSQLThreshold_v1, CLog.Log4net_AutoLogSQLThreshold, (ExistingKey, oldValue) => CLog.Log4net_AutoLogSQLThreshold);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_MaxFunctionTimeThreshold_v1, CLog.Log4net_MaxFunctionTimeThreshold, (ExistingKey, oldValue) => CLog.Log4net_MaxFunctionTimeThreshold);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_DebugLevels_v1, CLog.Log4net_DebugLevels, (ExistingKey, oldValue) => CLog.Log4net_DebugLevels);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_IgnoreFunctions_v1, CLog.Log4net_IgnoreFunctions, (ExistingKey, oldValue) => CLog.Log4net_IgnoreFunctions);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_LogLevel_v1, CLog.Log4net_LogLevel, (ExistingKey, oldValue) => CLog.Log4net_LogLevel);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_AllowLoging_v1, CLog.Log4net_AllowLoging, (ExistingKey, oldValue) => CLog.Log4net_AllowLoging);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log_FunctionHeaderMethod_v1, CLog.Log_FunctionHeaderMethod, (ExistingKey, oldValue) => CLog.Log_FunctionHeaderMethod);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log_FunctionHeaderConstructor_v1, CLog.Log_FunctionHeaderConstructor, (ExistingKey, oldValue) => CLog.Log_FunctionHeaderConstructor);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log_ComplexParameterValues_v1, CLog.Log_ComplexParameterValues, (ExistingKey, oldValue) => CLog.Log_ComplexParameterValues);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log_SqlCommand_v1, CLog.Log_SqlCommand, (ExistingKey, oldValue) => CLog.Log_SqlCommand);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log_SqlParameters_v1, CLog.Log_SqlParameters, (ExistingKey, oldValue) => CLog.Log_SqlParameters);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log_SqlCommandResults_v1, CLog.Log_SqlCommandResults, (ExistingKey, oldValue) => CLog.Log_SqlCommandResults);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log_MemberTypeInformation_v1, CLog.Log_MemberTypeInformation, (ExistingKey, oldValue) => CLog.Log_MemberTypeInformation);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log_DynamicLoggingNotice_v1, CLog.Log_DynamicLoggingNotice, (ExistingKey, oldValue) => CLog.Log_DynamicLoggingNotice);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log_DumpComplexParameterValues_v1, CLog.Log_DumpComplexParameterValues, (ExistingKey, oldValue) => CLog.Log_DumpComplexParameterValues);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_EnableDebugCode_v1, CLog.Log4net_EnableDebugCode, (ExistingKey, oldValue) => CLog.Log4net_EnableDebugCode);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log_DebugDumpSQL_v1, CLog.Log_DebugDumpSQL, (ExistingKey, oldValue) => CLog.Log_DebugDumpSQL);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_IISSoapLogging_v1, CLog.Log4net_IISSoapLogging, (ExistingKey, oldValue) => CLog.Log4net_IISSoapLogging);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_MaxAutoRetriesSql_v1, CLog.Log4net_MaxAutoRetriesSql, (ExistingKey, oldValue) => CLog.Log4net_MaxAutoRetriesSql);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_AutoRetrySleepMsSql_v1, CLog.Log4net_AutoRetrySleepMsSql, (ExistingKey, oldValue) => CLog.Log4net_AutoRetrySleepMsSql_v1);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_AutoTimeoutIncrementSecondsSql_v1, CLog.Log4net_AutoTimeoutIncrementSecondsSql, (ExistingKey, oldValue) => CLog.Log4net_AutoTimeoutIncrementSecondsSql);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_MaxAutoRetriesHttp_v1, CLog.Log4net_MaxAutoRetriesHttp, (ExistingKey, oldValue) => CLog.Log4net_MaxAutoRetriesHttp);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_AutoRetrySleepMsHttp_v1, CLog.Log4net_AutoRetrySleepMsHttp, (ExistingKey, oldValue) => CLog.Log4net_AutoRetrySleepMsHttp);
                    m_dicSettingsLookup.AddOrUpdate(CLog.Log4net_AutoTimeoutIncrementMsHttp_v1, CLog.Log4net_AutoTimeoutIncrementMsHttp, (ExistingKey, oldValue) => CLog.Log4net_AutoTimeoutIncrementMsHttp);
                }
                return m_dicSettingsLookup;
            }
            set
            {
                m_dicSettingsLookup = value;
            }
        }

        private static bool m_bWriteDebug = false;

        public static bool WriteDebug
        {
            get { return m_bWriteDebug; }
            set { m_bWriteDebug = value; }
        }

        private static bool m_bWriteConsole = false;

        public static bool WriteConsole
        {
            get { return m_bWriteConsole; }
            set { m_bWriteConsole = value; }
        }

        private string m_strConfigFile = "";
        public string ConfigFile
        {
            get { return m_strConfigFile; }
            set
            {
                m_strConfigFile = value;
                ReadConfigSettings();
            }
        }

#if __IOS__
        private FileInfo? m_fiConfigFile = null;
        private FileSystemWatcher? m_fswConfigFile = null;
#else
        private FileInfo m_fiConfigFile = null;
        private FileSystemWatcher m_fswConfigFile = null;
#endif
        public bool Monitoring
        {
            get
            {
                return m_fswConfigFile == null ? false : m_fswConfigFile.EnableRaisingEvents;
            }
            set
            {
                ToggleConfigMonitoring(value);
            }
        }

        public static int MaxAutoRetriesSql = 3;
        public static int AutoRetrySleepMsSql = 250;
        public static int AutoTimeoutIncrementSecondsSql = 0;
        public static int MaxAutoRetriesHttp = 3;
        public static int AutoRetrySleepMsHttp = 250;
        public static int AutoTimeoutIncrementMsHttp = 0;
        public static bool IsRunning = true;
        public static System.Security.Authentication.SslProtocols SslProtocols = System.Security.Authentication.SslProtocols.None;
        private static ConcurrentDictionary<string, Guid> m_bagAutoLogActivity = new ConcurrentDictionary<string, Guid>();
        public static ConcurrentDictionary<string, Guid> AutoLogActivity
        {
            get { return m_bagAutoLogActivity; }
            set
            {
                m_bagAutoLogActivity = value;
                PropertyChanged?.Invoke(null, new PropertyChangedEventArgs("AutoLogActivity", AutoLogActivity));
            }
        }

#if __IOS__
        public event EventHandler<CLogClassTypes.ConfigFileChangedEventArgs>? ConfigFileChanged;
        public event EventHandler<CLogClassTypes.ConfigSettingChangedEventArgs>? ConfigSettingChanged;
#else
        public event EventHandler<CLogClassTypes.ConfigFileChangedEventArgs> ConfigFileChanged;
        public event EventHandler<CLogClassTypes.ConfigSettingChangedEventArgs> ConfigSettingChanged;
#endif
        private void Watcher_Changed(object sender, FileSystemEventArgs e)
        {
            FileInfo fi = new FileInfo(e.FullPath);
            if (m_fiConfigFile == null || fi.LastWriteTime != m_fiConfigFile.LastWriteTime)
            {
                _log?.DebugFormat(2, "Watcher_Changed: {0}", e.FullPath);
                ReadConfigSettings();
                if (ConfigFileChanged != null)
                {
                    CLogClassTypes.ConfigFileChangedEventArgs cfce = new CLogClassTypes.ConfigFileChangedEventArgs(e.FullPath, e.ChangeType);
                    ConfigFileChanged(this, cfce);
                }
                m_fiConfigFile = fi;
            }
        }

        private void ToggleConfigMonitoring(bool bEnable)
        {
            if (m_fswConfigFile != null)
            {
                m_fswConfigFile.EnableRaisingEvents = bEnable;
                if (!bEnable)
                    m_fswConfigFile = null;
            }
            if (bEnable)
            {
                // Create a new FileSystemWatcher and set its properties.
                m_fswConfigFile = new FileSystemWatcher();
                if (m_fswConfigFile != null)
                {
                    FileInfo fi = new FileInfo(m_strConfigFile);
                    m_fswConfigFile.Path = fi.DirectoryName;

                    // Watch for changes in LastAccess and LastWrite times, and
                    // the renaming of files or directories.
                    m_fswConfigFile.NotifyFilter = NotifyFilters.CreationTime
                                            | NotifyFilters.LastWrite
                                            | NotifyFilters.FileName
                                            | NotifyFilters.DirectoryName;

                    // Only watch text files.
                    m_fswConfigFile.Filter = fi.Name;

                    // Add event handlers.
                    m_fswConfigFile.Changed += Watcher_Changed;
                    m_fswConfigFile.Created += Watcher_Changed;
                    m_fswConfigFile.Deleted += Watcher_Changed;
                    m_fswConfigFile.Renamed += Watcher_Changed;

                    // Begin watching.
                    m_fswConfigFile.EnableRaisingEvents = true;
                }
            }
        }

        private void ReadConfigSettings()
        {
            _log?.DebugFormat(2, "ReadConfigSettings: {0}", ConfigFile);
            XmlDocument xlConfig = new XmlDocument();
            XmlNodeList xlAppSettings;
            bool bLoaded = false;
            int iCount = 0;
            while (!bLoaded && iCount < 5)
            {
                try
                {
                    xlConfig.Load(ConfigFile);
                    bLoaded = true;
                }
                catch (Exception ex)
                {
                    iCount++;
                    if (iCount >= 5)
                        _log?.ErrorFormat("Error Loading Config File {0}", ex.ToString());
                    else
                        System.Threading.Thread.Sleep(500);
                }
            }
            try
            {
                if (ConfigSettingChanged != null)
                {
                    // reading LogFile key value to set LogPath.LogFile  and LogPath.LoggingThreshold properties
                    xlAppSettings = xlConfig.SelectNodes("/configuration/appSettings/add");
                    foreach (XmlNode xlSetting in xlAppSettings)
                    {
                        XmlAttribute attrKey = xlSetting.Attributes["key"];
                        XmlAttribute attrValue = xlSetting.Attributes["value"];
                        bool bIsPassword = false;

                        if (attrKey != null && attrValue != null)
                        {
                        //    //Data.AddOrUpdate(attrKey.Value, attrValue.Value.Trim(), (key, oldValue) => attrValue.Value.Trim());
                        //    Logger.MonitoredSettings.AddOrUpdate(attrKey.Value, attrValue.Value, (key, oldValue) => attrValue.Value);
                            if (_log != null && _log.IsUnEvaluated(attrKey.Value, attrValue.Value))
                            {
                        //        vAutoLogFunction.WriteError(string.Format("Template Value Found!  Item: [{0}] - Value: [{1}].", attrKey.Value, attrValue.Value));
                            }
                            else
                            {
                                if (_log != null && _log.IsConnectionString(attrKey.Value, attrValue.Value))
                                {
                                    //attrValue.InnerText = ApplicationSettings.LoggerUtility.StringRemovePassword(attrValue.InnerText);
                                    SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder(attrValue.Value);
                                    scsb.Password = "**************";
                                    //strXmlData = strXmlData.Replace(attrValue.Value, scsb.ToString());
                                    bIsPassword = true;
                                }
                                if (attrKey.Value.ToLower() == "PassWord".ToLower())
                                {
                                    //attrValue.InnerText = "";
                                    //strXmlData = strXmlData.Replace(attrValue.OuterXml, attrValue.OuterXml.Replace(attrValue.InnerText, "********"));
                                    bIsPassword = true;
                                }
                                if (attrKey.Value.ToLower() == "RptServerDBPassWord".ToLower())
                                {
                                    //attrValue.InnerText = "";
                                    //strXmlData = strXmlData.Replace(attrValue.OuterXml, attrValue.OuterXml.Replace(attrValue.InnerText, "********"));
                                    bIsPassword = true;
                                }
                            }
                        }

                        object oData;
                        CLogClassTypes.ConfigSettingChangedEventArgs csc;
                        if (Data.TryGetValue(xlSetting.Attributes["key"].Value, out oData))
                        {
                            csc = new CLogClassTypes.ConfigSettingChangedEventArgs(xlSetting.Attributes["key"].Value, (string)oData, xlSetting.Attributes["value"].Value, false, bIsPassword);
                        }
                        else
                        {
                            csc = new CLogClassTypes.ConfigSettingChangedEventArgs(xlSetting.Attributes["key"].Value, "", xlSetting.Attributes["value"].Value, true, bIsPassword);
                        }
                        ConfigSettingChanged(this, csc);
                        Data.AddOrUpdate(xlSetting.Attributes["key"].Value, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                    }
                }
            }
            catch (Exception ex)
            {
                _log?.ErrorFormat("Error Loading Config File {0}", ex.ToString());
            }
        }

    }
}
