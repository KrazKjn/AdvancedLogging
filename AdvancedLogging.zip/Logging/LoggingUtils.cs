using log4net;
using log4net.Appender;
#if __IOS__
using Serilog;
#endif
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;

namespace AdvancedLogging.Logging
{
    public class LoggingUtils
    {
        private enum DebugPrintLevels
        {
            FunctionHeaderMethod = 4, // At this Level, we Print the Function Header, the Parameter Names, Types, and Values if the Value type is a Simple Data Type (i.e., Int, String, etc)
            // (5 - 7 for levels of debug)
            SqlCommand = 8,
            SqlCommandResults = 8,
            SqlParameters = 8,
            ComplexParameterValues = 12,
            FunctionHeaderConstructor = 16, // At this Level, we Print the Constructor Header, the Parameter Names, Types, and Values if the Value type is a Simple Data Type (i.e., Int, String, etc)
            // (16 - 19 for levels of debug)
            MemberTypeInformation = 20,
            DumpComplexParameterValues = 24,
            DebugDumpSQL = 100
        }
        private static int m_intMaxFunctionTimeThreshold = 120;
        public static int MaxFunctionTimeThreshold
        {
            get
            {
                return m_intMaxFunctionTimeThreshold;
            }
            set
            {
                m_intMaxFunctionTimeThreshold = value;
            }
        }
        public static bool AllowLogging = true;
        public static ConcurrentDictionary<string, bool> IgnoreLogging = new ConcurrentDictionary<string, bool>();

        private static ConcurrentDictionary<string, int> m_dicDebugPrintLevel = new ConcurrentDictionary<string, int>();

        public static ConcurrentDictionary<string, int> DebugPrintLevel
        {
            get
            {
                if (m_dicDebugPrintLevel.Count == 0)
                {
                    m_dicDebugPrintLevel.AddOrUpdate(CLog.Log_FunctionHeaderMethod, (int)DebugPrintLevels.FunctionHeaderMethod, (key, oldValue) => (int)DebugPrintLevels.FunctionHeaderMethod);
                    m_dicDebugPrintLevel.AddOrUpdate(CLog.Log_FunctionHeaderConstructor, (int)DebugPrintLevels.FunctionHeaderConstructor, (key, oldValue) => (int)DebugPrintLevels.FunctionHeaderConstructor);
                    m_dicDebugPrintLevel.AddOrUpdate(CLog.Log_ComplexParameterValues, (int)DebugPrintLevels.ComplexParameterValues, (key, oldValue) => (int)DebugPrintLevels.ComplexParameterValues);
                    m_dicDebugPrintLevel.AddOrUpdate(CLog.Log_SqlCommand, (int)DebugPrintLevels.SqlCommand, (key, oldValue) => (int)DebugPrintLevels.SqlCommand);
                    m_dicDebugPrintLevel.AddOrUpdate(CLog.Log_SqlParameters, (int)DebugPrintLevels.SqlParameters, (key, oldValue) => (int)DebugPrintLevels.SqlParameters);
                    m_dicDebugPrintLevel.AddOrUpdate(CLog.Log_SqlCommandResults, (int)DebugPrintLevels.SqlCommandResults, (key, oldValue) => (int)DebugPrintLevels.SqlCommandResults);
                    m_dicDebugPrintLevel.AddOrUpdate(CLog.Log_MemberTypeInformation, (int)DebugPrintLevels.MemberTypeInformation, (key, oldValue) => (int)DebugPrintLevels.MemberTypeInformation);
                    m_dicDebugPrintLevel.AddOrUpdate(CLog.Log_DumpComplexParameterValues, (int)DebugPrintLevels.DumpComplexParameterValues, (key, oldValue) => (int)DebugPrintLevels.DumpComplexParameterValues);
                    m_dicDebugPrintLevel.AddOrUpdate(CLog.Log_DebugDumpSQL, (int)DebugPrintLevels.DebugDumpSQL, (key, oldValue) => (int)DebugPrintLevels.DebugDumpSQL);
                }
                return m_dicDebugPrintLevel;
            }
            set { m_dicDebugPrintLevel = value; }
        }

#if __IOS__
        private static ILoggerUtility? _loggerUtility;
        public static ILoggerUtility? LoggerUtility
#else
        private static ILoggerUtility _loggerUtility;
        public static ILoggerUtility LoggerUtility
#endif		
        {
#pragma warning disable CS8603 // Possible null reference return.
            get { return _loggerUtility; }
#pragma warning restore CS8603 // Possible null reference return.
            set { _loggerUtility = value; }
        }

#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
        private static ICLog _log = null;
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.

        public static ICLog Logger
        {
#pragma warning disable CS8603 // Possible null reference return.
            get { return _log; }
#pragma warning restore CS8603 // Possible null reference return.
            set
            {
                _log = value;
#if __IOS__
                m_bRemotingLogging = false;
#else
                m_bRemotingLogging = (_log is RemotingAppender);
#endif
            }
        }

        private static bool m_bRemotingLogging = false;
        public static bool IsRemotingAppender
        {
            get
            {
                //if (_log == null)
                //    throw new NullReferenceException("LoggingUtils.Logger is NULL!");
                return m_bRemotingLogging;
            }
        }
        private static int m_intConsoleStatus = -1;
        public static bool ConsoleAttached
        {
            get
            {
                if (m_intConsoleStatus == -1)
                {
                    try
                    {
                        m_intConsoleStatus = Console.WindowHeight;
                        m_intConsoleStatus = 1;
                    }
                    catch (Exception ex)
                    {
                        if (ApplicationSettings.WriteDebug)
                            Debug.WriteLine(ex.Message);
                        m_intConsoleStatus = 0;
                    }
                }
                return (m_intConsoleStatus == 1);
            }
        }
        public static void LogFunction(MethodBase _function, object _parameters, bool bError = false, string strLogPrefix = "")
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { _function, _parameters, bError, strLogPrefix }))
            {
                LogFunctionNoAutoLog(_function, _parameters, bError, strLogPrefix);
            }
        }
#if __IOS__
        public static void LogFunctionNoAutoLog(MethodBase _function, object _parameters, bool bError = false, string strLogPrefix = "", Exception? _ex = null)
#else
        public static void LogFunctionNoAutoLog(MethodBase _function, object _parameters, bool bError = false, string strLogPrefix = "", Exception _ex = null)
#endif
        {
            try
            {
                string strMessage = strLogPrefix;
                StackTrace st = new StackTrace();
                StackFrame[] arrFrames = st.GetFrames();
                string CallPath = CLog.FunctionFullPath(arrFrames.Skip(1).ToArray());

                ParameterInfo[] pars = _function.GetParameters();
                strMessage += string.Format("[Func: {0}", _function.DeclaringType.FullName + " (" + _function.MemberType.ToString() + ")]");
                if (bError)
                    LoggingUtils.WriteError(strMessage);
                else
                {
                    Logger?.Debug(strMessage);
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage);
                }
                if (ConsoleAttached && ApplicationSettings.WriteConsole)
                    Console.WriteLine(strMessage);
                if (bError)
                {
                    if (_ex == null)
                    {
                        Logger?.ErrorFormat("\tCall Path: {0}", CallPath);
                    }
                }
                ProcessParameters(pars, _parameters, bError, strLogPrefix);
                if (_ex != null)
                {
                    WriteError("\t" + new string('*', 120));
                    WriteErrorFormat("\tException Error: {0}", _ex.GetType().Name + ": " + _ex.Message);
                    WriteError("\t" + new string('*', 120));
                    WriteErrorFormat("\tCall Path: {0}", CallPath);
                    WriteError("\tSource: " + _ex.Source);
                    WriteError("\tTargetSite: " + _ex.TargetSite);
                    // {"Attempted to divide by zero."}
                    foreach (string strItem in GetAllFootprints(_ex))
                    {
                        WriteError("\t" + strItem);
                    }
                    WriteError("\t" + new string('*', 120));
                }
            }
            catch (Exception ex)
            {
                LoggingUtils.WriteError(strLogPrefix + "Error in LogFunction: ", ex);
                if (ConsoleAttached && ApplicationSettings.WriteConsole)
                    Console.WriteLine(strLogPrefix + string.Format("Error in LogFunction: {0}", ex));
            }
            finally
            {
                if (bError)
                    LoggingUtils.WriteError("[End Func]");
                else
                {
                    Logger?.Debug("[End Func]");
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine("[End Func]");
                }
                if (ConsoleAttached && ApplicationSettings.WriteConsole)
                    Console.WriteLine("[End Func]");
            }
        }
        public static void ProcessParameters(ParameterInfo[] pars, object _parameters, bool bError = false, string strLogPrefix = "")
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { pars, _parameters, bError, strLogPrefix }))
            {
                ProcessParametersNoAutoLog(pars, _parameters, bError, strLogPrefix);
            }
        }
        private static bool PrintItForProcessParametersNoAutoLog(int iDebugLevel, string strLogPrefix, string strMessage, bool bError)
        {
            if (bError)
            {
                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                return true;
            }
            else
            {
                if (iDebugLevel == 0)
                {
                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                    return true;
                }
                else
                    return WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
            }
        }
        public static void ProcessParametersNoAutoLog(ParameterInfo[] pars, object _parameters, bool bError = false, string strLogPrefix = "", int iDebugLevel = 4)
        {
            if (pars == null || pars.Length == 0)
            {
                throw new ArgumentOutOfRangeException("Parameter [pars] is empty.");
            }
            int i = 0;
            string strMessage = "";
            foreach (PropertyInfo pi in _parameters.GetType().GetProperties())
            {
                string strName = pars[i].ParameterType.Name;
                string strFullName = pars[i].ParameterType.FullName ?? pars[i].ParameterType.Name;
                System.Type _Type = pars[i].ParameterType;

                while (pars[i].IsOut && i < pars.Length)
                {
                    strMessage = string.Format("({0}){1} N/A (Out)", pars[i].ParameterType.Name, pars[i].Name);
                    PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                    i++;
                    if (i < pars.Length)
                    {
                        strName = pars[i].ParameterType.Name;
                        strFullName = pars[i].ParameterType.FullName ?? pars[i].ParameterType.Name;
                        _Type = pars[i].ParameterType;
                    }
                }

                List<string> lstValueType = new List<string>();
                bool bIsArray = false;
                int iDimensions = 0;
#if DEBUG
                if (ApplicationSettings.Logger?.LogLevel >= iDebugLevel && ApplicationSettings.WriteDebug)
                    Debug.WriteLine((strLogPrefix == "" ? "-> " : strLogPrefix) + strFullName);
#endif
                if (strFullName.EndsWith("&"))
                {
                    strFullName = strFullName.Replace("&", "");
                }
                if (strFullName.EndsWith("[]"))
                {
#if DEBUG
                    bIsArray = pars[i].ParameterType.IsArray;
#endif
                    bIsArray = true;
                    strFullName = strFullName.Replace("[]", "");
                }
                if (strFullName.Contains("`") && strFullName.Contains("[["))
                {
                    // "System.Collections.Generic.List`1[[System.String, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]"
#if DEBUG
                    bIsArray = pars[i].ParameterType.IsArray;
#endif
                    bIsArray = true;
                    string[] arrItems = strFullName.Split('`');
                    strFullName = arrItems[0];
                    string strTemp = arrItems[1].Substring(0, arrItems[1].IndexOf("["));
                    iDimensions = int.Parse(strTemp);
                    strTemp = arrItems[1].Substring(arrItems[1].IndexOf("[") + 1);
                    strTemp = strTemp.Substring(0, strTemp.Length - 2);
                    arrItems = strTemp.Split(']');
                    foreach (string strItem in arrItems)
                    {
                        lstValueType.Add(strItem.Split('[')[1].Split(',')[0]);
                    }
                }
                if (pars[i].ParameterType.Name.Contains("`"))
                {
                    strName = pars[i].ParameterType.Name.Split('`')[0];
                }
                if (strFullName == "System.Nullable" && bIsArray && iDimensions == 1)
                {
                    bIsArray = false;
                    strFullName = lstValueType[0];
                }
                switch (strFullName)
                {
                    case "System.Data.SqlClient.SqlCommand":
                        strMessage = string.Format("({0}){1}: {2}", i < pars.Length ? strName : "???", pi.Name, ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_SqlParameters] ? "(See Command/Parameters/Values Below)" : "(See Command Below.  Set LogLevel >= " + DebugPrintLevel[CLog.Log_SqlParameters].ToString() + " for Parameters/Values)");
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError))
                        {
                            System.Data.SqlClient.SqlCommand sc = (System.Data.SqlClient.SqlCommand)pi.GetValue(_parameters, null);
                            if (sc == null)
                            {
                                strMessage = string.Format("\t{0}", "(NULL)");
                                if (bError)
                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                else
                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                            }
                            else
                            {
                                //
                                // Call LoggingExtensions.Log Extension Method
                                //
                                sc.Log(iDebugLevel, strLogPrefix);
                            }
                        }
                        break;
                    case "System.Collections.Generic.List":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError) && ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_ComplexParameterValues])
                        {
                            switch (lstValueType[0])
                            {
                                case "System.String":
                                    {
                                        List<string> vList = (List<string>)pi.GetValue(_parameters, null);
                                        if (vList == null)
                                        {
                                            strMessage = string.Format("\t{0}", "(NULL)");
                                            if (bError)
                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                            else
                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                        }
                                        else
                                        {
                                            foreach (string vItem in vList)
                                            {
                                                strMessage = string.Format("\t{0}", vItem);
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                        }
                                    }
                                    break;
                                case "System.Int":
                                    {
                                        List<int> vList = (List<int>)pi.GetValue(_parameters, null);
                                        if (vList == null)
                                        {
                                            strMessage = string.Format("\t{0}", "(NULL)");
                                            if (bError)
                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                            else
                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                        }
                                        else
                                        {
                                            foreach (int vItem in vList)
                                            {
                                                strMessage = string.Format("\t{0}", vItem.ToString());
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                        }
                                    }
                                    break;
                            }
                        }
                        break;
                    case "System.Collections.Generic.SortedDictionary":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError) && ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_ComplexParameterValues])
                        {
                            switch (lstValueType[0])
                            {
                                case "System.String":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    SortedDictionary<string, string> vList = (SortedDictionary<string, string>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    SortedDictionary<string, int> vList = (SortedDictionary<string, int>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                                case "System.Int":
                                case "System.Int32":
                                case "System.Int64":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    SortedDictionary<int, string> vList = (SortedDictionary<int, string>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    SortedDictionary<int, int> vList = (SortedDictionary<int, int>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                            }
                        }
                        break;
                    case "System.Collections.Generic.Dictionary":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError) && ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_ComplexParameterValues])
                        {
                            switch (lstValueType[0])
                            {
                                case "System.String":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    Dictionary<string, string> vList = (Dictionary<string, string>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    Dictionary<string, int> vList = (Dictionary<string, int>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                                case "System.Int":
                                case "System.Int32":
                                case "System.Int64":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    Dictionary<int, string> vList = (Dictionary<int, string>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    Dictionary<int, int> vList = (Dictionary<int, int>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                            }
                        }
                        break;
                    case "System.Collections.Concurrent.ConcurrentDictionary":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError) && ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_ComplexParameterValues])
                        {
                            switch (lstValueType[0])
                            {
                                case "System.String":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    ConcurrentDictionary<string, string> vList = (ConcurrentDictionary<string, string>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    ConcurrentDictionary<string, int> vList = (ConcurrentDictionary<string, int>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                                case "System.Int":
                                case "System.Int32":
                                case "System.Int64":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    ConcurrentDictionary<int, string> vList = (ConcurrentDictionary<int, string>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    ConcurrentDictionary<int, int> vList = (ConcurrentDictionary<int, int>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                            }
                        }
                        break;
                    case "System.Collections.Generic.SortedList":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError) && ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_ComplexParameterValues])
                        {
                            switch (lstValueType[0])
                            {
                                case "System.String":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    SortedList<string, string> vList = (SortedList<string, string>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    SortedList<string, int> vList = (SortedList<string, int>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                                case "System.Int":
                                case "System.Int32":
                                case "System.Int64":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    SortedList<int, string> vList = (SortedList<int, string>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    SortedList<int, int> vList = (SortedList<int, int>)pi.GetValue(_parameters, null);
                                                    if (vList == null)
                                                    {
                                                        strMessage = string.Format("\t{0}", "(NULL)");
                                                        if (bError)
                                                            WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        else
                                                            WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    }
                                                    else
                                                    {
                                                        foreach (var vItem in vList)
                                                        {
                                                            strMessage = string.Format("\t{0} - {1}", vItem.Key, vItem.Value);
                                                            if (bError)
                                                                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                            else
                                                                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                        }
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                            }
                        }
                        break;
                    case "System.Array":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError) && ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_ComplexParameterValues])
                        {
                            if (!(pi.GetValue(_parameters, null) is System.Array vArray))
                            {
                                strMessage = string.Format("\t{0}", "(NULL)");
                                if (bError)
                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                else
                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                            }
                            else
                            {
                                foreach (var vItem in vArray)
                                {
                                    strMessage = string.Format("\t{0}", vItem);
                                    if (bError)
                                        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                    else
                                        WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                }
                            }
                        }
                        break;
                    case "AdvancedLogging.Logging.ICLog":
                    case "AdvancedLogging.Logging.CLog":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError) && ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_ComplexParameterValues])
                        {
                            CLog log = (CLog)pi.GetValue(_parameters, null);
                            if (log == null)
                            {
                                strMessage = string.Format("\t{0}", "(NULL)");
                                if (bError)
                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                else
                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                            }
                            else
                            {
                                //
                                // Call LoggingExtensions.Log Extension Method
                                //
                                log.Log(iDebugLevel, strLogPrefix);
                            }
                        }
                        break;
                    case "System.Configuration.Configuration":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                        break;
                    case "System.Data.SqlClient.SqlParameter":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError))
                        {
                            if (bIsArray)
                            {
                                var sqlParameters = (SqlParameter[])pi.GetValue(_parameters, null);
                                if (sqlParameters == null)
                                {
                                    strMessage = string.Format("\t{0}", "(NULL)");
                                    if (bError)
                                        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                    else
                                        WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                }
                                else
                                {
                                    if (sqlParameters.Length == 0)
                                    {
                                        if (bError)
                                            WriteErrorPrefixNoAutoLog(strLogPrefix, "\tParameters: (None)");
                                        else
                                            WriteDebugPrefixNoAutoLog(strLogPrefix, "\tParameters: (None)");
                                    }
                                    else
                                    {
                                        foreach (SqlParameter item in sqlParameters)
                                        {
                                            if (item.Direction == ParameterDirection.Input || item.Direction == ParameterDirection.InputOutput)
                                            {
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, string.Format("\t({0}){1}: {2}", SqlDbTypeToString(item), item.ParameterName, (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString()));
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, string.Format("\t({0}){1}: {2}", SqlDbTypeToString(item), item.ParameterName, (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString()));
                                            }
                                            else
                                            {
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, string.Format("\t({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString()));
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, string.Format("\t({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString()));
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                SqlParameter item = (SqlParameter)pi.GetValue(_parameters, null);
                                if (item == null)
                                {
                                    strMessage = string.Format("\t{0}", "(NULL)");
                                    if (bError)
                                        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                    else
                                        WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                }
                                else
                                {
                                    if (item.Direction == ParameterDirection.Input || item.Direction == ParameterDirection.InputOutput)
                                    {
                                        if (bError)
                                            WriteErrorPrefixNoAutoLog(strLogPrefix, string.Format("({0}){1}: {2}", SqlDbTypeToString(item), item.ParameterName, (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString()));
                                        else
                                            WriteDebugPrefixNoAutoLog(strLogPrefix, string.Format("({0}){1}: {2}", SqlDbTypeToString(item), item.ParameterName, (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString()));
                                    }
                                    else
                                    {
                                        if (bError)
                                            WriteErrorPrefixNoAutoLog(strLogPrefix, string.Format("({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString()));
                                        else
                                            WriteDebugPrefixNoAutoLog(strLogPrefix, string.Format("({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString()));
                                    }
                                }
                            }
                        }
                        break;
                    case "System.Data.SqlClient.SqlParameterCollection":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                        //System.Data.SqlClient.SqlParameterCollection pc = (System.Data.SqlClient.SqlParameterCollection)pi.GetValue(_parameters, null);
                        //if (pc != null)
                        //{
                        //    if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log4net_SqlParameters])
                        //    {
                        //        LogSQLData(pc, bSuppresFunctionDeclaration:true);
                        //    }
                        //}
                        break;
                    case "System.Security.Cryptography.X509Certificates.X509CertificateCollection":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError) && ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_ComplexParameterValues])
                        {
                            System.Security.Cryptography.X509Certificates.X509CertificateCollection vList = (System.Security.Cryptography.X509Certificates.X509CertificateCollection)pi.GetValue(_parameters, null);
                            if (vList == null)
                            {
                                strMessage = string.Format("\t{0}", "(NULL)");
                                if (bError)
                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                else
                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                            }
                            else
                            {
                                //
                                // Call LoggingExtensions.Log Extension Method
                                //
                                vList.Log(iDebugLevel, strLogPrefix);
                            }
                        }
                        break;
                    case "System.Diagnostics.Stopwatch":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError) && ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_ComplexParameterValues])
                        {
                            Stopwatch sw = (Stopwatch)pi.GetValue(_parameters, null);
                            if (sw == null)
                            {
                                strMessage = string.Format("\t{0}", "(NULL)");
                                if (bError)
                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                else
                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                            }
                            else
                            {
                                //
                                // Call LoggingExtensions.Log Extension Method
                                //
                                sw.Log(iDebugLevel, strLogPrefix);
                            }
                        }
                        break;
                    case "System.Net.BufferAsyncResult":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                        //if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log4net_FunctionHeaderMethod])
                        //{
                        //    System.Net.BufferAsyncResult sw = (System.Net.BufferAsyncResult)pi.GetValue(_parameters, null);
                        //    if (sw.IsRunning)
                        //    {
                        //        strMessage = string.Format("Elapsed: {0}", sw.Elapsed.ToString());
                        //    }
                        //    else
                        //    {
                        //        strMessage = string.Format("Elapsed: Not Running");
                        //    }
                        //    if (bError)
                        //        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                        //    else
                        //        WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                        //}
                        break;
                    case "System.Net.HttpWebRequest":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError) && ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_ComplexParameterValues])
                        {
                            System.Net.HttpWebRequest httpRequest = (System.Net.HttpWebRequest)pi.GetValue(_parameters, null);
                            if (httpRequest == null)
                            {
                                strMessage = string.Format("\t{0}", "(NULL)");
                                if (bError)
                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                else
                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                            }
                            else
                            {
                                //
                                // Call LoggingExtensions.Log Extension Method
                                //
                                httpRequest.Log(iDebugLevel, strLogPrefix);
                            }
                        }
                        break;
                    case "System.Net.WebRequest":
                        strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError) && ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_ComplexParameterValues])
                        {
                            System.Net.WebRequest httpRequest = (System.Net.WebRequest)pi.GetValue(_parameters, null);
                            if (httpRequest == null)
                            {
                                strMessage = string.Format("\t{0}", "(NULL)");
                                if (bError)
                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                else
                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                            }
                            else
                            {
                                //
                                // Call LoggingExtensions.Log Extension Method
                                //
                                httpRequest.Log(iDebugLevel, strLogPrefix);
                            }
                        }
                        break;
                    default:
                        if (bIsArray)
                        {
                            strMessage = string.Format("({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                            if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError))
                            {
                                switch (strFullName)
                                {
                                    case "System.String":
                                        {
                                            string[] vList = (string[])pi.GetValue(_parameters, null);
                                            if (vList == null)
                                            {
                                                strMessage = string.Format("\t{0}", "(NULL)");
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                            else
                                            {
                                                foreach (string vItem in vList)
                                                {
                                                    strMessage = string.Format("\t{0}", vItem);
                                                    PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                                                }
                                            }
                                        }
                                        break;
                                    case "System.Int16":
                                    case "System.Int32":
                                    case "System.Int64":
                                    case "System.IntPtr":
                                        {
                                            int[] vList = (int[])pi.GetValue(_parameters, null);
                                            if (vList == null)
                                            {
                                                strMessage = string.Format("\t{0}", "(NULL)");
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                            else
                                            {
                                                foreach (int vItem in vList)
                                                {
                                                    strMessage = string.Format("\t{0}", vItem.ToString());
                                                    PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                                                }
                                            }
                                        }
                                        break;
                                    case "System.UInt16":
                                    case "System.UInt32":
                                    case "System.UInt64":
                                    case "System.UIntPtr":
                                        {
                                            uint[] vList = (uint[])pi.GetValue(_parameters, null);
                                            if (vList == null)
                                            {
                                                strMessage = string.Format("\t{0}", "(NULL)");
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                            else
                                            {
                                                foreach (uint vItem in vList)
                                                {
                                                    strMessage = string.Format("\t{0}", vItem.ToString());
                                                    PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                                                }
                                            }
                                        }
                                        break;
                                    case "System.Double":
                                    case "System.Single":
                                        {
                                            Double[] vList = (Double[])pi.GetValue(_parameters, null);
                                            if (vList == null)
                                            {
                                                strMessage = string.Format("\t{0}", "(NULL)");
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                            else
                                            {
                                                foreach (Double vItem in vList)
                                                {
                                                    strMessage = string.Format("\t{0}", vItem.ToString());
                                                    PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                                                }
                                            }
                                        }
                                        break;
                                    case "System.Boolean":
                                        {
                                            Boolean[] vList = (Boolean[])pi.GetValue(_parameters, null);
                                            if (vList == null)
                                            {
                                                strMessage = string.Format("\t{0}", "(NULL)");
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                            else
                                            {
                                                foreach (Boolean vItem in vList)
                                                {
                                                    strMessage = string.Format("\t{0}", vItem.ToString());
                                                    PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                                                }
                                            }
                                        }
                                        break;
                                    case "System.Byte":
                                        {
                                            Byte[] vList = (Byte[])pi.GetValue(_parameters, null);
                                            if (vList == null)
                                            {
                                                strMessage = string.Format("\t{0}", "(NULL)");
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                            else
                                            {
                                                foreach (Byte vItem in vList)
                                                {
                                                    strMessage = string.Format("\t{0}", vItem.ToString());
                                                    PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                                                }
                                            }
                                        }
                                        break;
                                    case "System.SByte":
                                        {
                                            SByte[] vList = (SByte[])pi.GetValue(_parameters, null);
                                            if (vList == null)
                                            {
                                                strMessage = string.Format("\t{0}", "(NULL)");
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                            else
                                            {
                                                foreach (SByte vItem in vList)
                                                {
                                                    strMessage = string.Format("\t{0}", vItem.ToString());
                                                    PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                                                }
                                            }
                                        }
                                        break;
                                    case "System.Char":
                                        {
                                            Char[] vList = (Char[])pi.GetValue(_parameters, null);
                                            if (vList == null)
                                            {
                                                strMessage = string.Format("\t{0}", "(NULL)");
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                            else
                                            {
                                                foreach (Char vItem in vList)
                                                {
                                                    strMessage = string.Format("\t{0}", vItem.ToString());
                                                    PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                                                }
                                            }
                                        }
                                        break;
                                    case "System.Decimal":
                                        {
                                            Decimal[] vList = (Decimal[])pi.GetValue(_parameters, null);
                                            if (vList == null)
                                            {
                                                strMessage = string.Format("\t{0}", "(NULL)");
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                            else
                                            {
                                                foreach (Decimal vItem in vList)
                                                {
                                                    strMessage = string.Format("\t{0}", vItem.ToString());
                                                    PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                                                }
                                            }
                                        }
                                        break;
                                    case "System.DateTime":
                                        {
                                            DateTime[] vList = (DateTime[])pi.GetValue(_parameters, null);
                                            if (vList == null)
                                            {
                                                strMessage = string.Format("\t{0}", "(NULL)");
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                            else
                                            {
                                                foreach (DateTime vItem in vList)
                                                {
                                                    strMessage = string.Format("\t{0}", vItem.ToShortDateString() + " " + vItem.ToShortTimeString());
                                                    PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError);
                                                }
                                            }
                                        }
                                        break;
                                    default:
                                        if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_DumpComplexParameterValues])
                                        {
                                            object oitem = (DateTime[])pi.GetValue(_parameters, null);
                                            if (oitem == null)
                                            {
                                                strMessage = string.Format("\t{0}", "(NULL)");
                                                if (bError)
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                else
                                                    WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                            }
                                            else
                                            {
                                                try
                                                {
                                                    strMessage = string.Format("Object Data  : {0}", ObjectDumper.Dump(oitem));
                                                    if (bError)
                                                        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    else
                                                        WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                }
                                                catch (Exception ex)
                                                {
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, string.Format("Error 'Dumping' object of type [{0}].", strFullName), ex);
                                                }
                                            }
                                        }
                                        break;
                                }
                            }
                        }
                        else
                        {
                            strMessage = string.Format("({0}){1}: {2}", i < pars.Length ? strName : "???", pi.Name, pi.GetValue(_parameters, null));
                            if (PrintItForProcessParametersNoAutoLog(iDebugLevel, strLogPrefix, strMessage, bError))
                            {
                                object oitem = pi.GetValue(_parameters, null);
                                if (oitem == null)
                                {
                                    strMessage = string.Format("\t{0}", "(NULL)");
                                    if (bError)
                                        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                    else
                                        WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                }
                                else
                                {
                                    if (!IsSimple(oitem.GetType()))
                                    {
                                        bool bLogged = false;
                                        try
                                        {
                                            dynamic dt = oitem.ToType(oitem.GetType());

                                            //
                                            // Call LoggingExtensions.Log Extension Method
                                            //
#if !__IOS__
                                            LoggingExtensions.Log(dt, iDebugLevel, strLogPrefix, bError);
#endif											
                                        }
                                        catch (NotImplementedException ex)
                                        {
                                            bLogged = (ex.Message == "Custom ToPrint not found!");
                                        }
                                        if (!bLogged)
                                        {
                                            if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_DumpComplexParameterValues])
                                            {
                                                try
                                                {
                                                    ObjectDumper.Maxlevels = 10;
                                                    strMessage = string.Format("Object Data  : {0}", ObjectDumper.Dump(oitem));
                                                    if (bError)
                                                        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                                                    else
                                                        WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage);
                                                }
                                                catch (Exception ex)
                                                {
                                                    WriteErrorPrefixNoAutoLog(strLogPrefix, string.Format("Error 'Dumping' object of type [{0}].", strFullName), ex);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        break;
                }

                i++;
            }
        }
        private static bool IsSimple(Type type)
        {
            if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
            {
                // nullable type, check if the nested type is simple.
                return IsSimple(type.GetGenericArguments()[0]);
            }
            return type.IsPrimitive
              || type.IsEnum
              || type.Equals(typeof(string))
              || type.Equals(typeof(decimal));
        }
        public static void ProcessStopWatch(ref Stopwatch sw, string strFunction, SqlCommand cmd, string strLogPrefix = "", int iDebugLevel = 4)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { sw, strFunction, cmd, strLogPrefix }))
            {
                try
                {
                    if (strFunction.ToLower().Contains(".sqlhelper") || strFunction.ToLower().Contains("httpwebextensions"))
                    {
                        if (sw?.Elapsed.TotalMinutes >= Logger?.AutoLogSQLThreshold)
                        {
                            if (Logger != null && sw != null)
                            {
                                vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                                vAutoLogFunction.WriteWarnFormat("+   Function: [{0}] - SQL Command Exceeded Time Threashold of [{1}] minutes - Actual [{2}] minutes.", strFunction, Logger.AutoLogSQLThreshold, sw.Elapsed);
                                vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                                vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                                vAutoLogFunction.WriteWarn("+   Database Call Information");
                                vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                                LogSQLData(false, strFunction, cmd.CommandText, cmd.Parameters, true, strLogPrefix);
                                vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                            }
                        }
                        else if (sw?.Elapsed.TotalSeconds >= LoggingUtils.MaxFunctionTimeThreshold)
                        {
                            vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                            vAutoLogFunction.WriteWarnFormat("+   Function: [{0}] - {1} Exceeded Time Threashold of [{2}] seconds - Actual [{3}] seconds.", strFunction, "Function", LoggingUtils.MaxFunctionTimeThreshold, sw.Elapsed);
                            vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                        }
                    }
                    else
                    {
                        if (sw?.Elapsed.TotalSeconds >= LoggingUtils.MaxFunctionTimeThreshold)
                        {
                            vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                            vAutoLogFunction.WriteWarnFormat("+   Function: [{0}] - {1} Exceeded Time Threashold of [{2}] seconds - Actual [{3}] seconds.", strFunction, "Function", LoggingUtils.MaxFunctionTimeThreshold, sw.Elapsed);
                            vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                        }
                    }
                    if (Logger?.LogLevel >= iDebugLevel && sw != null)
                    {
                        if (vAutoLogFunction.FunctionDeclarationLogged)
                            vAutoLogFunction.WriteDebugFormat("Time elapsed: {0}", sw.Elapsed);
                        else
                            vAutoLogFunction.WriteDebugFormat(strFunction + "\t: Time elapsed: {0}", sw.Elapsed);
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { sw, strFunction, cmd, strLogPrefix }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        public static void ProcessStopWatch(ref Stopwatch sw, AutoLogFunction vAutoLogFunction, SqlCommand cmd, int iDebugLevel = 4)
        {
            try
            {
                if (vAutoLogFunction.FullName.ToLower().Contains(".sqlhelper") || vAutoLogFunction.FullName.ToLower().Contains("httpwebextensions"))
                {
                    if (sw?.Elapsed.TotalMinutes >= Logger?.AutoLogSQLThreshold)
                    {
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
#pragma warning disable CS8602 // Dereference of a possibly null reference.
                        vAutoLogFunction.WriteWarnFormat("+   Function: [{0}] - SQL Command Exceeded Time Threashold of [{1}] minutes - Actual [{2}] minutes.", vAutoLogFunction.FullName, Logger.AutoLogSQLThreshold, sw.Elapsed);
#pragma warning restore CS8602 // Dereference of a possibly null reference.
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                        vAutoLogFunction.WriteWarn("+   Database Call Information");
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                        LogSQLData(false, vAutoLogFunction.FullName, cmd.CommandText, cmd.Parameters, true, vAutoLogFunction.LogPrefix);
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                    }
                    else if (sw?.Elapsed.TotalSeconds >= LoggingUtils.MaxFunctionTimeThreshold)
                    {
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                        vAutoLogFunction.WriteWarnFormat("+   Function: [{0}] - {1} Exceeded Time Threashold of [{2}] seconds - Actual [{3}] seconds.", vAutoLogFunction.FullName, "Function", LoggingUtils.MaxFunctionTimeThreshold, sw.Elapsed);
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                    }
                }
                else
                {
                    if (sw?.Elapsed.TotalSeconds >= LoggingUtils.MaxFunctionTimeThreshold)
                    {
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                        vAutoLogFunction.WriteWarnFormat("+   Function: [{0}] - {1} Exceeded Time Threashold of [{2}] seconds - Actual [{3}] seconds.", vAutoLogFunction.FullName, "Function", LoggingUtils.MaxFunctionTimeThreshold, sw.Elapsed);
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                    }
                }
                if (Logger?.LogLevel >= iDebugLevel && sw != null)
                {
                    if (vAutoLogFunction.FunctionDeclarationLogged)
                        vAutoLogFunction.WriteDebugFormat("Time elapsed: {0}", sw.Elapsed);
                    else
                        vAutoLogFunction.WriteDebugFormat(vAutoLogFunction.FullName + "\t: Time elapsed: {0}", sw.Elapsed);
                }
            }
            catch (Exception ExOuter)
            {
                vAutoLogFunction.LogFunction(new { sw, vAutoLogFunction, cmd, iDebugLevel }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                throw;
            }
        }
        public static void ProcessStopWatch(ref Stopwatch sw, string strFunction, string strMessage = "", string strLogPrefix = "", int iDebugLevel = 4)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { sw, strFunction, strMessage, strLogPrefix }))
            {
                try
                {
                    if (strFunction.ToLower().Contains(".sqlhelper") || strFunction.ToLower().Contains("httpwebextensions"))
                    {
                        if (sw?.Elapsed.TotalMinutes >= Logger?.AutoLogSQLThreshold)
                        {
                            if (Logger != null && sw != null)
                            {
                                vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                                vAutoLogFunction.WriteWarnFormat("+   Function: [{0}] - {1} Exceeded Time Threashold of [{2}] minutes - Actual [{3}] minutes.", strFunction, (strMessage.Length > 0 ? "HTTP Query" : ""), Logger.AutoLogSQLThreshold, sw.Elapsed);
                                vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                                if (strMessage.Length > 0)
                                {
                                    vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                                    vAutoLogFunction.WriteWarn("+   Web Call Information: " + strMessage);
                                }
                                vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                            }
                        }
                        else if (sw?.Elapsed.TotalSeconds >= LoggingUtils.MaxFunctionTimeThreshold)
                        {
                            vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                            vAutoLogFunction.WriteWarnFormat("+   Function: [{0}] - {1} Exceeded Time Threashold of [{2}] seconds - Actual [{3}] seconds.", strFunction, "Function", LoggingUtils.MaxFunctionTimeThreshold, sw.Elapsed);
                            vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                        }
                    }
                    else
                    {
                        if (sw?.Elapsed.TotalSeconds >= LoggingUtils.MaxFunctionTimeThreshold)
                        {
                            vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                            vAutoLogFunction.WriteWarnFormat("+   Function: [{0}] - {1} Exceeded Time Threashold of [{2}] seconds - Actual [{3}] seconds.", strFunction, "Function", LoggingUtils.MaxFunctionTimeThreshold, sw.Elapsed);
                            vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                        }
                    }
                    if (Logger?.LogLevel >= iDebugLevel && sw != null)
                    {
                        if (vAutoLogFunction.FunctionDeclarationLogged)
                            vAutoLogFunction.WriteDebugFormat("Time elapsed: {0}", sw.Elapsed);
                        else
                            vAutoLogFunction.WriteDebugFormat(strFunction + "\t: Time elapsed: {0}", sw.Elapsed);
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { sw, strFunction, strMessage, strLogPrefix }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        public static void ProcessStopWatch(ref Stopwatch sw, AutoLogFunction vAutoLogFunction, string strMessage = "", int iDebugLevel = 4)
        {
            try
            {
                if (vAutoLogFunction.FullName.ToLower().Contains(".sqlhelper") || vAutoLogFunction.FullName.ToLower().Contains("httpwebextensions"))
                {
                    if (sw?.Elapsed.TotalMinutes >= Logger?.AutoLogSQLThreshold)
                    {
                        if (Logger != null && sw != null)
                        {
                            vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                            vAutoLogFunction.WriteWarnFormat("+   {0} Exceeded Time Threashold of [{1}] minutes - Actual [{2}] minutes.", (strMessage.Length > 0 ? "HTTP Query" : ""), Logger.AutoLogSQLThreshold, sw.Elapsed);
                            vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                            if (strMessage.Length > 0)
                            {
                                vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                                vAutoLogFunction.WriteWarn("+   Web Call Information: " + strMessage);
                            }
                            vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                        }
                    }
                    else if (sw?.Elapsed.TotalSeconds >= LoggingUtils.MaxFunctionTimeThreshold)
                    {
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                        vAutoLogFunction.WriteWarnFormat("+   Function: [{0}] - {1} Exceeded Time Threashold of [{2}] seconds - Actual [{3}] seconds.", vAutoLogFunction.FullName, "Function", LoggingUtils.MaxFunctionTimeThreshold, sw.Elapsed);
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                    }
                }
                else
                {
                    if (sw?.Elapsed.TotalSeconds >= LoggingUtils.MaxFunctionTimeThreshold)
                    {
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                        vAutoLogFunction.WriteWarnFormat("+   Function: [{0}] - {1} Exceeded Time Threashold of [{2}] seconds - Actual [{3}] seconds.", vAutoLogFunction.FullName, "Function", LoggingUtils.MaxFunctionTimeThreshold, sw.Elapsed);
                        vAutoLogFunction.WriteWarn("+" + new string('-', 79));
                    }
                }
                if (Logger?.LogLevel >= iDebugLevel && sw != null)
                {
                    vAutoLogFunction.WriteDebugFormat("Time elapsed: {0}", sw.Elapsed);
                }
            }
            catch (Exception ExOuter)
            {
                vAutoLogFunction.LogFunction(new { sw, strMessage }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="CurrentMethod"></param>
        /// <param name="ParentFunction"></param>
        /// <param name="cmd"></param>
        /// <param name="ex"></param>
        public static void LogDBError(MethodBase CurrentMethod, MethodBase ParentFunction, SqlCommand cmd, Exception ex, string LogPrefix = "")
        {
            string strParent = CLog.FunctionFullName(ParentFunction);
            using (var vAutoLogFunction = new AutoLogFunction(new { CurrentMethod, ParentFunction, cmd, ex, LogPrefix }, bSuppresFunctionDeclaration: true))
            {
                try
                {

                    vAutoLogFunction.WriteError("+" + new string('-', 79));
                    vAutoLogFunction.WriteError("+   Database Error");
                    vAutoLogFunction.WriteError("+" + new string('-', 79));
                    vAutoLogFunction.WriteErrorFormat("{0}: [{1}] - {2}", CLog.FunctionFullName(CurrentMethod), cmd.CommandText, ex.ToString());
                    vAutoLogFunction.WriteError("+" + new string('-', 79));
                    vAutoLogFunction.WriteError("+   Database Call Information");
                    vAutoLogFunction.WriteError("+" + new string('-', 79));
                    LoggingUtils.LogSQLData(strParent, cmd.CommandText, cmd.Parameters, true, LogPrefix);
                    vAutoLogFunction.WriteError("+" + new string('-', 79));
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { CurrentMethod, ParentFunction, cmd, ex, LogPrefix }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="CurrentMethod"></param>
        /// <param name="ParentFunction"></param>
        /// <param name="cmdText"></param>
        /// <param name="ex"></param>
        public static void LogDBError(MethodBase CurrentMethod, MethodBase ParentFunction, string cmdText, Exception ex, string LogPrefix = "")
        {
            string strParent = CLog.FunctionFullName(ParentFunction);
            using (var vAutoLogFunction = new AutoLogFunction(new { CurrentMethod, ParentFunction, cmdText, ex, LogPrefix }, bSuppresFunctionDeclaration: true))
            {
                try
                {
                    vAutoLogFunction.WriteError("+" + new string('-', 79));
                    vAutoLogFunction.WriteError("+   Database Error");
                    vAutoLogFunction.WriteError("+" + new string('-', 79));
                    vAutoLogFunction.WriteErrorFormat("{0}: [{1}] - {2}", CLog.FunctionFullName(CurrentMethod), cmdText, ex.ToString());
                    vAutoLogFunction.WriteError("+" + new string('-', 79));
                    vAutoLogFunction.WriteError("+   Database Call Information");
                    vAutoLogFunction.WriteError("+" + new string('-', 79));
                    LoggingUtils.LogSQLData(strParent, cmdText, bForceLogWrite: true, strLogPrefix: LogPrefix);
                    vAutoLogFunction.WriteError("+" + new string('-', 79));
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { CurrentMethod, ParentFunction, cmdText, ex, LogPrefix }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public static void LogSQLData(string strFunction, string strCommand, SqlParameter[] sqlParameters, bool bForceLogWrite = false, string strLogPrefix = "")
        {
            LogSQLData(true, strFunction, strCommand, sqlParameters, bForceLogWrite, strLogPrefix);
        }

        public static void LogSQLData(bool bAutoDetect, string strFunction, string strCommand, SqlParameter[] sqlParameters, bool bForceLogWrite = false, string strLogPrefix = "")
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { bAutoDetect, strFunction, strCommand, sqlParameters, bForceLogWrite, strLogPrefix }))
            {
                try
                {
                    string strDetectedCriteria = "";
                    string strDetectedFunction;

                    if (Logger == null)
                        return;
                    if (!bForceLogWrite)
                    {
                        if (!Logger.ToLog(4, out strDetectedCriteria, out strDetectedFunction, out int iDetectedLevel)) // Log the Comamnd if LogLevel is >= to 4
                            return;
                    }
                    if (vAutoLogFunction.FunctionDeclarationLogged)
                    {
                        if (Logger.LoggingDebug())
                            vAutoLogFunction.WriteDebugFormat("Command: [{0}]", strCommand);
                        else
                            vAutoLogFunction.WriteWarnFormat("Command: [{0}]", strCommand);
                    }
                    else
                    {
                        if (Logger.LoggingDebug())
                            vAutoLogFunction.WriteDebugFormat("{0}{1}: Command: [{2}]", strFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", strCommand);
                        else
                            vAutoLogFunction.WriteWarnFormat("{0}{1}: Command: [{2}]", strFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", strCommand);
                    }
                    if (!bForceLogWrite)
                    {
                        if (!Logger.ToLog(DebugPrintLevel[CLog.Log_SqlParameters], out strDetectedCriteria, out strDetectedFunction, out int iDetectedLevel)) // Log the Parameters if LogLevel is >= to 10
                            return;
                    }
                    if (sqlParameters == null || sqlParameters.Length == 0)
                    {
                        if (Logger.IsDebugEnabled)
                            vAutoLogFunction.WriteDebug("No Parameters!");
                        else
                            vAutoLogFunction.WriteWarn("No Parameters!");
                    }
                    else
                    {
                        foreach (SqlParameter item in sqlParameters)
                        {
                            if (item.Direction == ParameterDirection.Input || item.Direction == ParameterDirection.InputOutput)
                            {
                                if (Logger.IsDebugEnabled)
                                    vAutoLogFunction.WriteDebugFormat("({0}){1}: {2}", SqlDbTypeToString(item), item.ParameterName, (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                                else
                                    vAutoLogFunction.WriteLogFormat("({0}){1}: {2}", SqlDbTypeToString(item), item.ParameterName, (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                            }
                            else
                            {
                                if (Logger.IsDebugEnabled)
                                    vAutoLogFunction.WriteDebugFormat("({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                                else
                                    vAutoLogFunction.WriteLogFormat("({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                            }
                        }
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { bAutoDetect, strFunction, strCommand, sqlParameters, bForceLogWrite, strLogPrefix }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

#if __IOS__
        public static void LogSQLData(string strFunction, string strCommand, SqlParameterCollection? sqlParameters = null, bool bForceLogWrite = false, string strLogPrefix = "")
#else
        public static void LogSQLData(string strFunction, string strCommand, SqlParameterCollection sqlParameters = null, bool bForceLogWrite = false, string strLogPrefix = "")
#endif
        {
            LogSQLData(true, strFunction, strCommand, sqlParameters, bForceLogWrite, strLogPrefix);
        }

#if __IOS__
        public static void LogSQLData(bool bAutoDetect, string strFunction, string strCommand, SqlParameterCollection? sqlParameters = null, bool bForceLogWrite = false, string strLogPrefix = "")
#else
        public static void LogSQLData(bool bAutoDetect, string strFunction, string strCommand, SqlParameterCollection sqlParameters = null, bool bForceLogWrite = false, string strLogPrefix = "")
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { bAutoDetect, strFunction, strCommand, sqlParameters, bForceLogWrite, strLogPrefix }))
            {
                try
                {
                    string strDetectedCriteria = "";
                    string strDetectedFunction = "";

                    if (Logger == null)
                        return;
                    if (!bForceLogWrite)
                    {
                        if (bAutoDetect && !Logger.ToLog(4, out strDetectedCriteria, out strDetectedFunction, out int iDetectedLevel)) // Log the Comamnd if LogLevel is >= to 4
                            return;
                    }
                    if (vAutoLogFunction.FunctionDeclarationLogged)
                    {
                        if (Logger.LoggingDebug())
                            vAutoLogFunction.WriteDebugFormat("Command: [{0}]", strCommand);
                        else
                            vAutoLogFunction.WriteWarnFormat("Command: [{0}]", strCommand);
                    }
                    else
                    {
                        if (Logger.LoggingDebug())
                            vAutoLogFunction.WriteDebugFormat("{0}{1}: Command: [{2}]", strFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", strCommand);
                        else
                            vAutoLogFunction.WriteWarnFormat("{0}{1}: Command: [{2}]", strFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", strCommand);
                    }
                    if (!bForceLogWrite)
                    {
                        if (bAutoDetect && !Logger.ToLog(DebugPrintLevel[CLog.Log_SqlParameters], out strDetectedCriteria, out strDetectedFunction, out int iDetectedLevel)) // Log the Parameters if LogLevel is >= to 10
                            return;
                    }
                    if (sqlParameters == null || sqlParameters.Count == 0)
                    {
                        if (Logger.IsDebugEnabled)
                            vAutoLogFunction.WriteDebugFormat("No Parameters!");
                        else
                            vAutoLogFunction.WriteWarnFormat("No Parameters!");
                    }
                    else
                    {
                        foreach (SqlParameter item in sqlParameters)
                        {
                            if (item.Direction == ParameterDirection.Input || item.Direction == ParameterDirection.InputOutput)
                            {
                                if (Logger.IsDebugEnabled)
                                    vAutoLogFunction.WriteDebugFormat("({0}){1}: {2}", SqlDbTypeToString(item), item.ParameterName, SqlDbTypeToString(item), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                                else
                                    vAutoLogFunction.WriteLogFormat("({0}){1}: {2}", SqlDbTypeToString(item), item.ParameterName, (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                            }
                            else
                            {
                                if (Logger.IsDebugEnabled)
                                    vAutoLogFunction.WriteDebugFormat("({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                                else
                                    vAutoLogFunction.WriteLogFormat("({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                            }
                        }
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { bAutoDetect, strFunction, strCommand, sqlParameters, bForceLogWrite, strLogPrefix }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

#if __IOS__
        public static void LogSQLData(SqlParameterCollection? sqlParameters = null, string strAppendLogPrefix = "", int iTabs = -1, bool bSuppresFunctionDeclaration = false)
#else
        public static void LogSQLData(SqlParameterCollection sqlParameters = null, string strAppendLogPrefix = "", int iTabs = -1, bool bSuppresFunctionDeclaration = false)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { sqlParameters, strAppendLogPrefix }, null, iTabs, bSuppresFunctionDeclaration))
            {
                try
                {
                    if (strAppendLogPrefix.Length > 0)
                        vAutoLogFunction.LogPrefix = strAppendLogPrefix;
                    if (Logger == null)
                        return;
                    if (!Logger.ToLog(DebugPrintLevel[CLog.Log_SqlParameters], out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel)) // Log the Parameters if LogLevel is >= to 10
                        return;
                    if (sqlParameters == null)
                    {
                        if (Logger.IsDebugEnabled)
                            vAutoLogFunction.WriteDebugFormat("No Parameters:");
                        else
                            vAutoLogFunction.WriteWarnFormat("No Parameters:");
                    }
                    else
                    {
                        foreach (SqlParameter item in sqlParameters)
                        {
                            if (item.Direction == ParameterDirection.Input || item.Direction == ParameterDirection.InputOutput)
                            {
                                if (Logger.IsDebugEnabled)
                                    vAutoLogFunction.WriteDebugFormat("({0}){1}: {2}", SqlDbTypeToString(item), item.ParameterName, (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                                else
                                    vAutoLogFunction.WriteLogFormat("({0}){1}: {2}", SqlDbTypeToString(item), item.ParameterName, (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                            }
                            else
                            {
                                if (Logger.IsDebugEnabled)
                                    vAutoLogFunction.WriteDebugFormat("({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                                else
                                    vAutoLogFunction.WriteLogFormat("({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                            }
                        }
                    }
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { sqlParameters, strAppendLogPrefix }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        public static void LogSQLOutData(SqlParameterCollection sqlParameters, AutoLogFunction vAutoLogFunction)
        {
            if (sqlParameters != null)
            {
                foreach (SqlParameter item in sqlParameters)
                {
                    if (item.Direction == ParameterDirection.Output ||
                        item.Direction == ParameterDirection.InputOutput ||
                        item.Direction == ParameterDirection.ReturnValue)
                    {
                        if (Logger != null && Logger.IsDebugEnabled)
                            vAutoLogFunction.WriteDebugFormat("\t({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                        else
                            vAutoLogFunction.WriteLogFormat("\t({0}){1}: {3}({2})", item.ParameterName, SqlDbTypeToString(item), item.Direction.ToString(), (item.Value == System.DBNull.Value || item.Value == null) ? "(NULL)" : item.Value.ToString());
                    }
                }
            }
        }

#if __IOS__
        public static void WriteLog(string strMessage, Exception? ex = null)
#else
        public static void WriteLog(string strMessage, Exception ex = null)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strMessage, ex }))
            {
                WriteLogNoAutoLog(strMessage, ex);
            }
        }
#if __IOS__
        public static void WriteLogNoAutoLog(string strMessage, Exception? ex = null)
#else
        public static void WriteLogNoAutoLog(string strMessage, Exception ex = null)
#endif
        {
            try
            {
                if (ex == null)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strMessage);
                }
                else
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage + "; Error: " + ex);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strMessage + "; Error: " + ex);
                }
#if __IOS__
                if (ex == null)
                    Log.Information(strMessage);
                else
                    Log.Information(ex, strMessage);
#endif
                Logger?.Info(strMessage, ex);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { strMessage, ex }, true);
#if __IOS__
                Log.Debug(ExOuter, string.Format("{0}", System.Reflection.MethodBase.GetCurrentMethod().Name));
#endif
                Logger?.Debug(string.Format("{0}", System.Reflection.MethodBase.GetCurrentMethod().Name), ExOuter);
                throw;
            }
        }
        //public static void WriteLogPrefix(string strLogPrefix, string strMessage, Exception ex = null)
        //{
        //    using (var vAutoLogFunction = new AutoLogFunction(new { strMessage, ex }))
        //    {
        //        try
        //        {
        //            if (ex == null)
        //            {
        //                Debug.WriteLine(strLogPrefix + strMessage);
        //                if (ConsoleAttached && ApplicationSettings.WriteConsole)
        //                    Console.WriteLine(strLogPrefix + strMessage);
        //            }
        //            else
        //            {
        //                Debug.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
        //                if (ConsoleAttached && ApplicationSettings.WriteConsole)
        //                    Console.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
        //            }
        //            Logger?.InfoPrefix(strLogPrefix, strMessage, ex);
        //        }
        //        catch (Exception ExOuter)
        //        {
        //            LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), new { strMessage, ex }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
        //            Logger?.Debug(string.Format("{0}", System.Reflection.MethodBase.GetCurrentMethod().Name), ExOuter);
        //            throw;
        //        }
        //    }
        //}
#if __IOS__
        public static void WriteLogPrefix(string strLogPrefix, string strMessage, Exception? ex = null)
#else
        public static void WriteLogPrefix(string strLogPrefix, string strMessage, Exception ex = null)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strLogPrefix, strMessage, ex }))
            {
                WriteLogPrefixNoAutoLog(strLogPrefix, strMessage, ex);
            }
        }
#if __IOS__
        public static void WriteLogPrefixNoAutoLog(string strLogPrefix, string strMessage, Exception? ex = null)
#else
        public static void WriteLogPrefixNoAutoLog(string strLogPrefix, string strMessage, Exception ex = null)
#endif
        {
            try
            {
                if (ex == null)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strLogPrefix + strMessage);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strLogPrefix + strMessage);
                }
                else
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
                }
#if __IOS__
                if (ex == null)
                    Log.Information(strLogPrefix + strMessage);
                else
                    Log.Information(ex, strLogPrefix + strMessage);
#endif
                Logger?.Info(strLogPrefix + strMessage, ex);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { strLogPrefix, strMessage, ex }, true, _ex: ExOuter);
#if __IOS__
                Log.Debug(ExOuter, string.Format("{0}{1}", strLogPrefix, System.Reflection.MethodBase.GetCurrentMethod().Name));
#endif
                Logger?.Debug(string.Format("{0}{1}", strLogPrefix, System.Reflection.MethodBase.GetCurrentMethod().Name), ExOuter);
                throw;
            }
        }
        public static void WriteLogFormat(string format, params object[] args)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { format, args }))
            {
                WriteLogFormatNoAutoLog(format, args);
            }
        }
        public static void WriteLogFormatNoAutoLog(string format, params object[] args)
        {
            try
            {
                string strMessage = string.Format(format, args);
                if (ApplicationSettings.WriteDebug)
                    Debug.WriteLine(strMessage);
                if (ConsoleAttached && ApplicationSettings.WriteConsole)
                    Console.WriteLine(strMessage);
#if __IOS__
                Log.Information(strMessage);
#endif
                Logger?.Info(strMessage);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { format, args }, true, _ex: ExOuter);
                throw;
            }
        }
#if __IOS__
        public static void WriteDebug(string strMessage, Exception? ex = null)
#else
        public static void WriteDebug(string strMessage, Exception ex = null)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strMessage, ex }))
            {
                WriteDebugNoAutoLog(strMessage, ex);
            }
        }
#if __IOS__
        public static void WriteDebugNoAutoLog(string strMessage, Exception? ex = null)
#else
        public static void WriteDebugNoAutoLog(string strMessage, Exception ex = null)
#endif
        {
            try
            {
                if (ex == null)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strMessage);
                }
                else
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage + "; Error: " + ex);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strMessage + "; Error: " + ex);
                }
                Logger?.Debug(strMessage, ex);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { strMessage, ex }, true, _ex: ExOuter);
                throw;
            }
        }

#if __IOS__
        public static void WriteDebugPrefix(string strLogPrefix, string strMessage, Exception? ex = null)
#else
        public static void WriteDebugPrefix(string strLogPrefix, string strMessage, Exception ex = null)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strLogPrefix, strMessage, ex }))
            {
                WriteDebugPrefixNoAutoLog(strLogPrefix, strMessage, ex);
            }
        }
#if __IOS__
        public static void WriteDebugPrefixNoAutoLog(string strLogPrefix, string strMessage, Exception? ex = null)
#else
        public static void WriteDebugPrefixNoAutoLog(string strLogPrefix, string strMessage, Exception ex = null)
#endif
        {
            try
            {
                if (ex == null)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strLogPrefix + strMessage);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strLogPrefix + strMessage);
                }
                else
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
                }
                Logger?.Debug(strLogPrefix + strMessage, ex);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { strMessage, ex }, true, _ex: ExOuter);
                throw;
            }
        }
#if __IOS__
        public static bool WriteDebug(int DebugLevel, string strMessage, Exception? ex = null)
#else
        public static bool WriteDebug(int DebugLevel, string strMessage, Exception ex = null)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { DebugLevel, strMessage, ex }))
            {
                return WriteDebugNoAutoLog(DebugLevel, strMessage, ex);
            }
        }
#if __IOS__
        public static bool WriteDebugNoAutoLog(int DebugLevel, string strMessage, Exception? ex = null)
#else
        public static bool WriteDebugNoAutoLog(int DebugLevel, string strMessage, Exception ex = null)
#endif
        {
            try
            {
                if (ex == null)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strMessage);
                }
                else
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage + "; Error: " + ex);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strMessage + "; Error: " + ex);
                }
                if (Logger == null)
                    return false;
                else
                {
#pragma warning disable CS8604
                    return Logger.Debug(DebugLevel, strMessage, ex);
#pragma warning restore CS8604
                }
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { DebugLevel, strMessage, ex }, true, _ex: ExOuter);
                throw;
            }
        }
#if __IOS__
        public static bool WriteDebugPrefix(int DebugLevel, string strLogPrefix, string strMessage, Exception? ex = null)
#else
        public static bool WriteDebugPrefix(int DebugLevel, string strLogPrefix, string strMessage, Exception ex = null)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { DebugLevel, strLogPrefix, strMessage, ex }))
            {
                return WriteDebugPrefixNoAutoLog(DebugLevel, strLogPrefix, strMessage, ex);
            }
        }
#if __IOS__
        public static bool WriteDebugPrefixNoAutoLog(int DebugLevel, string strLogPrefix, string strMessage, Exception? ex = null)
#else
        public static bool WriteDebugPrefixNoAutoLog(int DebugLevel, string strLogPrefix, string strMessage, Exception ex = null)
#endif
        {
            try
            {
                if (ex == null)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strLogPrefix + strMessage);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strLogPrefix + strMessage);
                }
                else
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
                }
#pragma warning disable IDE0075 // Simplify conditional expression
#pragma warning disable CS8604 // Possible null reference argument.
                return Logger == null ? false : Logger.DebugPrefix(DebugLevel, strLogPrefix, strMessage, ex);
#pragma warning restore CS8604 // Possible null reference argument.
#pragma warning restore IDE0075 // Simplify conditional expression
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { DebugLevel, strMessage, ex }, true, _ex: ExOuter);
                throw;
            }
        }
        public static void WriteDebugFormatPrefix(string strLogPrefix, string format, params object[] args)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strLogPrefix, format, args }))
            {
                WriteDebugFormatPrefixNoAutoLog(strLogPrefix, format, args);
            }
        }
        public static void WriteDebugFormatPrefixNoAutoLog(string strLogPrefix, string format, params object[] args)
        {
            try
            {
                string strMessage = string.Format(format, args);
                if (ApplicationSettings.WriteDebug)
                    Debug.WriteLine(strMessage);
                if (ConsoleAttached && ApplicationSettings.WriteConsole)
                    Console.WriteLine(strMessage);
#pragma warning disable CS8625
                Logger?.DebugPrefix(strLogPrefix, strMessage, null);
#pragma warning restore CS8625
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { strLogPrefix, format, args }, true, strLogPrefix);
                Logger?.Debug(strLogPrefix + string.Format("{0}", System.Reflection.MethodBase.GetCurrentMethod().Name), ExOuter);
                throw;
            }
        }
        public static void WriteDebugFormatPrefix(string strLogPrefix, string functionName, string format, params object[] args)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strLogPrefix, functionName, format, args }))
            {
                WriteDebugFormatPrefixNoAutoLog(strLogPrefix, functionName, format, args);
            }
        }
        public static void WriteDebugFormatPrefixNoAutoLog(string strLogPrefix, string functionName, string format, params object[] args)
        {
            try
            {
                string strMessage = string.Format(format, args);
                if (ApplicationSettings.WriteDebug)
                    Debug.WriteLine(strMessage);
                if (ConsoleAttached && ApplicationSettings.WriteConsole)
                    Console.WriteLine(strMessage);
#pragma warning disable CS8625
                Logger?.DebugPrefix(strLogPrefix, functionName, strMessage, null);
#pragma warning restore CS8625
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { strLogPrefix, functionName, format, args }, true, strLogPrefix);
                Logger?.Debug(strLogPrefix + string.Format("{0}", System.Reflection.MethodBase.GetCurrentMethod().Name), ExOuter);
                throw;
            }
        }
        public static bool WriteDebugFormatPrefix(int DebugLevel, string strLogPrefix, string format, params object[] args)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { DebugLevel, strLogPrefix, format, args }))
            {
                return WriteDebugFormatPrefixNoAutoLog(DebugLevel, strLogPrefix, format, args);
            }
        }
        public static bool WriteDebugFormatPrefixNoAutoLog(int DebugLevel, string strLogPrefix, string format, params object[] args)
        {
            try
            {
                string strMessage = string.Format(format, args);
                if (ApplicationSettings.WriteDebug)
                    Debug.WriteLine(strMessage);
                if (ConsoleAttached && ApplicationSettings.WriteConsole)
                    Console.WriteLine(strMessage);
#pragma warning disable CS8625
                return Logger == null ? false : Logger.DebugPrefix(DebugLevel, strLogPrefix, strMessage, null);
#pragma warning restore CS8625
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { DebugLevel, strLogPrefix, format, args }, true, strLogPrefix);
                Logger?.Debug(strLogPrefix + string.Format("{0}", System.Reflection.MethodBase.GetCurrentMethod().Name), ExOuter);
                throw;
            }
        }
        public static bool WriteDebugFormatPrefix(int DebugLevel, string strLogPrefix, string functionName, string format, params object[] args)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { DebugLevel, strLogPrefix, functionName, format, args }))
            {
                return WriteDebugFormatPrefixNoAutoLog(DebugLevel, strLogPrefix, functionName, format, args);
            }
        }
        public static bool WriteDebugFormatPrefixNoAutoLog(int DebugLevel, string strLogPrefix, string functionName, string format, params object[] args)
        {
            try
            {
                string strMessage = string.Format(format, args);
                if (ApplicationSettings.WriteDebug)
                    Debug.WriteLine(strMessage);
                if (ConsoleAttached && ApplicationSettings.WriteConsole)
                    Console.WriteLine(strMessage);
#pragma warning disable CS8625
                return Logger == null ? false : Logger.DebugPrefix(DebugLevel, strLogPrefix, functionName, strMessage, null);
#pragma warning restore CS8625
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { DebugLevel, strLogPrefix, functionName, format, args }, true, strLogPrefix);
                Logger?.Error(strLogPrefix + string.Format("{0}", System.Reflection.MethodBase.GetCurrentMethod().Name), ExOuter);
                throw;
            }
        }
#if __IOS__
        public static void WriteError(string strMessage, Exception? ex = null)
#else
        public static void WriteError(string strMessage, Exception ex = null)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strMessage, ex }))
            {
                WriteErrorNoAutoLog(strMessage, ex);
            }
        }
#if __IOS__
        public static void WriteErrorNoAutoLog(string strMessage, Exception? ex = null)
#else
        public static void WriteErrorNoAutoLog(string strMessage, Exception ex = null)
#endif
        {
            try
            {
                if (ex == null)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strMessage);
                }
                else
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage + "; Error: " + ex);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strMessage + "; Error: " + ex);
                }
                Logger?.Error(strMessage, ex);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { strMessage, ex }, true, _ex: ExOuter);
                throw;
            }
        }
#if __IOS__
        public static void WriteErrorPrefix(string strLogPrefix, string strMessage, Exception? ex = null)
#else
        public static void WriteErrorPrefix(string strLogPrefix, string strMessage, Exception ex = null)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strLogPrefix, strMessage, ex }))
            {
                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage, ex);
            }
        }
#if __IOS__
        public static void WriteErrorPrefixNoAutoLog(string strLogPrefix, string strMessage, Exception? ex = null)
#else
        public static void WriteErrorPrefixNoAutoLog(string strLogPrefix, string strMessage, Exception ex = null)
#endif
        {
            try
            {
                if (ex == null)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strLogPrefix + strMessage);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strLogPrefix + strMessage);
                }
                else
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
                }
                Logger?.Error(strLogPrefix + strMessage, ex);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { strMessage, ex }, true, _ex: ExOuter);
                throw;
            }
        }
        public static void WriteErrorFormat(string format, params object[] args)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { format, args }))
            {
                WriteErrorFormatNoAutoLog(format, args);
            }
        }
        public static void WriteErrorFormatNoAutoLog(string format, params object[] args)
        {
            try
            {
                string strMessage = string.Format(format, args);
                if (ApplicationSettings.WriteDebug)
                    Debug.WriteLine(strMessage);
                if (ConsoleAttached && ApplicationSettings.WriteConsole)
                    Console.WriteLine(strMessage);
                Logger?.ErrorFormat(strMessage);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { format, args }, true, _ex: ExOuter);
                throw;
            }
        }
#if __IOS__
        public static void WriteFatal(string strMessage, Exception? ex = null)
#else
        public static void WriteFatal(string strMessage, Exception ex = null)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strMessage, ex }))
            {
                WriteFatalNoAutoLog(strMessage, ex);
            }
        }
#if __IOS__
        public static void WriteFatalNoAutoLog(string strMessage, Exception? ex = null)
#else
        public static void WriteFatalNoAutoLog(string strMessage, Exception ex = null)
#endif
        {
            try
            {
                if (ex == null)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strMessage);
                }
                else
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage + "; Error: " + ex);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strMessage + "; Error: " + ex);
                }
                Logger?.Fatal(strMessage, ex);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { strMessage, ex }, true, _ex: ExOuter);
                throw;
            }
        }
#if __IOS__
        public static void WriteFatalPrefix(string strLogPrefix, string strMessage, Exception? ex = null)
#else
        public static void WriteFatalPrefix(string strLogPrefix, string strMessage, Exception ex = null)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strLogPrefix, strMessage, ex }))
            {
                WriteFatalPrefixNoAutoLog(strLogPrefix, strMessage, ex);
            }
        }
#if __IOS__
        public static void WriteFatalPrefixNoAutoLog(string strLogPrefix, string strMessage, Exception? ex = null)
#else
        public static void WriteFatalPrefixNoAutoLog(string strLogPrefix, string strMessage, Exception ex = null)
#endif
        {
            try
            {
                if (ex == null)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strLogPrefix + strMessage);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strLogPrefix + strMessage);
                }
                else
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
                }
                Logger?.Error(strLogPrefix + strMessage, ex);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { strMessage, ex }, true, _ex: ExOuter);
                throw;
            }
        }
        public static void WriteFatalFormat(string format, params object[] args)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { format, args }))
            {
                WriteFatalFormatNoAutoLog(format, args);
            }
        }
        public static void WriteFatalFormatNoAutoLog(string format, params object[] args)
        {
            try
            {
                string strMessage = string.Format(format, args);
                if (ApplicationSettings.WriteDebug)
                    Debug.WriteLine(strMessage);
                if (ConsoleAttached && ApplicationSettings.WriteConsole)
                    Console.WriteLine(strMessage);
                Logger?.ErrorFormat(strMessage);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { format, args }, true, _ex: ExOuter);
                throw;
            }
        }
#if __IOS__
        public static void WriteWarn(string strMessage, Exception? ex = null)
#else
        public static void WriteWarn(string strMessage, Exception ex = null)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strMessage, ex }))
            {
                WriteWarnAutoLog(strMessage, ex);
            }
        }
#if __IOS__
        public static void WriteWarnAutoLog(string strMessage, Exception? ex = null)
#else
        public static void WriteWarnAutoLog(string strMessage, Exception ex = null)
#endif
        {
            try
            {
                if (ex == null)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strMessage);
                }
                else
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strMessage + "; Error: " + ex);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strMessage + "; Error: " + ex);
                }
                Logger?.Warn(strMessage, ex);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { strMessage, ex }, true, _ex: ExOuter);
                throw;
            }
        }
#if __IOS__
        public static void WriteWarnPrefix(string strLogPrefix, string strMessage, Exception? ex = null)
#else
        public static void WriteWarnPrefix(string strLogPrefix, string strMessage, Exception ex = null)
#endif
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strLogPrefix, strMessage, ex }))
            {
                WriteWarnPrefixNoAutoLog(strLogPrefix, strMessage, ex);
            }
        }
#if __IOS__
        public static void WriteWarnPrefixNoAutoLog(string strLogPrefix, string strMessage, Exception? ex = null)
#else
        public static void WriteWarnPrefixNoAutoLog(string strLogPrefix, string strMessage, Exception ex = null)
#endif
        {
            try
            {
                if (ex == null)
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strLogPrefix + strMessage);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strLogPrefix + strMessage);
                }
                else
                {
                    if (ApplicationSettings.WriteDebug)
                        Debug.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
                    if (ConsoleAttached && ApplicationSettings.WriteConsole)
                        Console.WriteLine(strLogPrefix + strMessage + "; Error: " + ex);
                }
                Logger?.Warn(strLogPrefix + strMessage, ex);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { strMessage, ex }, true, strLogPrefix);
                Logger?.Error(strLogPrefix + string.Format("{0}", System.Reflection.MethodBase.GetCurrentMethod().Name), ExOuter);
                throw;
            }
        }
        public static void WriteWarnFormat(string format, params object[] args)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { format, args }))
            {
                WriteWarnFormatNoAutoLog(format, args);
            }
        }
        public static void WriteWarnFormatNoAutoLog(string format, params object[] args)
        {
            try
            {
                string strMessage = string.Format(format, args);
                if (ApplicationSettings.WriteDebug)
                    Debug.WriteLine(strMessage);
                if (ConsoleAttached && ApplicationSettings.WriteConsole)
                    Console.WriteLine(strMessage);
                Logger?.Warn(strMessage);
            }
            catch (Exception ExOuter)
            {
                LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { format, args }, true, _ex: ExOuter);
                throw;
            }
        }
        public static string[] GetAllFootprints(Exception x)
        {
            var st = new StackTrace(x, true);
            var frames = st.GetFrames();
            List<string> traceString = new List<string>();

            foreach (var frame in frames)
            {
                if (frame.GetFileLineNumber() < 1)
                    continue;

                traceString.Add("File: " + frame.GetFileName() + ", Method:" + frame.GetMethod().Name + ", LineNumber: " + frame.GetFileLineNumber());
            }
            return traceString.ToArray();
        }
        public static string SqlDbTypeToString(SqlParameter _SqlParameter)
        {
            try
            {
                switch (_SqlParameter.SqlDbType)
                {
                    case SqlDbType.Char:
                    case SqlDbType.NChar:
                    case SqlDbType.VarChar:
                    case SqlDbType.NVarChar:
                        return _SqlParameter.SqlDbType.ToString() + "(" + _SqlParameter.Size.ToString("#,##0") + ")";
                    default:
                        return _SqlParameter.SqlDbType.ToString();
                }
            }
            catch (Exception ExOuter)
            {
                LoggingUtils.WriteError("Error in SqlDbTypeToString:", ExOuter);
                throw;
            }
        }
    }
}
