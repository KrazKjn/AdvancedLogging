using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml;
using log4net;
using log4net.Core;
using AdvancedLogging.BE;
using System.Collections.Concurrent;
using static AdvancedLogging.Logging.LoggingUtils;
using System.Xml.Linq;
using System.Data.SqlClient;
using log4net.Repository.Hierarchy;
using log4net.Appender;
using log4net.Util;

#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning disable CS8602 // Dereference of a possibly null reference.
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
namespace AdvancedLogging.Logging
{
    public class CLog : ICLog
    {
        //public enum EntryType
        //{
        //    Info,
        //    Warning,
        //    Error
        //}
        private Dictionary<string, int> m_dicDebugLevels = new Dictionary<string, int>();

        public Dictionary<string, int> DebugLevels
        {
            get { return m_dicDebugLevels; }
            set { m_dicDebugLevels = value; }
        }
        private ConcurrentDictionary<string, string> m_dicMonitoredSettings = new ConcurrentDictionary<string, string>();
        public ConcurrentDictionary<string, string> MonitoredSettings
        {
            get { return m_dicMonitoredSettings; }
            set { m_dicMonitoredSettings = value; }
        }
        private ConcurrentDictionary<string, bool> m_dicIsPassword = null;

        public ConcurrentDictionary<string, bool> IsPassword
        {
            get
            {
                if (m_dicIsPassword == null)
                {
                    m_dicIsPassword = new ConcurrentDictionary<string, bool>();
                    m_dicIsPassword.AddOrUpdate("ConnString", true, (ExistingKey, oldValue) => true);
                    m_dicIsPassword.AddOrUpdate("Password", true, (ExistingKey, oldValue) => true);
                    m_dicIsPassword.AddOrUpdate("Pwd", true, (ExistingKey, oldValue) => true);
                }
                return m_dicIsPassword;
            }
            set
            {
                m_dicIsPassword = value;
            }
        }
        #region Private fields

        private const string DebugLoggingFormat = "[{0}] - (1)[{2}]";
        private readonly string DynamicLoggingNotice = "<-- DYNAMIC LOGGING --> ";
        private readonly ILog _log;
        private string m_strConfigFile = "";
        private FileSystemWatcher m_fswConfigFile = null;
        private bool m_bMonitoring = false;
        private FileInfo m_fiConfigFile = null;
        private log4net.Core.Level m_lvlLogLevel;
        private int m_intLogLevel = 0;
        private XmlDocument m_xlConfig = null;
        /// <summary>
        /// Theshold in SECONDS for Auto Logging long running SQL Commands.
        /// </summary>
        private double m_dAutoLogSQLThreshold = 10.0;

        #region DefinedSettingsValues
        // When changing these values, make sure to update ApplicationSettings.SettingsLookup Get Property with new or updated value pairs.
        //Logging Level Settings
        public const string Log_FunctionHeaderMethod_v1 = "FunctionHeaderMethod";
        public const string Log_FunctionHeaderConstructor_v1 = "FunctionHeaderConstructor";
        public const string Log_ComplexParameterValues_v1 = "ComplexParameterValues";
        public const string Log_SqlCommand_v1 = "SqlCommand";
        public const string Log_SqlParameters_v1 = "SqlParameters";
        public const string Log_SqlCommandResults_v1 = "SqlCommandResults";
        public const string Log_MemberTypeInformation_v1 = "MemberTypeInformation";
        public const string Log_DynamicLoggingNotice_v1 = "DynamicLoggingNotice";
        public const string Log_DumpComplexParameterValues_v1 = "DumpComplexParameterValues";
        public const string Log_DebugDumpSQL_v1 = "DebugDumpSQL";

        public const string Log_FunctionHeaderMethod_Lower_v1 = "functionheadermethod";
        public const string Log_FunctionHeaderConstructor_Lower_v1 = "functionheaderconstructor";
        public const string Log_ComplexParameterValues_Lower_v1 = "complexparametervalues";
        public const string Log_SqlCommand_Lower_v1 = "sqlcommand";
        public const string Log_SqlParameters_Lower_v1 = "sqlparameters";
        public const string Log_SqlCommandResults_Lower_v1 = "sqlcommandresults";
        public const string Log_MemberTypeInformation_Lower_v1 = "membertypeinformation";
        public const string Log_DynamicLoggingNotice_Lower_v1 = "dynamicloggingnotice";
        public const string Log_DumpComplexParameterValues_Lower_v1 = "dumpcomplexparametervalues";
        public const string Log_DebugDumpSQL_Lower_v1 = "debugdumpsql";

        public const string Log_FunctionHeaderMethod = "AutoLog:FunctionHeaderMethod";
        public const string Log_FunctionHeaderConstructor = "AutoLog:FunctionHeaderConstructor";
        public const string Log_ComplexParameterValues = "AutoLog:ComplexParameterValues";
        public const string Log_SqlCommand = "AutoLog:SqlCommand";
        public const string Log_SqlParameters = "AutoLog:SqlParameters";
        public const string Log_SqlCommandResults = "AutoLog:SqlCommandResults";
        public const string Log_MemberTypeInformation = "AutoLog:MemberTypeInformation";
        public const string Log_DynamicLoggingNotice = "AutoLog:DynamicLoggingNotice";
        public const string Log_DumpComplexParameterValues = "AutoLog:DumpComplexParameterValues";
        public const string Log_DebugDumpSQL = "AutoLog:DebugDumpSQL";

        public const string Log_FunctionHeaderMethod_Lower = "autolog:functionheadermethod";
        public const string Log_FunctionHeaderConstructor_Lower = "autolog:functionheaderconstructor";
        public const string Log_ComplexParameterValues_Lower = "autolog:complexparametervalues";
        public const string Log_SqlCommand_Lower = "autolog:sqlcommand";
        public const string Log_SqlParameters_Lower = "autolog:sqlparameters";
        public const string Log_SqlCommandResults_Lower = "autolog:sqlcommandresults";
        public const string Log_MemberTypeInformation_Lower = "autolog:membertypeinformation";
        public const string Log_DynamicLoggingNotice_Lower = "autolog:dynamicloggingnotice";
        public const string Log_DumpComplexParameterValues_Lower = "autolog:dumpcomplexparametervalues";
        public const string Log_DebugDumpSQL_Lower = "autolog:debugdumpsql";

        // Settings
        public const string Log4net_LogFile_v1 = "LogFile";
        public const string Log4net_LoggingThreshold_v1 = "LoggingThreshold";
        public const string Log4net_AutoLogSQLThreshold_v1 = "AutoLogSQLThreshold";
        public const string Log4net_MaxFunctionTimeThreshold_v1 = "MaxFunctionTimeThreshold";
        public const string Log4net_DebugLevels_v1 = "DebugLevels";
        public const string Log4net_IgnoreFunctions_v1 = "IgnoreFunctions";
        public const string Log4net_LogLevel_v1 = "LogLevel";
        public const string Log4net_AllowLoging_v1 = "AllowLoging";
        public const string Log4net_EnableDebugCode_v1 = "EnableDebugCode";
        public const string Log4net_IISSoapLogging_v1 = "IISSoapLogging";
        public const string Log4net_MaxAutoRetriesSql_v1 = "MaxAutoRetriesSql";
        public const string Log4net_AutoRetrySleepMsSql_v1 = "AutoRetrySleepMsSql";
        public const string Log4net_AutoTimeoutIncrementSecondsSql_v1 = "AutoTimeoutIncrementSecondsSql";
        public const string Log4net_MaxAutoRetriesHttp_v1 = "MaxAutoRetriesHttp";
        public const string Log4net_AutoRetrySleepMsHttp_v1 = "AutoRetrySleepMsHttp";
        public const string Log4net_AutoTimeoutIncrementMsHttp_v1 = "AutoTimeoutIncrementMsHttp";

        public const string Log4net_LogFile_Lower_v1 = "logfile";
        public const string Log4net_LoggingThreshold_Lower_v1 = "loggingthreshold";
        public const string Log4net_AutoLogSQLThreshold_Lower_v1 = "autologsqlthreshold";
        public const string Log4net_MaxFunctionTimeThreshold_Lower_v1 = "maxfunctiontimethreshold";
        public const string Log4net_DebugLevels_Lower_v1 = "debuglevels";
        public const string Log4net_IgnoreFunctions_Lower_v1 = "ignorefunctions";
        public const string Log4net_LogLevel_Lower_v1 = "loglevel";
        public const string Log4net_AllowLoging_Lower_v1 = "allowloging";
        public const string Log4net_EnableDebugCode_Lower_v1 = "enabledebugcode";
        public const string Log4net_IISSoapLogging_Lower_v1 = "iissoaplogging";
        public const string Log4net_MaxAutoRetriesSql_Lower_v1 = "maxautoretriessql";
        public const string Log4net_AutoRetrySleepMsSql_Lower_v1 = "autoretrysleepmssql";
        public const string Log4net_AutoTimeoutIncrementSecondsSql_Lower_v1 = "autotimeoutincrementsecondssql";
        public const string Log4net_MaxAutoRetriesHttp_Lower_v1 = "maxautoretrieshttp";
        public const string Log4net_AutoRetrySleepMsHttp_Lower_v1 = "autoretrysleepmshttp";
        public const string Log4net_AutoTimeoutIncrementMsHttp_Lower_v1 = "autotimeoutincrementmshttp";

        public const string Log4net_LogFile = "AutoLog:LogFile";
        public const string Log4net_LoggingThreshold = "AutoLog:LoggingThreshold";
        public const string Log4net_AutoLogSQLThreshold = "AutoLog:AutoLogSQLThreshold";
        public const string Log4net_MaxFunctionTimeThreshold = "AutoLog:MaxFunctionTimeThreshold";
        public const string Log4net_DebugLevels = "AutoLog:DebugLevels";
        public const string Log4net_IgnoreFunctions = "AutoLog:IgnoreFunctions";
        public const string Log4net_LogLevel = "AutoLog:LogLevel";
        public const string Log4net_AllowLoging = "AutoLog:AllowLoging";
        public const string Log4net_EnableDebugCode = "AutoLog:EnableDebugCode";
        public const string Log4net_IISSoapLogging = "AutoLog:IISSoapLogging";
        public const string Log4net_MaxAutoRetriesSql = "AutoLog:MaxAutoRetriesSql";
        public const string Log4net_AutoRetrySleepMsSql = "AutoLog:AutoRetrySleepMsSql";
        public const string Log4net_AutoTimeoutIncrementSecondsSql = "AutoLog:AutoTimeoutIncrementSecondsSql";
        public const string Log4net_MaxAutoRetriesHttp = "AutoLog:MaxAutoRetriesHttp";
        public const string Log4net_AutoRetrySleepMsHttp = "AutoLog:AutoRetrySleepMsHttp";
        public const string Log4net_AutoTimeoutIncrementMsHttp = "AutoLog:AutoTimeoutIncrementMsHttp";

        public const string Log4net_LogFile_Lower = "autolog:logfile";
        public const string Log4net_LoggingThreshold_Lower = "autolog:loggingthreshold";
        public const string Log4net_AutoLogSQLThreshold_Lower = "autolog:autologsqlthreshold";
        public const string Log4net_MaxFunctionTimeThreshold_Lower = "autolog:maxfunctiontimethreshold";
        public const string Log4net_DebugLevels_Lower = "autolog:debuglevels";
        public const string Log4net_IgnoreFunctions_Lower = "autolog:ignorefunctions";
        public const string Log4net_LogLevel_Lower = "autolog:loglevel";
        public const string Log4net_AllowLoging_Lower = "autolog:allowloging";
        public const string Log4net_EnableDebugCode_Lower = "autolog:enabledebugcode";
        public const string Log4net_IISSoapLogging_Lower = "autolog:iissoaplogging";
        public const string Log4net_MaxAutoRetriesSql_Lower = "autolog:maxautoretriessql";
        public const string Log4net_AutoRetrySleepMsSql_Lower = "autolog:autoretrysleepmssql";
        public const string Log4net_AutoTimeoutIncrementSecondsSql_Lower = "autolog:autotimeoutincrementsecondssql";
        public const string Log4net_MaxAutoRetriesHttp_Lower = "autolog:maxautoretrieshttp";
        public const string Log4net_AutoRetrySleepMsHttp_Lower = "autolog:autoretrysleepmshttp";
        public const string Log4net_AutoTimeoutIncrementMsHttp_Lower = "autolog:autotimeoutincrementmshttp";
        #endregion // DefinedSettingsValues

        public event EventHandler<CLogClassTypes.ConfigFileChangedEventArgs> ConfigFileChanged;
        public event EventHandler<CLogClassTypes.ConfigSettingChangedEventArgs> ConfigSettingChanged;
        #endregion

#pragma warning disable CS8601 // Possible null reference assignment.
        public CLog(string name)
        {
            _log = LogManager.GetLogger(name);
            if (_log is log4net.Core.LogImpl)
                LoggingUtils.Logger = _log as ICLog;
            else
                LoggingUtils.Logger = (ICLog)_log;
            if (LoggingUtils.Logger == null)
            {
                if (_log is log4net.Core.LogImpl)
                    LoggingUtils.Logger = _log as CLog;
                else
                    LoggingUtils.Logger = (CLog)_log;
            }
            DynamicLoggingNotice = LoggingUtils.Logger?.MonitoredSettings.GetOrAdd(CLog.Log_DynamicLoggingNotice, "<-- DYNAMIC LOGGING --> ");
        }
        public CLog(Type type)
        {
            _log = LogManager.GetLogger(type);
            if (_log is log4net.Core.LogImpl)
                LoggingUtils.Logger = _log as ICLog;
            else
                LoggingUtils.Logger = (ICLog)_log;
            if (LoggingUtils.Logger == null)
            {
                if (_log is log4net.Core.LogImpl)
                    LoggingUtils.Logger = _log as CLog;
                else
                    LoggingUtils.Logger = (CLog)_log;
            }
            DynamicLoggingNotice = LoggingUtils.Logger?.MonitoredSettings.GetOrAdd(CLog.Log_DynamicLoggingNotice, "<-- DYNAMIC LOGGING --> ");
#pragma warning restore CS8601 // Possible null reference assignment.
        }

        #region Implementation of ILoggerWrapper
        /*
        ILogger ILoggerWrapper.Logger
        {
            get { return _log?.Logger; }
        }
        */

        /// <summary>
        /// Theshold in SECONDS for Auto Logging long running SQL Commands.
        /// </summary>
        public double AutoLogSQLThreshold
        {
            get
            {
                return m_dAutoLogSQLThreshold;
            }
            set
            {
                m_dAutoLogSQLThreshold = value;
            }
        }

        public bool Monitoring
        {
            get
            {
                return m_fswConfigFile == null ? false : m_fswConfigFile.EnableRaisingEvents;
            }
            set
            {
                m_bMonitoring = value;
                ToggleConfigMonitoring(value);
            }
        }
        public int LogLevel
        {
            get { return m_intLogLevel; }
            set { m_intLogLevel = value; }
        }
        private string m_strLogFile = "";
        public string LogFile
        {
            get
            {
                return m_strLogFile;
                //return (string)log4net.GlobalContext.Properties["LogFile"];
            }
            set
            {
                //setting log4net global context property
                //if (string.IsNullOrEmpty((string)log4net.GlobalContext.Properties["LogFile"]))
                //{
                //    SetLogFile(value);
                //}
                //else
                //{
                //    if (!ReplaceLogFile((string)log4net.GlobalContext.Properties["LogFile"], value))
                //        SetLogFile(value);
                //}
                //log4net.GlobalContext.Properties["LogFile"] = value;
                if (string.IsNullOrEmpty(m_strLogFile))
                {
                    SetLogFile(value);
                }
                else
                {
                    if (!ReplaceLogFile(m_strLogFile, value))
                        SetLogFile(value);
                }
                m_strLogFile = value;
            }
        }

        public string ConfigFile
        {
            get { return m_strConfigFile; }
            set
            {
                m_strConfigFile = value;
                ToggleConfigMonitoring(m_bMonitoring);
                if (!Monitoring)
                    ReadConfigSettings();
            }
        }
        public log4net.Core.Level Level
        {
            get
            {
                if (m_lvlLogLevel == null)
                    m_lvlLogLevel = log4net.Core.Level.Info;
                return m_lvlLogLevel;
            }
            set
            {
                m_lvlLogLevel = value;
                ToggleLogging(m_lvlLogLevel);
            }
        }

        public string ConfigFileContents
        {
            get
            {
#if __IOS__
                XmlDocument xDoc = new XmlDocument();
                if (m_xlConfig == null)
                    return "";
                xDoc.LoadXml(m_xlConfig.OuterXml);
                return xDoc.ToString();
#else
                return XDocument.Parse(m_xlConfig.OuterXml).ToString();
#endif
            }
        }
        public XmlDocument ConfigFileXml
        {
            get
            {
#pragma warning disable CS8603 // Possible null reference return.
                return m_xlConfig;
#pragma warning restore CS8603 // Possible null reference return.
            }
        }
        public XmlDocument ConfigFileXmlDocument
        {
            get
            {
#pragma warning disable CS8603 // Possible null reference return.
                return m_xlConfig;
#pragma warning restore CS8603 // Possible null reference return.
            }
        }

        private void Watcher_Changed(object sender, FileSystemEventArgs e)
        {
            FileInfo fi = new FileInfo(e.FullPath);
            if (m_fiConfigFile == null || fi.LastWriteTime != m_fiConfigFile.LastWriteTime)
            {
                if (ToLog(2))
                    _log?.DebugFormat("Watcher_Changed: {0}", e.FullPath);
                ReadConfigSettings();
                if (ConfigFileChanged != null)
                {
                    CLogClassTypes.ConfigFileChangedEventArgs cfce = new CLogClassTypes.ConfigFileChangedEventArgs(e.FullPath, e.ChangeType);
                    ConfigFileChanged(this, cfce);
                }
                m_fiConfigFile = fi;
            }
        }
        private void ReadConfigSettings()
        {
            if (ToLog(2))
                _log?.DebugFormat("ReadConfigSettings: {0}", ConfigFile);
            m_xlConfig = new XmlDocument();
            XmlNodeList xlAppSettings;
            bool bLoaded = false;
            int iCount = 0;
            while (!bLoaded && iCount < 5)
            {
                try
                {
                    m_xlConfig.Load(ConfigFile);
                    bLoaded = true;
                }
                catch (Exception ex)
                {
                    iCount++;
                    if (iCount >= 5)
                        _log?.ErrorFormat("Error Loading Config File {0}", ex.ToString());
                    else
                        System.Threading.Thread.Sleep(500);
                }
            }
            try
            {
                // reading LogFile key value to set LogPath.LogFile  and LogPath.LoggingThreshold properties
                xlAppSettings = m_xlConfig.SelectNodes("/configuration/appSettings/add");
                foreach (XmlNode xlSetting in xlAppSettings)
                {
                    bool bExisting = MonitoredSettings.ContainsKey(xlSetting.Attributes["key"].Value);
                    bool bIsPassword = false;

                    //XmlAttribute attrKey = xlSetting.Attributes["key"];
                    //XmlAttribute attrValue = xlSetting.Attributes["value"];

                    if (xlSetting.Attributes["key"] != null && xlSetting.Attributes["value"] != null)
                    {
                        //Data.AddOrUpdate(attrKey.Value, attrValue.Value.Trim(), (key, oldValue) => attrValue.Value.Trim());
                        //MonitoredSettings.AddOrUpdate(attrKey.Value, attrValue.Value, (key, oldValue) => attrValue.Value);
                        if (IsUnEvaluated(xlSetting.Attributes["key"].Value, xlSetting.Attributes["value"].Value))
                        {
                            Error(string.Format("Template Value Found!  Item: [{0}] - Value: [{1}].", xlSetting.Attributes["key"].Value, xlSetting.Attributes["value"].Value));
                        }
                        else
                        {
                            string strXmlData = "";

                            if (IsConnectionString(xlSetting.Attributes["key"].Value, xlSetting.Attributes["value"].Value))
                            {
#if !__IOS__
                                SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder(xlSetting.Attributes["value"].Value)
                                {
                                    Password = "**************"
                                };
                                strXmlData = strXmlData.Replace(xlSetting.Attributes["value"].Value, scsb.ToString());
                                bIsPassword = true;
#endif
                            }
                            if (xlSetting.Attributes["key"].Value.ToLower() == "PassWord".ToLower())
                            {
                                strXmlData = strXmlData.Replace(xlSetting.Attributes["value"].OuterXml, xlSetting.Attributes["value"].OuterXml.Replace(xlSetting.Attributes["value"].InnerText, "********"));
                                bIsPassword = true;
                            }
                            if (xlSetting.Attributes["key"].Value.ToLower() == "RptServerDBPassWord".ToLower())
                            {
                                strXmlData = strXmlData.Replace(xlSetting.Attributes["value"].OuterXml, xlSetting.Attributes["value"].OuterXml.Replace(xlSetting.Attributes["value"].InnerText, "********"));
                                bIsPassword = true;
                            }
                        }
                    }

                    switch (xlSetting.Attributes["key"].Value.ToLower())
                    {
                        case Log4net_LogFile_Lower_v1:
                        case Log4net_LogFile_Lower:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_LogFile_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_LogFile_v1, ApplicationSettings.SettingsLookup[Log4net_LogFile_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (LogFile != xlSetting.Attributes["value"].Value)
                                {
                                    string LogFilePrevious = LogFile;
                                    LogFile = xlSetting.Attributes["value"].Value;
                                    MonitoredSettings.AddOrUpdate(Log4net_LogFile, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                    if (ConfigSettingChanged != null)
                                    {
                                        CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_LogFile, LogFilePrevious, xlSetting.Attributes["value"].Value, bExisting, bIsPassword);
                                        ConfigSettingChanged(this, csc);
                                    }
                                }
                            }
                            break;
                        case Log4net_LoggingThreshold_Lower_v1:
                        case Log4net_LoggingThreshold_Lower:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_LoggingThreshold_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_LoggingThreshold_v1, ApplicationSettings.SettingsLookup[Log4net_LoggingThreshold_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (Level != log4net.LogManager.GetRepository().LevelMap[xlSetting.Attributes["value"].Value.ToUpper()])
                                {
                                    log4net.Core.Level LevelPrevious = Level;
                                    Level = log4net.LogManager.GetRepository().LevelMap[xlSetting.Attributes["value"].Value.ToUpper()];
                                    MonitoredSettings.AddOrUpdate(Log4net_LoggingThreshold, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                    if (ConfigSettingChanged != null)
                                    {
                                        CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_LoggingThreshold, Level == null || LevelPrevious == null ? "Nothing" : LevelPrevious.DisplayName, xlSetting.Attributes["value"].Value, bExisting, bIsPassword);
                                        ConfigSettingChanged(this, csc);
                                    }
                                }
                            }
                            break;
                        case Log4net_AutoLogSQLThreshold_Lower_v1:
                        case Log4net_AutoLogSQLThreshold_Lower:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_AutoLogSQLThreshold_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_AutoLogSQLThreshold_v1, ApplicationSettings.SettingsLookup[Log4net_AutoLogSQLThreshold_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (double.TryParse(xlSetting.Attributes["value"].Value, out double dv))
                                {
                                    if (AutoLogSQLThreshold != dv)
                                    {
                                        double AutoLogSQLThresholdPrevious = AutoLogSQLThreshold;
                                        AutoLogSQLThreshold = dv;
                                        MonitoredSettings.AddOrUpdate(Log4net_AutoLogSQLThreshold, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_AutoLogSQLThreshold, AutoLogSQLThresholdPrevious.ToString(), dv.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                            }
                            break;
                        case Log4net_MaxFunctionTimeThreshold_Lower_v1:
                        case Log4net_MaxFunctionTimeThreshold_Lower:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_MaxFunctionTimeThreshold_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_MaxFunctionTimeThreshold_v1, ApplicationSettings.SettingsLookup[Log4net_MaxFunctionTimeThreshold_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (int.TryParse(xlSetting.Attributes["value"].Value, out int iVal))
                                {
                                    if (LoggingUtils.MaxFunctionTimeThreshold != iVal)
                                    {
                                        int MaxFunctionTimeThresholdPrevious = LoggingUtils.MaxFunctionTimeThreshold;
                                        LoggingUtils.MaxFunctionTimeThreshold = iVal;
                                        MonitoredSettings.AddOrUpdate(Log4net_MaxFunctionTimeThreshold, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_MaxFunctionTimeThreshold, MaxFunctionTimeThresholdPrevious.ToString(), iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                            }
                            break;
                        case Log4net_LogLevel_Lower_v1:
                        case Log4net_LogLevel_Lower:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_LogLevel_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_LogLevel_v1, ApplicationSettings.SettingsLookup[Log4net_LogLevel_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (int.TryParse(xlSetting.Attributes["value"].Value, out int iVal))
                                {
                                    if (LogLevel != iVal)
                                    {
                                        int LogLevelPrevious = LogLevel;
                                        LogLevel = iVal;
                                        MonitoredSettings.AddOrUpdate(Log4net_LogLevel, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_LogLevel, LogLevelPrevious.ToString(), iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                                else
                                    LogLevel = 0;
                            }
                            break;
                        case Log4net_AllowLoging_Lower_v1:
                        case Log4net_AllowLoging_Lower:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_AllowLoging_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_AllowLoging_v1, ApplicationSettings.SettingsLookup[Log4net_AllowLoging_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (int.TryParse(xlSetting.Attributes["value"].Value, out int iVal))
                                {
                                    if (AllowLogging != (iVal != 0))
                                    {
                                        bool AllowLoggingPrevious = AllowLogging;
                                        AllowLogging = (iVal != 0);
                                        MonitoredSettings.AddOrUpdate(Log4net_AllowLoging, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_AllowLoging, AllowLoggingPrevious.ToString(), iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                                else if (bool.TryParse(xlSetting.Attributes["value"].Value, out bool bVal))
                                {
                                    if (AllowLogging != bVal)
                                    {
                                        bool AllowLoggingPrevious = AllowLogging;
                                        AllowLogging = bVal;
                                        MonitoredSettings.AddOrUpdate(Log4net_AllowLoging, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_AllowLoging, AllowLoggingPrevious.ToString(), iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                                else
                                    AllowLogging = true;
                            }
                            break;
                        case Log4net_IISSoapLogging_Lower_v1:
                        case Log4net_IISSoapLogging_Lower:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_IISSoapLogging_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_IISSoapLogging_Lower_v1, ApplicationSettings.SettingsLookup[Log4net_IISSoapLogging_Lower_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                string strCurrent = MonitoredSettings.GetOrAdd(Log4net_IISSoapLogging, xlSetting.Attributes["value"].Value);
                                if (strCurrent != xlSetting.Attributes["value"].Value)
                                {
                                    MonitoredSettings.AddOrUpdate(Log4net_IISSoapLogging, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                    if (ConfigSettingChanged != null)
                                    {
                                        CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_IISSoapLogging, strCurrent, xlSetting.Attributes["value"].Value, bExisting, bIsPassword);
                                        ConfigSettingChanged(this, csc);
                                    }
                                }
                            }
                            break;
                        case Log4net_DebugLevels_Lower_v1:
                        case Log4net_DebugLevels_Lower:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_DebugLevels_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_DebugLevels_v1, ApplicationSettings.SettingsLookup[Log4net_DebugLevels_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                string[] arrItems = xlSetting.Attributes["value"].Value.Split(';');
                                MonitoredSettings.AddOrUpdate(Log4net_DebugLevels, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                if (ConfigSettingChanged != null)
                                {
                                    string strCurrent = "";
                                    foreach (string strItem in DebugLevels.Keys)
                                    {
                                        if (strItem != "*")
                                        {
                                            if (strCurrent.Length > 0)
                                                strCurrent += ";";
                                            strCurrent += strItem + ":" + DebugLevels[strItem].ToString();
                                        }
                                    }
                                    if (strCurrent != xlSetting.Attributes["value"].Value)
                                    {
                                        CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_DebugLevels, strCurrent, xlSetting.Attributes["value"].Value, bExisting, bIsPassword);
                                        ConfigSettingChanged(this, csc);
                                    }
                                }
                                DebugLevels.Clear();
                                foreach (string strItem in arrItems)
                                {
                                    string[] arrData = strItem.Split(':');
                                    if (int.TryParse(arrData[1], out int i))
                                    {
                                        DebugLevels.Add(arrData[0], i);
                                    }
                                }
                            }
                            break;
                        case Log4net_EnableDebugCode_Lower_v1:
                        case Log4net_EnableDebugCode_Lower:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_EnableDebugCode_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_EnableDebugCode_v1, ApplicationSettings.SettingsLookup[Log4net_EnableDebugCode_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (int.TryParse(xlSetting.Attributes["value"].Value, out int iVal))
                                {
                                    if (AllowLogging != (iVal != 0))
                                    {
                                        string strCurrent = MonitoredSettings.GetOrAdd(Log4net_EnableDebugCode, iVal.ToString());
                                        MonitoredSettings.AddOrUpdate(Log4net_EnableDebugCode, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_EnableDebugCode, strCurrent, iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                                else if (bool.TryParse(xlSetting.Attributes["value"].Value, out bool bVal))
                                {
                                    if (AllowLogging != bVal)
                                    {
                                        string strCurrent = MonitoredSettings.GetOrAdd(Log4net_EnableDebugCode, bVal.ToString());
                                        MonitoredSettings.AddOrUpdate(Log4net_EnableDebugCode, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_EnableDebugCode, strCurrent, iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                            }
                            break;
                        case Log_DebugDumpSQL_Lower_v1:
                        case Log_DebugDumpSQL_Lower:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log_DebugDumpSQL_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log_DebugDumpSQL_v1, ApplicationSettings.SettingsLookup[Log_DebugDumpSQL_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (int.TryParse(xlSetting.Attributes["value"].Value, out int iVal))
                                {
                                    if (AllowLogging != (iVal != 0))
                                    {
                                        string strCurrent = MonitoredSettings.GetOrAdd(Log_DebugDumpSQL, iVal.ToString());
                                        MonitoredSettings.AddOrUpdate(Log_DebugDumpSQL, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log_DebugDumpSQL, strCurrent, iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                                else if (bool.TryParse(xlSetting.Attributes["value"].Value, out bool bVal))
                                {
                                    if (AllowLogging != bVal)
                                    {
                                        string strCurrent = MonitoredSettings.GetOrAdd(Log_DebugDumpSQL, bVal.ToString());
                                        MonitoredSettings.AddOrUpdate(Log_DebugDumpSQL, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log_DebugDumpSQL, strCurrent, iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                            }
                            break;
                        case Log4net_IgnoreFunctions_Lower_v1:
                        case Log4net_IgnoreFunctions_Lower:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_IgnoreFunctions_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_IgnoreFunctions_v1, ApplicationSettings.SettingsLookup[Log4net_IgnoreFunctions_v1]);
                            //if (IgnoreLogging.GetOrAdd(Name, false))
                            //    return;

                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                string[] arrItems = xlSetting.Attributes["value"].Value.Split(';');
                                MonitoredSettings.AddOrUpdate(Log4net_IgnoreFunctions, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                string strCurrent = "";
                                string strNew = "";
                                if (ConfigSettingChanged != null)
                                {
                                    foreach (string strItem in IgnoreLogging.Keys)
                                    {
                                        if (strCurrent.Length > 0)
                                            strCurrent += ";";
                                        strCurrent += strItem + ":" + IgnoreLogging[strItem].ToString();
                                    }
                                }
                                foreach (string strItem in arrItems)
                                {
                                    IgnoreLogging.AddOrUpdate(strItem, true, (key, oldValue) => true);
                                }
                                if (ConfigSettingChanged != null)
                                {
                                    foreach (string strItem in IgnoreLogging.Keys)
                                    {
                                        if (strNew.Length > 0)
                                            strNew += ";";
                                        strNew += strItem + ":" + IgnoreLogging[strItem].ToString();
                                    }
                                    if (strCurrent != strNew)
                                    {
                                        CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_IgnoreFunctions, strCurrent, strNew, bExisting, bIsPassword);
                                        ConfigSettingChanged(this, csc);
                                    }
                                }
                            }
                            break;
                        case Log_FunctionHeaderMethod_Lower:
                        case Log_FunctionHeaderConstructor_Lower:
                        case Log_ComplexParameterValues_Lower:
                        case Log_SqlCommand_Lower:
                        case Log_SqlParameters_Lower:
                        case Log_SqlCommandResults_Lower:
                        case Log_MemberTypeInformation_Lower:
                        case Log_DumpComplexParameterValues_Lower:
                        case Log_FunctionHeaderMethod_Lower_v1:
                        case Log_FunctionHeaderConstructor_Lower_v1:
                        case Log_ComplexParameterValues_Lower_v1:
                        case Log_SqlCommand_Lower_v1:
                        case Log_SqlParameters_Lower_v1:
                        case Log_SqlCommandResults_Lower_v1:
                        case Log_MemberTypeInformation_Lower_v1:
                        case Log_DumpComplexParameterValues_Lower_v1:
                            string strHeaderValue = xlSetting.Attributes["key"].Value;
                            switch (xlSetting.Attributes["key"].Value.ToLower())
                            {
                                case Log_FunctionHeaderMethod_Lower_v1:
                                case Log_FunctionHeaderMethod_Lower:
                                    if (xlSetting.Attributes["key"].Value.ToLower() == Log_FunctionHeaderMethod_Lower_v1)
                                        WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log_FunctionHeaderMethod_v1, ApplicationSettings.SettingsLookup[Log_FunctionHeaderMethod_v1]);
                                    strHeaderValue = Log_FunctionHeaderMethod;
                                    break;
                                case Log_FunctionHeaderConstructor_Lower_v1:
                                case Log_FunctionHeaderConstructor_Lower:
                                    if (xlSetting.Attributes["key"].Value.ToLower() == Log_FunctionHeaderConstructor_Lower_v1)
                                        WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log_FunctionHeaderConstructor_v1, ApplicationSettings.SettingsLookup[Log_FunctionHeaderConstructor_v1]);
                                    strHeaderValue = Log_FunctionHeaderConstructor;
                                    break;
                                case Log_ComplexParameterValues_Lower_v1:
                                case Log_ComplexParameterValues_Lower:
                                    if (xlSetting.Attributes["key"].Value.ToLower() == Log_ComplexParameterValues_Lower_v1)
                                        WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log_ComplexParameterValues_v1, ApplicationSettings.SettingsLookup[Log_ComplexParameterValues_v1]);
                                    strHeaderValue = Log_ComplexParameterValues;
                                    break;
                                case Log_SqlCommand_Lower_v1:
                                case Log_SqlCommand_Lower:
                                    if (xlSetting.Attributes["key"].Value.ToLower() == Log_SqlCommand_Lower_v1)
                                        WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log_SqlCommand_v1, ApplicationSettings.SettingsLookup[Log_SqlCommand_v1]);
                                    strHeaderValue = Log_SqlCommand;
                                    break;
                                case Log_SqlParameters_Lower_v1:
                                case Log_SqlParameters_Lower:
                                    if (xlSetting.Attributes["key"].Value.ToLower() == Log_SqlParameters_Lower_v1)
                                        WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log_SqlParameters_v1, ApplicationSettings.SettingsLookup[Log_SqlParameters_v1]);
                                    strHeaderValue = Log_SqlParameters;
                                    break;
                                case Log_SqlCommandResults_Lower_v1:
                                case Log_SqlCommandResults_Lower:
                                    if (xlSetting.Attributes["key"].Value.ToLower() == Log_SqlCommandResults_Lower_v1)
                                        WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log_SqlCommandResults_v1, ApplicationSettings.SettingsLookup[Log_SqlCommandResults_v1]);
                                    strHeaderValue = Log_SqlCommandResults;
                                    break;
                                case Log_MemberTypeInformation_Lower_v1:
                                case Log_MemberTypeInformation_Lower:
                                    if (xlSetting.Attributes["key"].Value.ToLower() == Log_MemberTypeInformation_Lower_v1)
                                        WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log_MemberTypeInformation_v1, ApplicationSettings.SettingsLookup[Log_MemberTypeInformation_v1]);
                                    strHeaderValue = Log_MemberTypeInformation;
                                    break;
                                case Log_DumpComplexParameterValues_Lower_v1:
                                case Log_DumpComplexParameterValues_Lower:
                                    if (xlSetting.Attributes["key"].Value.ToLower() == Log_DumpComplexParameterValues_Lower_v1)
                                        WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log_DumpComplexParameterValues_v1, ApplicationSettings.SettingsLookup[Log_DumpComplexParameterValues_v1]);
                                    strHeaderValue = Log_DumpComplexParameterValues;
                                    break;
                            }
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (int.TryParse(xlSetting.Attributes["value"].Value, out int iVal))
                                {
                                    if (LoggingUtils.DebugPrintLevel[strHeaderValue] != iVal)
                                    {
                                        int DebugPrintLevelPrevious = LoggingUtils.DebugPrintLevel[strHeaderValue];
                                        MonitoredSettings.AddOrUpdate(strHeaderValue, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        LoggingUtils.DebugPrintLevel.AddOrUpdate(strHeaderValue, iVal, (key, oldValue) => iVal);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(strHeaderValue, DebugPrintLevelPrevious.ToString(), iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                            }
                            break;
                        // SQL
                        case Log4net_MaxAutoRetriesSql_Lower:
                        case Log4net_MaxAutoRetriesSql_Lower_v1:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_MaxAutoRetriesSql_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_MaxAutoRetriesSql_v1, ApplicationSettings.SettingsLookup[Log4net_MaxAutoRetriesSql_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (int.TryParse(xlSetting.Attributes["value"].Value, out int iVal))
                                {
                                    if (ApplicationSettings.MaxAutoRetriesSql != iVal)
                                    {
                                        int PreviousSetting = ApplicationSettings.MaxAutoRetriesSql;
                                        ApplicationSettings.MaxAutoRetriesSql = iVal;
                                        MonitoredSettings.AddOrUpdate(Log4net_MaxAutoRetriesSql, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_MaxAutoRetriesSql, PreviousSetting.ToString(), iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                            }
                            break;
                        case Log4net_AutoRetrySleepMsSql_Lower:
                        case Log4net_AutoRetrySleepMsSql_Lower_v1:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_AutoRetrySleepMsSql_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_AutoRetrySleepMsSql_v1, ApplicationSettings.SettingsLookup[Log4net_AutoRetrySleepMsSql_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (int.TryParse(xlSetting.Attributes["value"].Value, out int iVal))
                                {
                                    if (ApplicationSettings.AutoRetrySleepMsSql != iVal)
                                    {
                                        int PreviousSetting = ApplicationSettings.AutoRetrySleepMsSql;
                                        ApplicationSettings.AutoRetrySleepMsSql = iVal;
                                        MonitoredSettings.AddOrUpdate(Log4net_AutoRetrySleepMsSql, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_AutoRetrySleepMsSql, PreviousSetting.ToString(), iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                            }
                            break;
                        case Log4net_AutoTimeoutIncrementSecondsSql_Lower:
                        case Log4net_AutoTimeoutIncrementSecondsSql_Lower_v1:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_AutoTimeoutIncrementSecondsSql_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_AutoTimeoutIncrementSecondsSql_v1, ApplicationSettings.SettingsLookup[Log4net_AutoTimeoutIncrementSecondsSql_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (int.TryParse(xlSetting.Attributes["value"].Value, out int iVal))
                                {
                                    if (ApplicationSettings.AutoTimeoutIncrementSecondsSql != iVal)
                                    {
                                        int PreviousSetting = ApplicationSettings.AutoTimeoutIncrementSecondsSql;
                                        ApplicationSettings.AutoTimeoutIncrementSecondsSql = iVal;
                                        MonitoredSettings.AddOrUpdate(Log4net_AutoTimeoutIncrementSecondsSql, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_AutoTimeoutIncrementSecondsSql, PreviousSetting.ToString(), iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                            }
                            break;
                        case Log4net_MaxAutoRetriesHttp_Lower:
                        case Log4net_MaxAutoRetriesHttp_Lower_v1:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_MaxAutoRetriesHttp_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_MaxAutoRetriesHttp_v1, ApplicationSettings.SettingsLookup[Log4net_MaxAutoRetriesHttp_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (int.TryParse(xlSetting.Attributes["value"].Value, out int iVal))
                                {
                                    if (ApplicationSettings.MaxAutoRetriesHttp != iVal)
                                    {
                                        int PreviousSetting = ApplicationSettings.MaxAutoRetriesHttp;
                                        ApplicationSettings.MaxAutoRetriesHttp = iVal;
                                        MonitoredSettings.AddOrUpdate(Log4net_MaxAutoRetriesHttp, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_MaxAutoRetriesHttp, PreviousSetting.ToString(), iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                            }
                            break;
                        case Log4net_AutoRetrySleepMsHttp_Lower:
                        case Log4net_AutoRetrySleepMsHttp_Lower_v1:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_AutoRetrySleepMsHttp_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_AutoRetrySleepMsHttp_v1, ApplicationSettings.SettingsLookup[Log4net_AutoRetrySleepMsHttp_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (int.TryParse(xlSetting.Attributes["value"].Value, out int iVal))
                                {
                                    if (ApplicationSettings.AutoRetrySleepMsHttp != iVal)
                                    {
                                        int PreviousSetting = ApplicationSettings.AutoRetrySleepMsHttp;
                                        ApplicationSettings.AutoRetrySleepMsHttp = iVal;
                                        MonitoredSettings.AddOrUpdate(Log4net_AutoRetrySleepMsHttp, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_AutoRetrySleepMsHttp, PreviousSetting.ToString(), iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                            }
                            break;
                        case Log4net_AutoTimeoutIncrementMsHttp_Lower:
                        case Log4net_AutoTimeoutIncrementMsHttp_Lower_v1:
                            if (xlSetting.Attributes["key"].Value.ToLower() == Log4net_AutoTimeoutIncrementMsHttp_Lower_v1)
                                WarnFormat("Old Setting Name Found! Update {0} to {1}.", Log4net_AutoTimeoutIncrementMsHttp_v1, ApplicationSettings.SettingsLookup[Log4net_AutoTimeoutIncrementMsHttp_v1]);
                            if (!string.IsNullOrEmpty(xlSetting.Attributes["value"].Value))
                            {
                                if (int.TryParse(xlSetting.Attributes["value"].Value, out int iVal))
                                {
                                    if (ApplicationSettings.AutoTimeoutIncrementMsHttp != iVal)
                                    {
                                        int PreviousSetting = ApplicationSettings.AutoTimeoutIncrementMsHttp;
                                        ApplicationSettings.AutoTimeoutIncrementMsHttp = iVal;
                                        MonitoredSettings.AddOrUpdate(Log4net_AutoTimeoutIncrementMsHttp, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(Log4net_AutoTimeoutIncrementMsHttp, PreviousSetting.ToString(), iVal.ToString(), bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                            }
                            break;
                        default:
                            if (MonitoredSettings.ContainsKey(xlSetting.Attributes["key"].Value))
                            {
                                if (!string.IsNullOrEmpty(MonitoredSettings[xlSetting.Attributes["key"].Value]))
                                {
                                    if (MonitoredSettings[xlSetting.Attributes["key"].Value] != xlSetting.Attributes["value"].Value)
                                    {
                                        string MonitoredSettingPrevious = MonitoredSettings[xlSetting.Attributes["key"].Value];
                                        MonitoredSettings.AddOrUpdate(xlSetting.Attributes["key"].Value, xlSetting.Attributes["value"].Value, (key, oldValue) => xlSetting.Attributes["value"].Value);
                                        if (ConfigSettingChanged != null)
                                        {
                                            CLogClassTypes.ConfigSettingChangedEventArgs csc = new CLogClassTypes.ConfigSettingChangedEventArgs(xlSetting.Attributes["key"].Value, MonitoredSettingPrevious, xlSetting.Attributes["value"].Value, bExisting, bIsPassword);
                                            ConfigSettingChanged(this, csc);
                                        }
                                    }
                                }
                            }
                            break;
                    }
                }
                ToggleLogging(m_lvlLogLevel);
                if (DebugLevels.ContainsKey("*"))
                    DebugLevels["*"] = LogLevel;
                else
                    DebugLevels.Add("*", LogLevel);
            }
            catch (Exception ex)
            {
                _log?.ErrorFormat("Error Loading Config File {0}", ex.ToString());
            }
        }

        #endregion
        /*
        public bool IsAllEnabled => (Level == log4net.Core.Level.All); // int.MinValue

        public bool IsDebugEnabled => _log.IsDebugEnabled || (Level == log4net.Core.Level.All);

        public bool IsInfoEnabled => _log.IsInfoEnabled || (Level == log4net.Core.Level.All);

        public bool IsWarnEnabled => _log.IsWarnEnabled || (Level == log4net.Core.Level.All);

        public bool IsErrorEnabled => _log.IsErrorEnabled || (Level == log4net.Core.Level.All);

        public bool IsFatalEnabled => _log.IsFatalEnabled || (Level == log4net.Core.Level.All);
        */
        public bool IsAllEnabled => (Level == log4net.Core.Level.All); // int.MinValue

        public bool IsDebugEnabled => Level <= log4net.Core.Level.Debug || (Level == log4net.Core.Level.All); // 3000

        public bool IsInfoEnabled => Level <= log4net.Core.Level.Info || (Level == log4net.Core.Level.All); // 4000

        public bool IsWarnEnabled => Level <= log4net.Core.Level.Warn || (Level == log4net.Core.Level.All); // 6000

        public bool IsErrorEnabled => Level <= log4net.Core.Level.Error || (Level == log4net.Core.Level.All); // 7000

        public bool IsFatalEnabled => Level <= log4net.Core.Level.Fatal || (Level == log4net.Core.Level.All); // 11000

#pragma warning disable CS8603 // Possible null reference return.
        public log4net.Core.ILogger Logger => _log?.Logger;
#pragma warning restore CS8603 // Possible null reference return.
        #region Implementation of ILog

        #region Implementation of Debug
        public void Debug(object message)
        {
#if DEBUG
            var rootAppender = ((Hierarchy)LogManager.GetRepository()).Root.Appenders.OfType<FileAppender>().FirstOrDefault();
            string strLogFileName = rootAppender == null ? string.Empty : rootAppender.File;
            if (string.IsNullOrEmpty(strLogFileName))
            {
                System.Diagnostics.Debug.Assert(!string.IsNullOrEmpty(strLogFileName));
            }
#endif
#if __IOS__
            Log.Debug(string.Format("{0}", message));
#endif
            _log?.Debug(message);
        }
        public void Debug(object message, Exception exception)
        {
#if __IOS__
            if (exception == null)
                Log.Debug(string.Format("{0}", message));
            else
                Log.Debug(exception, string.Format("{0}", message));
#endif
            if (exception == null)
                _log?.Debug(message);
            else
                _log?.Debug(message, exception);
        }
        public void DebugPrefix(string logPrefix, object message, Exception exception)
        {
#if __IOS__
            if (exception == null)
                Log.Debug(logPrefix + string.Format("{0}", message));
            else
                Log.Debug(exception, logPrefix + string.Format("{0}", message));
#endif
            _log?.Debug(logPrefix + message, exception);
        }
        public void DebugPrefix(string logPrefix, string functionName, object message, Exception exception)
        {
#if __IOS__
            if (exception == null)
                Log.Debug(string.Format("{0}{1}: {2}", logPrefix, functionName, message));
            else
                Log.Debug(exception, string.Format("{0}{1}: {2}", logPrefix, functionName, message));
#endif
            _log?.Debug(string.Format("{0}{1}: {2}", logPrefix, functionName, message), exception);
        }
        public void DebugFormat(string format, params object[] args)
        {
#if __IOS__
            Log.Debug(string.Format(format, args));
#endif
            _log?.DebugFormat(format, args);
        }
        public void DebugFormat(string format, object arg0)
        {
#if __IOS__
            Log.Debug(format, arg0);
#endif
            _log?.DebugFormat(format, arg0);
        }

        public void DebugFormat(string format, object arg0, object arg1)
        {
#if __IOS__
            Log.Debug(format, arg0, arg1);
#endif
            _log?.DebugFormat(format, arg0, arg1);
        }

        public void DebugFormat(string format, object arg0, object arg1, object arg2)
        {
#if __IOS__
            Log.Debug(format, arg0, arg1, arg2);
#endif
            _log?.DebugFormat(format, arg0, arg1, arg2);
        }

        public void DebugFormat(IFormatProvider provider, string format, params object[] args)
        {
#if __IOS__
            Log.Debug(new SystemStringFormat(provider, format, args).ToString());
#endif
            _log?.DebugFormat(provider, format, args);
        }
        // --------------------------------------------------------------------------------------
        public bool Debug(Int32 level, object message)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
                    Log.Debug(string.Format("{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message));
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                    _log?.DebugFormat("{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message);
                }
                else
                {
                    if (ToLog(level))
                    {
#if __IOS__
                        Log.Debug(string.Format("{0}", message));
#endif
                        _log?.DebugFormat("{0}", message);
                    }
                    else
                    {
                        if (strDetectedFunction.Length == 0)
                            strDetectedFunction = FunctionFullName(GetParentFunction());
                        if (level >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                        {
#if __IOS__
                            Log.Debug(string.Format("{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message));
#endif
                            _log?.DebugFormat("{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message);
                        }
                        else
                        {
#if __IOS__
                            Log.Debug(string.Format("{0}", message));
#endif
                            _log?.DebugFormat("{0}", message);
                        }
                    }
                }
                return true;
            }
            return false;
        }
        public bool DebugPrefix(Int32 level, string logPrefix, object message)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(logPrefix + DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
                    Log.Debug(string.Format(logPrefix + "{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message));
#endif
                    _log?.DebugFormat(logPrefix + DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                    _log?.DebugFormat(logPrefix + "{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message);
                }
                else
                {
                    if (ToLog(level))
                    {
#if __IOS__
                        Log.Debug(string.Format(logPrefix + "{0}", message));
#endif
                        _log?.DebugFormat(logPrefix + "{0}", message);
                    }
                    else
                    {
                        if (strDetectedFunction.Length == 0)
                            strDetectedFunction = FunctionFullName(GetParentFunction());
                        if (level >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                        {
#if __IOS__
                            Log.Debug(string.Format(logPrefix + "{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message));
#endif
                            _log?.DebugFormat(logPrefix + "{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message);
                        }
                        else
                        {
#if __IOS__
                            Log.Debug(string.Format(logPrefix + "{0}", message));
#endif
                            _log?.DebugFormat(logPrefix + "{0}", message);
                        }
                    }
                }
                return true;
            }
            return false;
        }

        public bool Debug(Int32 level, object message, Exception exception)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
                    Log.Debug(exception, string.Format("{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message));
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                    _log?.Debug(string.Format("{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message), exception);
                }
                else
                {
                    if (ToLog(level))
                    {
#if __IOS__
                        Log.Debug(exception, string.Format("{0}", message));
#endif
                        _log?.Debug(string.Format("{0}", message), exception);
                    }
                    else
                    {
                        if (strDetectedFunction.Length == 0)
                            strDetectedFunction = FunctionFullName(GetParentFunction());
                        if (level >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                        {
#if __IOS__
                            Log.Debug(exception, string.Format("{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message));
#endif
                            _log?.Debug(string.Format("{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message), exception);
                        }
                        else
                        {
#if __IOS__
                            Log.Debug(exception, string.Format("{0}", message));
#endif
                            _log?.Debug(string.Format("{0}", message), exception);
                        }
                    }
                }
                return true;
            }
            return false;
        }
        public bool DebugPrefix(Int32 level, string logPrefix, object message, Exception exception)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(logPrefix + DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
                    Log.Debug(exception, string.Format(logPrefix + "{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message));
#endif
                    _log?.DebugFormat(logPrefix + DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                    _log?.Debug(string.Format("{0}{1}{2}: {3}", logPrefix, strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message), exception);
                }
                else
                {
                    if (ToLog(level))
                    {
#if __IOS__
                        Log.Debug(exception, string.Format(logPrefix + "{0}", message));
#endif
                        _log?.Debug(string.Format("{0}{1}", logPrefix, message), exception);
                    }
                    else
                    {
                        if (strDetectedFunction.Length == 0)
                            strDetectedFunction = FunctionFullName(GetParentFunction());
                        if (level >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                        {
#if __IOS__
                            Log.Debug(exception, string.Format(logPrefix + "{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message));
#endif
                            _log?.Debug(string.Format("{0}{1}{2}: {3}", logPrefix, strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message), exception);
                        }
                        else
                        {
#if __IOS__
                            Log.Debug(exception, string.Format(logPrefix + "{0}", message));
#endif
                            _log?.Debug(string.Format("{0}{1}", logPrefix, message), exception);
                        }
                    }
                }
                return true;
            }
            return false;
        }

        public bool DebugFormat(Int32 level, string format, params object[] args)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
                    Log.Debug(string.Format(string.Format("{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", format), args));
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                    _log?.DebugFormat(string.Format("{0}{1}: ", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, args);
                }
                else
                {
                    if (ToLog(level))
                    {
#if __IOS__
                        Log.Debug(string.Format(format, args));
#endif
                        _log?.DebugFormat(format, args);
                    }
                    else
                    {
                        if (strDetectedFunction.Length == 0)
                            strDetectedFunction = FunctionFullName(GetParentFunction());
                        if (level >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                        {
#if __IOS__
                            Log.Debug(string.Format(string.Format("{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", format), args));
#endif
                            _log?.DebugFormat(string.Format("{0}{1}: ", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, args);
                        }
                        else
                        {
#if __IOS__
                            Log.Debug(string.Format(format, args));
#endif
                            _log?.DebugFormat(format, args);
                        }
                    }
                }
                return true;
            }
            return false;
        }

        public bool DebugFormat(Int32 level, string format, object arg0)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
                    Log.Debug(string.Format(string.Format("{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", format), arg0));
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                    _log?.DebugFormat(string.Format("{0}{1}: ", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, arg0);
                }
                else
                {
                    if (ToLog(level))
                    {
                        _log?.DebugFormat(format, arg0);
                    }
                    else
                    {
                        if (strDetectedFunction.Length == 0)
                            strDetectedFunction = FunctionFullName(GetParentFunction());
                        if (level >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                        {
#if __IOS__
                            Log.Debug(string.Format(string.Format("{0}{1}: {2}", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", format), arg0));
#endif
                            _log?.DebugFormat(string.Format("{0}{1}: ", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, arg0);
                        }
                        else
                        {
#if __IOS__
                            Log.Debug(string.Format(format, arg0));
#endif
                            _log?.DebugFormat(format, arg0);
                        }
                    }
                }
                return true;
            }
            return false;
        }

        public bool DebugFormat(Int32 level, string format, object arg0, object arg1)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                }
#if __IOS__
                Log.Debug(string.Format(string.Format("{0}{1}: {2}", FunctionFullName(GetParentFunction()), strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", format), arg0, arg1));
#endif
                _log?.DebugFormat(string.Format("{0}{1}: ", FunctionFullName(GetParentFunction()), strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, arg0, arg1);
                return true;
            }
            return false;
        }

        public bool DebugFormat(Int32 level, string format, object arg0, object arg1, object arg2)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                }
#if __IOS__
                Log.Debug(string.Format(string.Format("{0}{1}: {2}", FunctionFullName(GetParentFunction()), strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", format), arg0, arg1, arg2));
#endif
                _log?.DebugFormat(string.Format("{0}{1}: ", FunctionFullName(GetParentFunction()), strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, arg0, arg1, arg2);
                return true;
            }
            return false;
        }

        public bool DebugFormat(Int32 level, IFormatProvider provider, string format, params object[] args)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
                    Log.Debug(string.Format("{0}{1}: ", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + new SystemStringFormat(provider, format, args));
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                    _log?.DebugFormat(provider, string.Format("{0}{1}: ", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, args);
                }
                else
                {
                    if (ToLog(level))
                    {
#if __IOS__
                        Log.Debug(new SystemStringFormat(provider, format, args).ToString());
#endif
                        _log?.DebugFormat(provider, format, args);
                    }
                    else
                    {
                        if (strDetectedFunction.Length == 0)
                            strDetectedFunction = FunctionFullName(GetParentFunction());
                        if (level >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                        {
#if __IOS__
                            Log.Debug(string.Format("{0}{1}: ", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + new SystemStringFormat(provider, format, args));
#endif
                            _log?.DebugFormat(provider, string.Format("{0}{1}: ", strDetectedFunction, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, args);
                        }
                        else
                        {
#if __IOS__
                            Log.Debug(new SystemStringFormat(provider, format, args).ToString());
#endif
                            _log?.DebugFormat(provider, format, args);
                        }
                    }
                }
                return true;
            }
            return false;
        }
        // --------------------------------------------------------------------------------------
        public bool Debug(Int32 level, string functionName, object message, Exception exception)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                //if (strDetectedCriteria.Length > 0)
                //    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                //_log?.Debug(string.Format("{0}{1}: {2}", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message), exception);
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
                    Log.Debug(exception, string.Format("{0}{1}: {2}", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message));
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                    _log?.Debug(string.Format("{0}{1}: {2}", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message), exception);
                }
                else
                {
                    if (ToLog(level))
                    {
#if __IOS__
                        Log.Debug(exception, string.Format("{0}: {1}", functionName, message));
#endif
                        _log?.Debug(string.Format("{0}: {1}", functionName, message), exception);
                    }
                    else
                    {
                        if (strDetectedFunction.Length == 0)
                            strDetectedFunction = FunctionFullName(GetParentFunction());
                        if (level >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                        {
#if __IOS__
                            Log.Debug(exception, string.Format("{0}{1}: {2}", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message));
#endif
                            _log?.Debug(string.Format("{0}{1}: {2}", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message), exception);
                        }
                        else
                        {
#if __IOS__
                            Log.Debug(exception, string.Format("{0}: {1}", functionName, message));
#endif
                            _log?.Debug(string.Format("{0}: {1}", functionName, message), exception);
                        }
                    }
                }
                return true;
            }
            return false;
        }
        public bool DebugPrefix(Int32 level, string logPrefix, string functionName, object message, Exception exception)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                //if (strDetectedCriteria.Length > 0)
                //    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                //_log?.Debug(string.Format("{0}{1}: {2}", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message), exception);
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
                    Log.Debug(exception, string.Format("{0}{1}{2}: {3}", logPrefix, functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message));
#endif
                    _log?.DebugFormat(logPrefix + DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                    _log?.Debug(string.Format("{0}{1}{2}: {3}", logPrefix, functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message), exception);
                }
                else
                {
                    if (ToLog(level))
                    {
#if __IOS__
                        Log.Debug(exception, string.Format("{0}{1}: {2}", logPrefix, functionName, message));
#endif
                        _log?.Debug(string.Format("{0}{1}: {2}", logPrefix, functionName, message), exception);
                    }
                    else
                    {
                        if (strDetectedFunction.Length == 0)
                            strDetectedFunction = FunctionFullName(GetParentFunction());
                        if (level >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                        {
#if __IOS__
                            Log.Debug(exception, string.Format("{0}{1}{2}: {3}", logPrefix, functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message));
#endif
                            _log?.Debug(string.Format("{0}{1}{2}: {3}", logPrefix, functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "", message), exception);
                        }
                        else
                        {
#if __IOS__
                            Log.Debug(exception, string.Format("{0}{1}: {2}", logPrefix, functionName, message));
#endif
                            _log?.Debug(string.Format("{0}{1}: {2}", logPrefix, functionName, message), exception);
                        }
                    }
                }
                return true;
            }
            return false;
        }

        public bool DebugFormat(Int32 level, string functionName, string format, params object[] args)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                //if (strDetectedCriteria.Length > 0)
                //    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                //_log?.DebugFormat(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, args);

                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
                    Log.Debug(string.Format(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format), args);
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                    _log?.DebugFormat(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, args);
                }
                else
                {
                    if (ToLog(level))
                    {
#if __IOS__
                        Log.Debug(string.Format(string.Format("{0}{1}: ", functionName, format), args));
#endif
                        _log?.DebugFormat(string.Format("{0}: ", functionName) + format, args);
                    }
                    else
                    {
                        if (strDetectedFunction.Length == 0)
                            strDetectedFunction = FunctionFullName(GetParentFunction());
                        if (level >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                        {
#if __IOS__
                            Log.Debug(string.Format(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format), args);
#endif
                            _log?.DebugFormat(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, args);
                        }
                        else
                        {
#if __IOS__
                            Log.Debug(string.Format(string.Format("{0}{1}: ", functionName, format), args));
#endif
                            _log?.DebugFormat(string.Format("{0}: ", functionName) + format, args);
                        }
                    }
                }
                return true;
            }
            return false;
        }

        public bool DebugFormat(Int32 level, string functionName, string format, object arg0)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                }
#if __IOS__
                Log.Debug(string.Format(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format), arg0);
#endif
                _log?.DebugFormat(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, arg0);
                return true;
            }
            return false;
        }

        public bool DebugFormatPrefix(Int32 level, string logPrefix, string functionName, string format, object arg0)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(logPrefix + string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
#endif
                    _log?.DebugFormat(logPrefix + DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                }
#if __IOS__
                Log.Debug(logPrefix + string.Format(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format), arg0);
#endif
                _log?.DebugFormat(logPrefix + string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, arg0);
                return true;
            }
            return false;
        }

        public bool DebugFormat(Int32 level, string functionName, string format, object arg0, object arg1)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                }
#if __IOS__
                Log.Debug(string.Format(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format), arg0, arg1);
#endif
                _log?.DebugFormat(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, arg0, arg1);
                return true;
            }
            return false;
        }
        public bool DebugFormatPrefix(Int32 level, string logPrefix, string functionName, string format, object arg0, object arg1)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(logPrefix + string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
#endif
                    _log?.DebugFormat(logPrefix + DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                }
#if __IOS__
                Log.Debug(logPrefix + string.Format(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format), arg0, arg1);
#endif
                _log?.DebugFormat(logPrefix + string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, arg0, arg1);
                return true;
            }
            return false;
        }

        public bool DebugFormat(Int32 level, string functionName, string format, object arg0, object arg1, object arg2)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                }
#if __IOS__
                Log.Debug(string.Format(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format), arg0, arg1, arg2);
#endif
                _log?.DebugFormat(string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, arg0, arg1, arg2);
                return true;
            }
            return false;
        }

        public bool DebugFormat(Int32 level, string functionName, IFormatProvider provider, string format, params object[] args)
        {
            if (ToLog(level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
            {
                if (strDetectedCriteria.Length > 0)
                {
#if __IOS__
                    Log.Debug(string.Format(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction));
#endif
                    _log?.DebugFormat(DebugLoggingFormat, strDetectedCriteria, DynamicLoggingNotice, strDetectedFunction);
                }
#if __IOS__
                Log.Debug(new SystemStringFormat(provider, string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, args).ToString());
#endif
                _log?.DebugFormat(provider, string.Format("{0}{1}: ", functionName, strDetectedCriteria.Length > 0 ? "(* Detailed Logging)" : "") + format, args);
                return true;
            }
            return false;
        }
        // --------------------------------------------------------------------------------------
        #endregion Implementation of Debug

        #region Implementation of Base Functions
        public void Error(object message)
        {
#if __IOS__
            Log.Error(string.Format("{0}", message));
#endif
            _log?.Error(message);
        }

        public void Error(object message, Exception exception)
        {
#if __IOS__
            if (exception == null)
                Log.Error(string.Format("{0}", message));
            else
                Log.Error(exception, string.Format("{0}", message));
#endif
            if (exception == null)
                _log?.Error(message);
            else
                _log?.Error(message, exception);
        }

        public void ErrorFormat(string format, params object[] args)
        {
#if __IOS__
            Log.Error(string.Format(format, args));
#endif
            _log?.ErrorFormat(format, args);
        }

        public void ErrorFormat(string format, object arg0)
        {
#if __IOS__
            Log.Error(string.Format(format, arg0));
#endif
            _log?.ErrorFormat(format, arg0);
        }

        public void ErrorFormat(string format, object arg0, object arg1)
        {
#if __IOS__
            Log.Error(string.Format(format, arg0, arg1));
#endif
            _log?.ErrorFormat(format, arg0, arg1);
        }

        public void ErrorFormat(string format, object arg0, object arg1, object arg2)
        {
#if __IOS__
            Log.Error(string.Format(format, arg0, arg1, arg2));
#endif
            _log?.ErrorFormat(format, arg0, arg1, arg2);
        }

        public void ErrorFormat(IFormatProvider provider, string format, params object[] args)
        {
#if __IOS__
            Log.Error(new SystemStringFormat(provider, format, args).ToString());
#endif
            _log?.ErrorFormat(provider, format, args);
        }

        public void Fatal(object message)
        {
#if __IOS__
            Log.Fatal(string.Format("{0}", message));
#endif
            _log?.Fatal(message);
        }

        public void Fatal(object message, Exception exception)
        {
#if __IOS__
            if (exception == null)
                Log.Fatal(string.Format("{0}", message));
            else
                Log.Fatal(exception, string.Format("{0}", message));
#endif
            if (exception == null)
                _log?.Fatal(message);
            else
                _log?.Fatal(message, exception);
        }

        public void FatalFormat(string format, params object[] args)
        {
#if __IOS__
            Log.Fatal(string.Format(format, args));
#endif
            _log?.FatalFormat(format, args);
        }

        public void FatalFormat(string format, object arg0)
        {
#if __IOS__
            Log.Fatal(string.Format(format, arg0));
#endif
            _log?.FatalFormat(format, arg0);
        }

        public void FatalFormat(string format, object arg0, object arg1)
        {
#if __IOS__
            Log.Fatal(string.Format(format, arg0, arg1));
#endif
            _log?.FatalFormat(format, arg0, arg1);
        }

        public void FatalFormat(string format, object arg0, object arg1, object arg2)
        {
#if __IOS__
            Log.Fatal(string.Format(format, arg0, arg1, arg2));
#endif
            _log?.FatalFormat(format, arg0, arg1, arg2);
        }

        public void FatalFormat(IFormatProvider provider, string format, params object[] args)
        {
#if __IOS__
            Log.Fatal(new SystemStringFormat(provider, format, args).ToString());
#endif
            _log?.FatalFormat(provider, format, args);
        }

        public void Info(object message)
        {
#if DEBUG
            var rootAppender = ((Hierarchy)LogManager.GetRepository()).Root.Appenders.OfType<FileAppender>().FirstOrDefault();
            string strLogFileName = rootAppender == null ? string.Empty : rootAppender.File;
            if (string.IsNullOrEmpty(strLogFileName))
            {
                System.Diagnostics.Debug.Assert(!string.IsNullOrEmpty(strLogFileName));
            }
#endif
#if __IOS__
            Log.Information(string.Format("{0}", message));
#endif
            _log?.Info(message);
        }

        public void Info(object message, Exception exception)
        {
#if __IOS__
            if (exception == null)
                Log.Information(string.Format("{0}", message));
            else
                Log.Information(exception, string.Format("{0}", message));
#endif
            if (exception == null)
                _log?.Info(message);
            else
                _log?.Info(message, exception);
        }

        public void InfoFormat(string format, params object[] args)
        {
#if __IOS__
            Log.Information(string.Format(format, args));
#endif
            _log?.InfoFormat(format, args);
        }

        public void InfoFormat(string format, object arg0)
        {
#if __IOS__
            Log.Information(string.Format(format, arg0));
#endif
            _log?.InfoFormat(format, arg0);
        }

        public void InfoFormat(string format, object arg0, object arg1)
        {
#if __IOS__
            Log.Information(string.Format(format, arg0, arg1));
#endif
            _log?.InfoFormat(format, arg0, arg1);
        }

        public void InfoFormat(string format, object arg0, object arg1, object arg2)
        {
#if __IOS__
            Log.Information(string.Format(format, arg0, arg1, arg2));
#endif
            _log?.InfoFormat(format, arg0, arg1, arg2);
        }

        public void InfoFormat(IFormatProvider provider, string format, params object[] args)
        {
#if __IOS__
            Log.Information(new SystemStringFormat(provider, format, args).ToString());
#endif
            _log?.InfoFormat(provider, format, args);
        }

        public void Warn(object message)
        {
#if __IOS__
            Log.Warning(string.Format("{0}", message));
#endif
            _log?.Warn(message);
        }

        public void Warn(object message, Exception exception)
        {
#if __IOS__
            if (exception == null)
                Log.Warning(string.Format("{0}", message));
            else
                Log.Warning(exception, string.Format("{0}", message));
#endif
            if (exception == null)
                _log?.Warn(message);
            else
                _log?.Warn(message, exception);
        }

        public void WarnFormat(string format, params object[] args)
        {
#if __IOS__
            Log.Warning(string.Format(format, args));
#endif
            _log?.WarnFormat(format, args);
        }

        public void WarnFormat(string format, object arg0)
        {
#if __IOS__
            Log.Warning(string.Format(format, arg0));
#endif
            _log?.WarnFormat(format, arg0);
        }

        public void WarnFormat(string format, object arg0, object arg1)
        {
#if __IOS__
            Log.Warning(string.Format(format, arg0, arg1));
#endif
            _log?.WarnFormat(format, arg0, arg1);
        }

        public void WarnFormat(string format, object arg0, object arg1, object arg2)
        {
#if __IOS__
            Log.Warning(string.Format(format, arg0, arg1, arg2));
#endif
            _log?.WarnFormat(format, arg0, arg1, arg2);
        }

        public void WarnFormat(IFormatProvider provider, string format, params object[] args)
        {
#if __IOS__
            Log.Warning(new SystemStringFormat(provider, format, args).ToString());
#endif
            _log?.WarnFormat(provider, format, args);
        }
        #endregion Implementation of Base Functions

        #endregion Implementation of ILog
        public static string FunctionFullName(MethodBase method)
        {
            return method.DeclaringType.FullName + "." + method.Name;
        }
        public static string FunctionFullPath(StackFrame[] arrFrames)
        {
            string strFullName = "";
#if __IOS__
            Array.Reverse(arrFrames);
            foreach (var vItem in arrFrames)
#else
            foreach (var vItem in arrFrames.Reverse())
#endif
            {
                try
                {
                    MethodBase m = vItem.GetMethod();
                    if (m != null)
                    {
                        bool bProcess = true;
#if ReflectionType
                        if (m.ReflectedType != null)
                        {
                            if (m.ReflectedType.FullName.StartsWith("System.") ||
                                m.ReflectedType.FullName.StartsWith("Microsoft.") ||
                                m.ReflectedType.FullName.StartsWith("ASP."))
                            {
                                bProcess = false;
                            }
                        }
#else
                        if (m.DeclaringType != null)
                        {
                            if (m.DeclaringType.FullName.StartsWith("System.") ||
                                m.DeclaringType.FullName.StartsWith("Microsoft.") ||
                                m.DeclaringType.FullName.StartsWith("ASP."))
                            {
                                bProcess = false;
                            }
                        }
#endif
                        if (bProcess)
                        {
                            string strFunctionName = m.Name;
                            if (m.IsConstructor && m.DeclaringType != null)
                                strFunctionName = m.DeclaringType.Name;
                            if (strFullName.Length > 0)
                                strFullName += ".";
                            else if (m.DeclaringType != null)
                                strFullName = m.DeclaringType.FullName + ".";
                            strFullName += strFunctionName;
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (ApplicationSettings.WriteDebug)
                        System.Diagnostics.Debug.WriteLine(ex.Message);
                }
            }
            return strFullName;
        }
        public static MethodBase GetParentFunction()
        {
            StackTrace st = new StackTrace();
            StackFrame frame = st.GetFrame(2);
            return frame.GetMethod();
        }
        public bool InCodePathOf(string strFucntion, out string strDetectedFunction)
        {
            System.Diagnostics.StackTrace t = new System.Diagnostics.StackTrace();
            StackFrame[] arrFrames = t.GetFrames();
            return InCodePathOf(strFucntion, arrFrames, out strDetectedFunction);
        }
        public bool InCodePathOf(string strFucntion, StackFrame[] arrFrames, out string strDetectedFunction)
        {
            strFucntion = strFucntion.ToLower();
            strDetectedFunction = FullPath(arrFrames);
            if (strFucntion.StartsWith("*") && strFucntion.EndsWith("*"))
            {
                if (strDetectedFunction.ToLower().Contains(strFucntion.Replace("*", "")))
                    return true;
            }
            else if (strFucntion.StartsWith("*"))
            {
                if (strDetectedFunction.ToLower().EndsWith(strFucntion.Replace("*", "")))
                    return true;
            }
            else if (strFucntion.EndsWith("*"))
            {
                if (strDetectedFunction.ToLower().StartsWith(strFucntion.Replace("*", "")))
                    return true;
            }
            else if (strFucntion.Contains("."))
            {
                if (strDetectedFunction.ToLower() == strFucntion)
                    return true;
            }
            else if (strDetectedFunction.ToLower().Contains(strFucntion))
                return true;
            strDetectedFunction = "";
            return false;
        }
        public string FullPath(StackFrame[] arrFrames)
        {
            string strFullName = "";
#if __IOS__
            Array.Reverse(arrFrames);
            foreach (var vItem in arrFrames)
#else
            foreach (var vItem in arrFrames.Reverse())
#endif
            {
                try
                {
                    MethodBase m = vItem.GetMethod();
                    if (m != null)
                    {
                        bool bProcess = true;
#if ReflectionType
                    if (m.ReflectedType != null)
                    {
                        if (!(m.ReflectedType.FullName.StartsWith("System.") ||
                                m.ReflectedType.FullName.StartsWith("Microsoft.") ||
                                m.ReflectedType.FullName.StartsWith("ASP.")))
                        {
                            bProcess = false;
                        }
                    }
#else
                        if (m.DeclaringType != null)
                        {
                            if (m.DeclaringType.FullName.StartsWith("System.") ||
                                m.DeclaringType.FullName.StartsWith("Microsoft.") ||
                                m.DeclaringType.FullName.StartsWith("ASP."))
                            {
                                bProcess = false;
                            }
                        }
#endif
                        if (bProcess)
                        {
                            string strFunctionName = m.Name;
                            if (m.IsConstructor && m.DeclaringType != null)
                                strFunctionName = m.DeclaringType.Name;
                            //if (!(strFullName.EndsWith("." + strFunctionName) || strFullName == strFunctionName))
                            {
                                if (strFullName.Length > 0)
                                    strFullName += ".";
                                else if (m.DeclaringType != null)
                                    strFullName = m.DeclaringType.FullName + ".";
                                strFullName += strFunctionName;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (ApplicationSettings.WriteDebug)
                        System.Diagnostics.Debug.WriteLine(ex.Message);
                }
            }
            return strFullName;
        }
        public bool LoggingDebug()
        {
            return IsDebugEnabled;
            //return (((log4net.Repository.Hierarchy.Hierarchy)log4net.LogManager.GetRepository()).Root.Level == log4net.Core.Level.All ||
            //        ((log4net.Repository.Hierarchy.Hierarchy)log4net.LogManager.GetRepository()).Root.Level == log4net.Core.Level.Debug);

        }
        /// <summary>
        /// Checks for Proper Log Level
        /// </summary>
        /// <param name="_level"></param>
        /// <returns></returns>
        public bool ToLog(int _level)
        {
            try
            {
                if (IsDebugEnabled)
                {
                    return (LogLevel >= _level);
                }
            }
            catch (Exception ex)
            {
                if (ApplicationSettings.WriteDebug)
                    System.Diagnostics.Debug.WriteLine("ToLog: Error: " + ex.ToString());
                Error("ToLog: Error: " + ex.ToString());
            }
            return false;
        }

        /// <summary>
        /// Checks for Proper Log Level or Function Log Level
        /// </summary>
        /// <param name="_level"></param>
        /// <param name="strDetectedCriteria"></param>
        /// <param name="strDetectedFunction"></param>
        /// <returns></returns>
        public bool ToLog(int _level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel)
        {
            strDetectedCriteria = "";
            strDetectedFunction = "";
            iDetectedLevel = 0;

            try
            {
                if (IsDebugEnabled)
                {
                    int iValue = 0;

                    if (DebugLevels.Count > 0)
                    {
                        System.Diagnostics.StackTrace t = new System.Diagnostics.StackTrace();
                        StackFrame[] arrFrames = t.GetFrames();
                        foreach (var vItem in DebugLevels)
                        {
                            if (vItem.Key == "*")
                                continue;
                            if (InCodePathOf(vItem.Key, arrFrames, out strDetectedFunction))
                            {
                                iDetectedLevel = vItem.Value;
                                iValue = vItem.Value;
                                strDetectedCriteria = vItem.Key + ":" + iValue.ToString();
                                break;
                            }
                        }
                        if (iValue == 0)
                        {
                            if (DebugLevels.ContainsKey("*"))
                                iValue = DebugLevels["*"];
                        }
                    }
                    if (iValue == 0)
                    {
                        return (LogLevel >= _level);
                    }
                    if (iValue < 0)
                    {
                        return false;
                    }
                    if (LogLevel >= iValue)
                    {
                        strDetectedCriteria = "";
                        strDetectedFunction = "";
                        return (LogLevel >= _level);
                    }
                    return (iValue >= _level);
                }
            }
            catch (Exception ex)
            {
                if (ApplicationSettings.WriteDebug)
                    System.Diagnostics.Debug.WriteLine("ToLog: Error: " + ex.ToString());
                Error("ToLog: Error: " + ex.ToString());
            }
            return false;
        }

        /// <summary>
        /// Toggle all appenders to this specified level 
        /// </summary>
        /// <param name="level"></param>
        public void ToggleLogging(log4net.Core.Level level)
        {
            log4net.Repository.ILoggerRepository repository = log4net.LogManager.GetRepository();
            foreach (log4net.Appender.IAppender appender in repository.GetAppenders())
            {
                try
                {
                    log4net.Appender.AppenderSkeleton vAppender = (log4net.Appender.AppenderSkeleton)appender;
                    vAppender.Threshold = level;
                }
                catch (Exception ex)
                {
                    ErrorFormat("Error Setting ThreshHold on {0}.  Error: {1}", appender.Name, ex.ToString());
                }
            }
            //Configure the root logger.
            log4net.Repository.Hierarchy.Hierarchy h = (log4net.Repository.Hierarchy.Hierarchy)log4net.LogManager.GetRepository();
            log4net.Repository.Hierarchy.Logger rootLogger = h.Root;
            rootLogger.Level = level;
        }

        /// <summary>
        /// Toggle all appenders to this specified level
        /// </summary>
        /// <param name="logLevel"></param>
        /// <returns></returns>
        public log4net.Core.Level ToggleLogging(string logLevel)
        {
            log4net.Core.Level level = null;

            if (!string.IsNullOrEmpty(logLevel))
            {
                level = log4net.LogManager.GetRepository().LevelMap[logLevel.ToUpper()];
            }
            if (level == null)
            {
                level = log4net.Core.Level.Info;
            }
            ToggleLogging(level);

            return level;
        }
        public log4net.Core.Level LoggingLevel()
        {
            log4net.Repository.Hierarchy.Hierarchy h = (log4net.Repository.Hierarchy.Hierarchy)log4net.LogManager.GetRepository();
            return h.Root.Level;
        }

        public void SetLogFile(string strFileName, string strAppenderName = "LogFileAppender")
        {
            FileInfo fiNew = new FileInfo(strFileName);
            if (!string.IsNullOrEmpty(strFileName))
            {
                if (strFileName.ToLower().EndsWith(".log"))
                    fiNew = new FileInfo(strFileName);
                else
                    fiNew = new FileInfo(strFileName + ".log");
            }

            log4net.Repository.ILoggerRepository repository = log4net.LogManager.GetRepository();
            foreach (log4net.Appender.IAppender appender in repository.GetAppenders())
            {
                try
                {
                    if (appender.Name.ToLower() == strAppenderName.ToLower())
                    {
                        if (appender is log4net.Appender.RollingFileAppender fa)
                        {
                            FileInfo fiOld = new FileInfo(fa.File);

                            if (string.IsNullOrEmpty(fa.DatePattern))
                            {
                                if (!fiOld.Name.Replace(fiOld.Extension, "").ToLower().StartsWith(fiNew.Name.Replace(fiNew.Extension, "").ToLower()))
                                {
                                    fa.File = strFileName;
                                    fa.ActivateOptions();
                                }
                            }
                            else
                            {
                                string strDatePattern = DateTime.Now.ToString(fa.DatePattern);
                                string strExpectedFileName = strFileName + strDatePattern;
                                fiNew = new FileInfo(strExpectedFileName);

                                if (fiOld.Name.ToLower() != fiNew.Name.ToLower())
                                {
                                    fa.File = strFileName;
                                    fa.ActivateOptions();
                                }
                            }
                        }
                        else if (appender is log4net.Appender.FileAppender fa2)
                        {
                            FileInfo fiOld = new FileInfo(fa2.File);

                            if (!fiOld.Name.Replace(fiOld.Extension, "").ToLower().StartsWith(fiNew.Name.Replace(fiNew.Extension, "").ToLower()))
                            {
                                fa2.File = strFileName;
                                fa2.ActivateOptions();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ErrorFormat("Error Setting File on {0}.  Error: {1}", appender.Name, ex.ToString());
                }
            }
        }
        public string GetLogFile(string strAppenderName = "LogFileAppender")
        {
            log4net.Repository.ILoggerRepository repository = log4net.LogManager.GetRepository();
            foreach (log4net.Appender.IAppender appender in repository.GetAppenders())
            {
                try
                {
                    if (appender.Name.ToLower() == strAppenderName.ToLower())
                    {
                        if (appender is log4net.Appender.RollingFileAppender fa)
                        {
                            return fa.File;
                        }
                        else if (appender is log4net.Appender.FileAppender fa2)
                        {
                            return fa2.File;
                        }
                    }
                    return "";
                }
                catch (Exception ex)
                {
                    ErrorFormat("Error Setting File on {0}.  Error: {1}", appender.Name, ex.ToString());
                }
            }
            return "";
        }

        public bool ReplaceLogFile(string strCurrentName, string strFileName)
        {
            bool bReplaced = false;
            FileInfo fiCurrent = null;
            if (!string.IsNullOrEmpty(strCurrentName))
            {
                if (strCurrentName.ToLower().EndsWith(".log"))
                    fiCurrent = new FileInfo(strCurrentName);
                else
                    fiCurrent = new FileInfo(strCurrentName + ".log");
            }
            FileInfo fiNew = new FileInfo(strFileName);

            log4net.Repository.ILoggerRepository repository = log4net.LogManager.GetRepository();
            foreach (log4net.Appender.IAppender appender in repository.GetAppenders())
            {
                try
                {
                    if (appender is log4net.Appender.RollingFileAppender fa)
                    {
                        if (fiCurrent == null)
                        {
                            fa.File = strFileName;
                            fa.ActivateOptions();
                            bReplaced = true;
                            break;
                        }
                        else
                        {
                            FileInfo fiOld = new FileInfo(fa.File);

                            if (string.IsNullOrEmpty(fa.DatePattern))
                            {
                                if (fiOld.Name.Replace(fiOld.Extension, "").ToLower().StartsWith(fiCurrent.Name.Replace(fiCurrent.Extension, "").ToLower()))
                                {
                                    fa.File = strFileName;
                                    fa.ActivateOptions();
                                    bReplaced = true;
                                    break;
                                }
                            }
                            else
                            {
                                string strDatePattern = DateTime.Now.ToString(fa.DatePattern);
                                string strExpectedFileName = fiCurrent.Name.Replace(fiCurrent.Extension, "").ToLower() + strDatePattern;

                                if (fiOld.Name.ToLower() == strExpectedFileName.ToLower())
                                {
                                    fa.File = strFileName;
                                    fa.ActivateOptions();
                                    bReplaced = true;
                                    break;
                                }
                            }
                        }
                    }
                    else if (appender is log4net.Appender.FileAppender fa2)
                    {
                        FileInfo fiOld = new FileInfo(fa2.File);

                        if (fiCurrent == null)
                        {
                            fa2.File = strFileName;
                            fa2.ActivateOptions();
                            bReplaced = true;
                            break;
                        }
                        else if (fiOld.Name.ToLower() == fiCurrent.Name.ToLower())
                        {
                            fa2.File = strFileName;
                            fa2.ActivateOptions();
                            bReplaced = true;
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    ErrorFormat("Error Setting File on {0}.  Error: {1}", appender.Name, ex.ToString());
                }
            }
            return bReplaced;
        }

        private void ToggleConfigMonitoring(bool bEnable)
        {
#if !__IOS__
            if (m_fswConfigFile != null)
            {
                m_fswConfigFile.EnableRaisingEvents = bEnable;
                if (!bEnable)
                    m_fswConfigFile = null;
            }
            if (bEnable)
            {
                FileInfo fi = null;
                if (m_fswConfigFile == null)
                {
                    if (!string.IsNullOrEmpty(m_strConfigFile))
                    {
                        // Create a new FileSystemWatcher and set its properties.
                        m_fswConfigFile = new FileSystemWatcher();
                        if (m_fswConfigFile != null)
                        {
                            fi = new FileInfo(m_strConfigFile);
                            m_fswConfigFile.Path = fi.DirectoryName;

                            // Watch for changes in LastAccess and LastWrite times, and
                            // the renaming of files or directories.
                            m_fswConfigFile.NotifyFilter = NotifyFilters.CreationTime
                                                    | NotifyFilters.LastWrite
                                                    | NotifyFilters.FileName
                                                    | NotifyFilters.DirectoryName;

                            // Only watch text files.
                            m_fswConfigFile.Filter = fi.Name;

                            // Add event handlers.
                            m_fswConfigFile.Changed += Watcher_Changed;
                            m_fswConfigFile.Created += Watcher_Changed;
                            m_fswConfigFile.Deleted += Watcher_Changed;
                            m_fswConfigFile.Renamed += Watcher_Changed;

                            // Begin watching.
                            m_fswConfigFile.EnableRaisingEvents = true;
                        }
                    }
                }
                if (fi != null)
                    ReadConfigSettings();
            }
#endif
        }
        /// <summary>
        /// Checks for template configuration values.
        /// </summary>
        /// <param name="strValue"></param>
        /// <returns></returns>
        public bool IsUnEvaluated(string strName, string strValue, bool bCheckForEmpty = false)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strValue }, bSuppresFunctionDeclaration: true))
            {
                if (string.IsNullOrEmpty(strValue))
                {
                    vAutoLogFunction.WriteWarnFormat("Application Setting [{0}] is an Empty/Blank value.", strName);
                    if (bCheckForEmpty)
                        return true;
                }
                strValue = strValue.Trim();
                if (strValue.StartsWith("%") && strValue.EndsWith("%"))
                    return true;
                else if (strValue.StartsWith("#{") && strValue.EndsWith("}"))
                    return true;
                return false;
            }
        }
        /// <summary>
        /// Checks for a valid Connection String.
        /// </summary>
        /// <param name="strValue"></param>
        /// <returns></returns>
        public bool IsConnectionString(string strName, string strValue)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { strValue }, bSuppresFunctionDeclaration: true))
            {
                if (IsUnEvaluated(strName, strValue))
                    return false;
                if (strValue.Contains(";") && strValue.Contains("="))
                {
                    try
                    {
                        SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder(strValue);
                        return true;
                    }
                    catch
                    {
                        vAutoLogFunction.WriteErrorFormat("Value [{0}] cannot be converted to a SqlConnectionStringBuilder.", strValue);
                        return false;
                    }
                }
                return false;
            }
        }
    }
}
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning restore CS8602 // Dereference of a possibly null reference.
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
