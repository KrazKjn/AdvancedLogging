﻿using log4net;
#if __IOS__
using Frsoft.Tms.Mobile.Common;
using Serilog;
using System.Linq2;
#else
using System.Linq;
#endif
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Reflection;
using System.Text;
using static AdvancedLogging.Logging.LoggingUtils;

namespace AdvancedLogging.Logging
{
    public class AutoLogFunction : IDisposable
    {
        private readonly bool m_bIsError = false;
        private bool m_bToLog = true;
        private bool m_bSuppresFunctionDeclaration = false;
        private Stopwatch m_sw = new Stopwatch();
#if __IOS__
        private MethodBase m_function = default!;
        private object m_parameters = default;
#else
        private MethodBase m_function = null;
        private object m_parameters = null;
#endif		
        private Guid m_guidInstanceId;
        private int m_iTabs = 0;
        private string m_strLogPrefix = "";
        private string m_strCallPath = "";
        private string m_strName = "";
        private string m_strFullName = "";
#if __IOS__
        private string? m_strDynamicLoggingNotice = "<-- DYNAMIC LOGGING --> ";
#else
        private string m_strDynamicLoggingNotice = "<-- DYNAMIC LOGGING --> ";
#endif		
        private bool m_bFunctionDeclarationLogged = false;
        private bool m_bFunctionParametersLogged = false;
        private bool m_bMemberTypeInformation = true;
        private ConcurrentDictionary<int, bool> m_dicDetailedLoggingDetected = new ConcurrentDictionary<int, bool>();

#if __IOS__
        public ICLog? Logger
#else
        public ICLog Logger
#endif		
        {
            get { return LoggingUtils.Logger; }
        }

#if __IOS__
        public ILoggerUtility? LoggerUtility
#else
        public ILoggerUtility LoggerUtility
#endif		
        {
            get { return LoggingUtils.LoggerUtility; }
        }
        public int Tabs
        {
            get { return m_iTabs; }
            set { m_iTabs = value; }
        }

        public bool ToLog
        {
            get { return m_bToLog; }
            set { m_bToLog = value; }
        }

        public bool SuppresFunctionDeclaration
        {
            get { return m_bSuppresFunctionDeclaration; }
            set { m_bSuppresFunctionDeclaration = value; }
        }

        private Guid GuidInstanceId
        {
            get
            {
                if (m_guidInstanceId == Guid.Empty)
                    m_guidInstanceId = Guid.NewGuid();
                return m_guidInstanceId;
            }
        }

        public string LogPrefix
        {
            get
            {
                if (Function == null)
                {
                    return "[" + GetInt64HashCode(GuidInstanceId.ToByteArray()).ToString("X16") + "] - " + m_strLogPrefix + (FunctionDeclarationLogged ? "\t" : "");
                }
                else
                {
                    switch (Function.MemberType)
                    {
                        case MemberTypes.Method:
                        case MemberTypes.Property:
                            if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod] && p.Value) || ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                            {
                                return "[" + GetInt64HashCode(GuidInstanceId.ToByteArray()).ToString("X16") + "] - " + m_strLogPrefix + (FunctionDeclarationLogged ? "\t" : "");
                            }
                            break;
                        case MemberTypes.Constructor:
                            if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderConstructor] && p.Value) || ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderConstructor])
                            {
                                return "[" + GetInt64HashCode(GuidInstanceId.ToByteArray()).ToString("X16") + "] - " + m_strLogPrefix + (FunctionDeclarationLogged ? "\t" : "");
                            }
                            break;
                    }
                }
                if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod] && p.Value) || ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                {
                    return "[" + GetInt64HashCode(GuidInstanceId.ToByteArray()).ToString("X16") + "] - " + m_strLogPrefix + (FunctionDeclarationLogged ? "\t" : "");
                }
                return "[" + GetInt64HashCode(GuidInstanceId.ToByteArray()).ToString("X16") + "] - " + (FunctionDeclarationLogged ? "\t" : "");
            }
            set { m_strLogPrefix = value; }
        }

        public string CallPath
        {
            get
            {
                if (string.IsNullOrEmpty(m_strCallPath))
                {
                    Initialization();
                    if (Function == null)
                    {
                        // Get calling function where this class is instantiated
                        Function = (new StackFrame(2, true)).GetMethod();
                    }
                    StackTrace st = new StackTrace();
                    StackFrame[] arrFrames = st.GetFrames();
                    if (LoggingUtils.IsRemotingAppender)
                    {
                        ThreadContext.Properties["procnamefull"] = FullName;
                        ThreadContext.Properties["procname"] = (Function.MemberType == MemberTypes.Constructor ? Function.DeclaringType.Name : Function.Name);
                    }
                    m_strCallPath = CLog.FunctionFullPath(arrFrames.Skip(2).ToArray());
                }
                return m_strCallPath;
            }
            set
            {
                m_strCallPath = value;
#if DEBUG
                if (ApplicationSettings.WriteDebug)
                    Debug.WriteLine((LogPrefix == "" ? "-> " : LogPrefix) + m_strCallPath);
#endif
            }
        }

        public MethodBase Function
        {
            get { return m_function; }
            set { m_function = value; }
        }

        public string Name
        {
            get
            {
                if (string.IsNullOrEmpty(m_strName) && m_function != null)
                {
                    m_strName = m_function.MemberType == MemberTypes.Constructor ? m_function.DeclaringType.Name : m_function.Name;
                }
                return m_strName;
            }
            set { m_strName = value; }
        }

        public string FullName
        {
            get
            {
                if (string.IsNullOrEmpty(m_strFullName) && m_function != null)
                {
                    m_strFullName = m_function.DeclaringType.FullName + "." + Name;
                }
                return m_strFullName;
            }
            set { m_strFullName = value; }
        }

        public ConcurrentDictionary<int, bool> DetailedLoggingDetected
        {
            get { return m_dicDetailedLoggingDetected; }
            set { m_dicDetailedLoggingDetected = value; }
        }

        public bool FunctionDeclarationLogged
        {
            get { return m_bFunctionDeclarationLogged; }
            set { m_bFunctionDeclarationLogged = value; }
        }
        public bool FunctionParametersLogged
        {
            get { return m_bFunctionParametersLogged; }
            set { m_bFunctionParametersLogged = value; }
        }
        public bool MemberTypeInformation
        {
            get { return m_bMemberTypeInformation; }
            set { m_bMemberTypeInformation = value; }
        }
#if __IOS__
        public string? DynamicLoggingNotice
#else
        public string DynamicLoggingNotice
#endif		
        {
            get { return m_strDynamicLoggingNotice; }
            set { m_strDynamicLoggingNotice = value; }
        }
        private void Initialization()
        {
            if (ApplicationSettings.Logger != null)
                MemberTypeInformation = ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_MemberTypeInformation];
            if (LoggingUtils.Logger != null)
                DynamicLoggingNotice = LoggingUtils.Logger?.MonitoredSettings.GetOrAdd(CLog.Log_DynamicLoggingNotice, "<-- DYNAMIC LOGGING --> ");
        }
#if V1
#if __IOS__
        public AutoLogFunction(MethodBase _function, AutoLogFunction? _Parent = null, bool bError = false, bool bSuppresFunctionDeclaration = false)
#else
        public AutoLogFunction(MethodBase _function, AutoLogFunction _Parent = null, bool bError = false, bool bSuppresFunctionDeclaration = false)
#endif
#else
#if __IOS__
        public AutoLogFunction(MethodBase? _function = null, AutoLogFunction? _Parent = null, bool bError = false, bool bSuppresFunctionDeclaration = false)
#else
        public AutoLogFunction(MethodBase _function = null, AutoLogFunction _Parent = null, bool bError = false, bool bSuppresFunctionDeclaration = false)
#endif
#endif
        {
            if (!AllowLogging)
                return;
            m_sw?.Start();
            Function = _function;
            m_bIsError = bError;
            m_bSuppresFunctionDeclaration = bSuppresFunctionDeclaration;
            if (!bError && bSuppresFunctionDeclaration)
                return;
            if (!WillWriteToLog(bError))
                return;

            if (Function == null)
            {
                // Get calling function where this class is instantiated
                Function = (new StackFrame(1, true)).GetMethod();
            }
            Name = Function.MemberType == MemberTypes.Constructor ? Function.DeclaringType.Name : Function.Name;
            if (IgnoreLogging.GetOrAdd(Name, false))
                return;

            Initialization();
            FullName = Function.DeclaringType.FullName + "." + Name;
            using (ThreadContext.Stacks["NDC"].Push(FullName))
            {
                StackTrace st = new StackTrace();
                StackFrame[] arrFrames = st.GetFrames();
                if (LoggingUtils.IsRemotingAppender)
                {
                    ThreadContext.Properties["procname"] = Name;
                    ThreadContext.Properties["procnamefull"] = FullName;
                }
                CallPath = CLog.FunctionFullPath(arrFrames.Skip(1).ToArray());
                ApplicationSettings.AutoLogActivity.AddOrUpdate(CallPath, GuidInstanceId, (key, oldValue) => GuidInstanceId);

                if (_Parent == null)
                {
                    Tabs = ApplicationSettings.AutoLogActivity.Count(p => CallPath.StartsWith(p.Key.Replace(".AutoLogFunction", ""))) - 1;
                }
                else
                    Tabs = _Parent.Tabs + 1;
                if (Tabs > 0)
                    LogPrefix = new string('\t', Tabs);
                //if (bSuppresFunctionDeclaration)
                //    return;
                try
                {
                    int iLogLevel = 0;
                    if (ApplicationSettings.Logger != null)
                        iLogLevel = ApplicationSettings.Logger.LogLevel;
                    string strMessage = string.Format("[Func: {0}]", FullName + (m_bMemberTypeInformation ? " (" + Function.MemberType.ToString() + ")" : ""));
                    if (LoggingUtils.Logger != null)
                    {
                        if (LoggingUtils.Logger.ToLog(LoggingUtils.Logger.LogLevel, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
                        {
                            if (strDetectedCriteria.Length > 0)
                            {
                                strMessage = string.Format("[Func: {0}]", FullName + " (" + Function.MemberType.ToString() + ") " + DynamicLoggingNotice + "[" + strDetectedCriteria + "]");
                                DetailedLoggingDetected.AddOrUpdate(iDetectedLevel, true, (key, oldValue) => true);
                                iLogLevel = iDetectedLevel;
                            }
                        }
                        else
                        {
                            if (iDetectedLevel < 0)
                                SuppresFunctionDeclaration = true;
                            ToLog = false;
                        }
                    }
                    FunctionDeclarationLogged = WriteToLog(strMessage, bError);
                    int iDebugLevel = DebugPrintLevel[CLog.Log_FunctionHeaderMethod];
                    switch (Function.MemberType)
                    {
                        case MemberTypes.Method:
                        case MemberTypes.Property:
                            if (bError || iLogLevel >= (DebugPrintLevel[CLog.Log_FunctionHeaderMethod] + 1))
                            {
                                strMessage = string.Format("Call Path: {0}", CallPath);
                                if (bError)
                                    WriteError(strMessage);
                                else if (ToLog)
                                    WriteDebug(strMessage);
                            }
                            break;
                        case MemberTypes.Constructor:
                            iDebugLevel = DebugPrintLevel[CLog.Log_FunctionHeaderConstructor];
                            if (bError || iLogLevel >= (DebugPrintLevel[CLog.Log_FunctionHeaderConstructor] + 1))
                            {
                                strMessage = string.Format("Call Path: {0}", CallPath);
                                if (bError)
                                    WriteError(strMessage);
                                else if (ToLog)
                                    WriteDebug(strMessage);
                            }
                            break;
                    }
                }
                catch (Exception ex)
                {
                    WriteError("Error in AutoLogFunction: ", ex);
                }
                finally
                {
                }
            }
        }
#if V1
#if __IOS__
        public AutoLogFunction(MethodBase _function, object _parameters, AutoLogFunction? _Parent = null, bool bError = false, bool bSuppresFunctionDeclaration = false)
#else
        public AutoLogFunction(MethodBase _function, object _parameters, AutoLogFunction _Parent = null, bool bError = false, bool bSuppresFunctionDeclaration = false)
#endif
#else
#if __IOS__
        public AutoLogFunction(object _parameters, MethodBase _function = null, AutoLogFunction? _Parent = null, bool bError = false, bool bSuppresFunctionDeclaration = false)
#else
        public AutoLogFunction(object _parameters, MethodBase _function = null, AutoLogFunction _Parent = null, bool bError = false, bool bSuppresFunctionDeclaration = false)
#endif
#endif
        {
            if (!AllowLogging)
                return;
            m_sw?.Start();
            Function = _function;
            m_parameters = _parameters;
            m_bIsError = bError;
            m_bSuppresFunctionDeclaration = bSuppresFunctionDeclaration;
            if (!bError && bSuppresFunctionDeclaration)
                return;
            if (!WillWriteToLog(bError))
                return;

            if (Function == null)
            {
                // Get calling function where this class is instantiated
                Function = (new StackFrame(1, true)).GetMethod();
            }
            Name = Function.MemberType == MemberTypes.Constructor ? Function.DeclaringType.Name : Function.Name;
            if (IgnoreLogging.GetOrAdd(Name, false))
                return;

            Initialization();
            FullName = Function.DeclaringType.FullName + "." + Name;
            using (ThreadContext.Stacks["NDC"].Push(FullName))
            {
                StackTrace st = new StackTrace();
                StackFrame[] arrFrames = st.GetFrames();
                if (LoggingUtils.IsRemotingAppender)
                {
                    ThreadContext.Properties["procname"] = Name;
                    ThreadContext.Properties["procnamefull"] = FullName;
                }
                CallPath = CLog.FunctionFullPath(arrFrames.Skip(1).ToArray());
                ApplicationSettings.AutoLogActivity.AddOrUpdate(CallPath, GuidInstanceId, (key, oldValue) => GuidInstanceId);
                if (_Parent == null)
                {
                    Tabs = ApplicationSettings.AutoLogActivity.Count(p => CallPath.StartsWith(p.Key.Replace(".AutoLogFunction", ""))) - 1;
                }
                else
                    Tabs = _Parent.Tabs + 1;
                if (Tabs > 0)
                    LogPrefix = new string('\t', Tabs);
                //if (bSuppresFunctionDeclaration)
                //    return;
                try
                {
                    int iLogLevel = 0;
                    if (ApplicationSettings.Logger != null)
                        iLogLevel = ApplicationSettings.Logger.LogLevel;
                    ParameterInfo[] pars = Function.GetParameters();
                    string strMessage = string.Format("[Func: {0}]", FullName + (m_bMemberTypeInformation ? " (" + Function.MemberType.ToString() + ")" : ""));
                    if (LoggingUtils.Logger != null)
                    {
                        if (LoggingUtils.Logger.ToLog(LoggingUtils.Logger.LogLevel, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
                        {
                            if (strDetectedCriteria.Length > 0)
                            {
                                strMessage = string.Format("[Func: {0}]", FullName + " (" + Function.MemberType.ToString() + ") " + DynamicLoggingNotice + "[" + strDetectedCriteria + "]");
                                DetailedLoggingDetected.AddOrUpdate(iDetectedLevel, true, (key, oldValue) => true);
                                iLogLevel = iDetectedLevel;
                            }
                        }
                        else
                        {
                            if (iDetectedLevel < 0)
                                SuppresFunctionDeclaration = true;
                            ToLog = false;
                        }
                    }
                    FunctionDeclarationLogged = WriteToLog(strMessage, bError);
                    int iDebugLevel = DebugPrintLevel[CLog.Log_FunctionHeaderMethod];
                    switch (Function.MemberType)
                    {
                        case MemberTypes.Method:
                        case MemberTypes.Property:
                            if (bError || iLogLevel >= (DebugPrintLevel[CLog.Log_FunctionHeaderMethod] + 1))
                            {
                                strMessage = string.Format("Call Path: {0}", CallPath);
                                if (bError)
                                    WriteError(strMessage);
                                else if (ToLog)
                                    WriteDebug(strMessage);
                            }
                            break;
                        case MemberTypes.Constructor:
                            iDebugLevel = DebugPrintLevel[CLog.Log_FunctionHeaderConstructor];
                            if (bError || iLogLevel >= (DebugPrintLevel[CLog.Log_FunctionHeaderConstructor] + 1))
                            {
                                strMessage = string.Format("Call Path: {0}", CallPath);
                                if (bError)
                                    WriteError(strMessage);
                                else if (ToLog)
                                    WriteDebug(strMessage);
                            }
                            break;
                    }
                    if (ToLog && pars != null && pars.Count() > 0)
                    {
                        LoggingUtils.ProcessParametersNoAutoLog(pars, _parameters, bError, LogPrefix, (DetailedLoggingDetected.Any(p => p.Key >= (iDebugLevel + 2) && p.Value) ? 0 : (iDebugLevel + 2)));
                        FunctionParametersLogged = true;
                    }
                }
                catch (Exception ex)
                {
                    WriteError("Error in AutoLogFunction: ", ex);
                }
                finally
                {
                }
            }
        }
#if V1
        public AutoLogFunction(MethodBase _function, object _parameters, int _Tabs, bool bError = false, bool bSuppresFunctionDeclaration = false)
#else
        public AutoLogFunction(object _parameters, MethodBase _function, int _Tabs, bool bError = false, bool bSuppresFunctionDeclaration = false)
#endif
        {
            if (!AllowLogging)
                return;
            m_sw?.Start();
            Function = _function;
            m_parameters = _parameters;
            m_bIsError = bError;
            m_bSuppresFunctionDeclaration = bSuppresFunctionDeclaration;
            if (!bError && bSuppresFunctionDeclaration)
                return;
            if (!WillWriteToLog(bError))
                return;

            if (Function == null)
            {
                // Get calling function where this class is instantiated
                Function = (new StackFrame(1, true)).GetMethod();
            }
            Name = Function.MemberType == MemberTypes.Constructor ? Function.DeclaringType.Name : Function.Name;
            if (IgnoreLogging.GetOrAdd(Name, false))
                return;

            Initialization();
            FullName = Function.DeclaringType.FullName + "." + Name;
            using (ThreadContext.Stacks["NDC"].Push(FullName))
            {
                StackTrace st = new StackTrace();
                StackFrame[] arrFrames = st.GetFrames();
                if (LoggingUtils.IsRemotingAppender)
                {
                    ThreadContext.Properties["procname"] = Name;
                    ThreadContext.Properties["procnamefull"] = FullName;
                }
                if (_Tabs > -1)
                    Tabs = _Tabs + 1;
                if (Tabs > 0)
                    LogPrefix = new string('\t', Tabs);
                //if (bSuppresFunctionDeclaration)
                //    return;
                try
                {
                    int iLogLevel = 0;
                    if (ApplicationSettings.Logger != null)
                        iLogLevel = ApplicationSettings.Logger.LogLevel;
                    ParameterInfo[] pars = Function.GetParameters();
                    string strMessage = string.Format("[Func: {0}]", FullName + (m_bMemberTypeInformation ? " (" + Function.MemberType.ToString() + ")" : ""));
                    if (LoggingUtils.Logger != null)
                    {
                        if (LoggingUtils.Logger.ToLog(LoggingUtils.Logger.LogLevel, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
                        {
                            if (strDetectedCriteria.Length > 0)
                            {
                                strMessage = string.Format("[Func: {0}]", FullName + " (" + Function.MemberType.ToString() + ") " + DynamicLoggingNotice + "[" + strDetectedCriteria + "]");
                                DetailedLoggingDetected.AddOrUpdate(iDetectedLevel, true, (key, oldValue) => true);
                                iLogLevel = iDetectedLevel;
                            }
                        }
                        else
                        {
                            if (iDetectedLevel < 0)
                                SuppresFunctionDeclaration = true;
                            ToLog = false;
                        }
                    }
                    FunctionDeclarationLogged = WriteToLog(strMessage, bError);
                    int iDebugLevel = DebugPrintLevel[CLog.Log_FunctionHeaderMethod];
                    switch (Function.MemberType)
                    {
                        case MemberTypes.Method:
                        case MemberTypes.Property:
                            if (bError || iLogLevel >= (DebugPrintLevel[CLog.Log_FunctionHeaderMethod] + 1))
                            {
                                CallPath = CLog.FunctionFullPath(arrFrames.Skip(1).ToArray());
                                strMessage = string.Format("Call Path: {0}", CallPath);
                                if (bError)
                                    WriteError(strMessage);
                                else if (ToLog)
                                    WriteDebug(strMessage);
                            }
                            break;
                        case MemberTypes.Constructor:
                            iDebugLevel = DebugPrintLevel[CLog.Log_FunctionHeaderConstructor];
                            if (bError || iLogLevel >= (DebugPrintLevel[CLog.Log_FunctionHeaderConstructor] + 1))
                            {
                                CallPath = CLog.FunctionFullPath(arrFrames.Skip(1).ToArray());
                                strMessage = string.Format("Call Path: {0}", CallPath);
                                if (bError)
                                    WriteError(strMessage);
                                else if (ToLog)
                                    WriteDebug(strMessage);
                            }
                            break;
                    }
                    if (ToLog && pars != null && pars.Count() > 0)
                    {
                        LoggingUtils.ProcessParametersNoAutoLog(pars, _parameters, bError, LogPrefix, (DetailedLoggingDetected.Any(p => p.Key >= (iDebugLevel + 2) && p.Value) ? 0 : (iDebugLevel + 2)));
                        FunctionParametersLogged = true;
                    }
                }
                catch (Exception ex)
                {
                    WriteError("Error in AutoLogFunction: ", ex);
                }
                finally
                {
                }
            }
        }

        private bool WillWriteToLog(bool bError)
        {
            if (!AllowLogging)
                return false;
            if (bError)
            {
                if (Logger != null && Logger.IsErrorEnabled)
                    return true;
                else
                    return false;
            }
            else
            {
                if (Logger != null && !Logger.IsDebugEnabled)
                    return false;
                if (Function != null)
                {
                	if (Logger != null && Logger.ToLog(Logger.LogLevel, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel))
	                {
    	                return true;
        	        }
                    switch (Function.MemberType)
                    {
                        case MemberTypes.Method:
                        case MemberTypes.Property:
                            if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod] && p.Value))
                            {
                                return true;
                            }
                            else
                            {
                                return (LoggingUtils.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod]);
                            }
                        case MemberTypes.Constructor:
                            if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderConstructor] && p.Value))
                            {
                                return true;
                            }
                            else
                            {
                                return (LoggingUtils.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderConstructor]);
                            }
                        default:
                            if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod] && p.Value))
                            {
                                return true;
                            }
                            break;
                    }
                }
                return false;
            }
        }
        private bool WriteToLog(string strMessage, bool bError)
        {
            if (!AllowLogging)
                return false;
            if (bError)
            {
                WriteError(strMessage);
                return true;
            }
            else
            {
                switch (Function.MemberType)
                {
                    case MemberTypes.Method:
                    case MemberTypes.Property:
                        if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod] && p.Value))
                        {
                            WriteDebug(strMessage);
                            return true;
                        }
                        else
                        {
                            WriteDebug((int)DebugPrintLevel[CLog.Log_FunctionHeaderMethod], strMessage);
                            return (LoggingUtils.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod]);
                        }
                    case MemberTypes.Constructor:
                        if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderConstructor] && p.Value))
                        {
                            WriteDebug(strMessage);
                            return true;
                        }
                        else
                        {
                            WriteDebug((int)DebugPrintLevel[CLog.Log_FunctionHeaderConstructor], strMessage);
                            return (LoggingUtils.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderConstructor]);
                        }
                    default:
                        if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod] && p.Value))
                        {
                            WriteDebug(strMessage);
                            return true;
                        }
                        break;
                }
                return false;
            }
        }
#if V1
#if __IOS__
        public void LogFunction(MethodBase _function, bool bError = false, Exception? _ex = null)
#else
        public void LogFunction(MethodBase _function, bool bError = false, Exception _ex = null)
#endif
#else
#if __IOS__
        public void LogFunction(MethodBase _function? = null, bool bError = false, Exception? _ex = null)
#else
        public void LogFunction(MethodBase _function = null, bool bError = false, Exception _ex = null)
#endif
#endif
        {
            if (!AllowLogging)
                return;
            try
            {
                string strMessage = "";

                if (_function == null)
                {
                    // Get calling function where this class is instantiated
                    _function = (new StackFrame(1, true)).GetMethod();
                }
                Function = _function;
                ParameterInfo[] pars = Function.GetParameters();
                Name = Function.MemberType == MemberTypes.Constructor ? Function.DeclaringType.Name : Function.Name;
                FullName = Function.DeclaringType.FullName + "." + Name;
                strMessage = string.Format("[Func: {0}]", FullName + " (" + Function.MemberType.ToString() + ")");
                if (bError)
                {
                    WriteError(strMessage);
                    if (_ex == null)
                        WriteErrorFormat("\tCall Path: {0}", CallPath);
                }
                else
                    WriteDebug(strMessage);

                if (_ex != null)
                {
                    WriteError("\t" + new string('*', 120));
                    WriteErrorFormat("\tException Error: {0}", _ex.GetType().Name + ": " + _ex.Message);
                    WriteError("\t" + new string('*', 120));
                    WriteErrorFormat("\tCall Path: {0}", CallPath);
                    WriteError("\tSource: " + _ex.Source);
                    WriteError("\tTargetSite: " + _ex.TargetSite);
                    // {"Attempted to divide by zero."}
                    foreach (string strItem in GetAllFootprints(_ex))
                    {
                        WriteError("\t" + strItem);
                    }
                    WriteError("\t" + new string('*', 120));
                }
            }
            catch (Exception ex)
            {
                WriteError("Error in LogFunction: ", ex);
            }
            finally
            {
                if (m_sw == null)
                {
                    if (bError)
                        WriteError("[End Func]");
                    else
                        WriteDebug("[End Func]");
                }
                else
                {
                    if (bError)
                        WriteErrorFormat("[End Func]: Time elapsed: {0}", m_sw.Elapsed);
                    else
                        WriteDebugFormat("[End Func]: Time elapsed: {0}", m_sw.Elapsed);
                }
            }
        }
#if V1
#if __IOS__
        public void LogFunction(MethodBase _function, object _parameters, bool bError = false, Exception? _ex = null)
#else
        public void LogFunction(MethodBase _function, object _parameters, bool bError = false, Exception _ex = null)
#endif
#else
#if __IOS__
        public void LogFunction(object _parameters, MethodBase _function? = null, bool bError = false, Exception? _ex = null)
#else
        public void LogFunction(object _parameters, MethodBase _function = null, bool bError = false, Exception _ex = null)
#endif
#endif
        {
            if (!AllowLogging)
                return;
            try
            {
                string strMessage = "";

                if (_function == null)
                {
                    // Get calling function where this class is instantiated
                    _function = (new StackFrame(1, true)).GetMethod();
                }
                Function = _function;
                ParameterInfo[] pars = Function.GetParameters();
                Name = Function.MemberType == MemberTypes.Constructor ? Function.DeclaringType.Name : Function.Name;
                FullName = Function.DeclaringType.FullName + "." + Name;
                strMessage = string.Format("[Func: {0}]", FullName + " (" + Function.MemberType.ToString() + ")");
                if (bError)
                {
                    WriteError(strMessage);
                    if (_ex == null)
                        WriteErrorFormat("\tCall Path: {0}", CallPath);
                }
                else
                    WriteDebug(strMessage);
                int iDebugLevel = Function.MemberType == MemberTypes.Constructor ? DebugPrintLevel[CLog.Log_FunctionHeaderConstructor] : DebugPrintLevel[CLog.Log_FunctionHeaderMethod];
                if (pars != null && pars.Count() > 0)
                    LoggingUtils.ProcessParametersNoAutoLog(pars, _parameters, bError, LogPrefix + "\t", (DetailedLoggingDetected.Any(p => p.Key >= (iDebugLevel + 2) && p.Value) ? 0 : (iDebugLevel + 2)));
                if (_ex != null)
                {
                    WriteError("\t" + new string('*', 120));
                    WriteErrorFormat("\tException Error: {0}", _ex.GetType().Name + ": " + _ex.Message);
                    WriteError("\t" + new string('*', 120));
                    WriteErrorFormat("\tCall Path: {0}", CallPath);
                    WriteError("\tSource: " + _ex.Source);
                    WriteError("\tTargetSite: " + _ex.TargetSite);
                    // {"Attempted to divide by zero."}
                    foreach (string strItem in GetAllFootprints(_ex))
                    {
                        WriteError("\t" + strItem);
                    }
                    WriteError("\t" + new string('*', 120));
                }
            }
            catch (Exception ex)
            {
                WriteError("Error in LogFunction: ", ex);
            }
            finally
            {
                if (m_sw == null)
                {
                    if (bError)
                        WriteError("[End Func]");
                    else
                        WriteDebug("[End Func]");
                }
                else
                {
                    if (bError)
                        WriteErrorFormat("[End Func]: Time elapsed: {0}", m_sw.Elapsed);
                    else
                        WriteDebugFormat("[End Func]: Time elapsed: {0}", m_sw.Elapsed);
                }
            }
        }
#if V1
#if __IOS__
        public void LogFunction(MethodBase _function, object _parameters, bool bError = false, System.Net.WebException? _ex = null)
#else
        public void LogFunction(MethodBase _function, object _parameters, bool bError = false, System.Net.WebException _ex = null)
#endif
#else
#if __IOS__
        public void LogFunction(object _parameters, MethodBase _function? = null, bool bError = false, System.Net.WebException? _ex = null)
#else
        public void LogFunction(object _parameters, MethodBase _function = null, bool bError = false, System.Net.WebException _ex = null)
#endif
#endif
        {
            if (!AllowLogging)
                return;
            try
            {
                string strMessage = "";

                if (_function == null)
                {
                    // Get calling function where this class is instantiated
                    _function = (new StackFrame(1, true)).GetMethod();
                }
                Function = _function;
                ParameterInfo[] pars = Function.GetParameters();
                Name = Function.MemberType == MemberTypes.Constructor ? Function.DeclaringType.Name : Function.Name;
                FullName = Function.DeclaringType.FullName + "." + Name;
                strMessage = string.Format("[Func: {0}]", FullName + " (" + Function.MemberType.ToString() + ")");
                if (bError)
                {
                    WriteError(strMessage);
                    if (_ex == null)
                        WriteErrorFormat("\tCall Path: {0}", CallPath);
                }
                else
                    WriteDebug(strMessage);
                int iDebugLevel = Function.MemberType == MemberTypes.Constructor ? DebugPrintLevel[CLog.Log_FunctionHeaderConstructor] : DebugPrintLevel[CLog.Log_FunctionHeaderMethod];
                if (pars != null && pars.Count() > 0)
                    LoggingUtils.ProcessParametersNoAutoLog(pars, _parameters, bError, LogPrefix + "\t", (DetailedLoggingDetected.Any(p => p.Key >= (iDebugLevel + 2) && p.Value) ? 0 : (iDebugLevel + 2)));
                if (_ex != null)
                {
                    WriteError("\t" + new string('*', 120));
                    WriteErrorFormat("\tException Error: {0}", _ex.GetType().Name + ": " + _ex.Message);
                    WriteError("\t" + new string('*', 120));
                    WriteErrorFormat("\tCall Path: {0}", CallPath);
                    WriteError("\tSource: " + _ex.Source);
                    WriteError("\tTargetSite: " + _ex.TargetSite);
                    if (_ex.Status == WebExceptionStatus.ProtocolError)
                    {
                        // protocol errors find the statuscode in the Response
                        // the enum statuscode can be cast to an int.
                        int code = (int)((HttpWebResponse)_ex.Response).StatusCode;
                        WriteError("\tStatus Code: " + code.ToString());
                        WriteError("\tStatus Description: " + ((HttpWebResponse)_ex.Response).StatusDescription);
                        WriteError("\tServer: " + ((HttpWebResponse)_ex.Response).Server);
                        WriteError("\tMethod: " + ((HttpWebResponse)_ex.Response).Method);
                        WriteError("\tResponse Uri: " + ((HttpWebResponse)_ex.Response).ResponseUri.OriginalString);
                    }
                    foreach (string strItem in GetAllFootprints(_ex))
                    {
                        WriteError("\t" + strItem);
                    }
                    WriteError("\t" + new string('*', 120));
                }
            }
            catch (Exception ex)
            {
                WriteError("Error in LogFunction: ", ex);
            }
            finally
            {
                if (m_sw == null)
                {
                    if (bError)
                        WriteError("[End Func]");
                    else
                        WriteDebug("[End Func]");
                }
                else
                {
                    if (bError)
                        WriteErrorFormat("[End Func]: Time elapsed: {0}", m_sw.Elapsed);
                    else
                        WriteDebugFormat("[End Func]: Time elapsed: {0}", m_sw.Elapsed);
                }
            }
        }
#if __IOS__
        public void WriteLog(string strMessage, Exception? ex = null)
#else
        public void WriteLog(string strMessage, Exception ex = null)
#endif
        {
            if (Logger != null && Logger.IsInfoEnabled)
            {
                if (AllowLogging)
                    LoggingUtils.WriteLogPrefixNoAutoLog(LogPrefix, strMessage, ex);
            }
        }
        public void WriteLogFormat(string format, params object[] args)
        {
            if (Logger != null && Logger.IsInfoEnabled)
            {
                if (AllowLogging)
                    LoggingUtils.WriteLogPrefixNoAutoLog(LogPrefix, string.Format(format, args));
            }
        }
#if __IOS__
        public void WriteDebug(string strMessage, Exception? ex = null)
#else
        public void WriteDebug(string strMessage, Exception ex = null)
#endif
        {
            if (Logger != null && Logger.IsDebugEnabled)
            {
                if (AllowLogging)
                    LoggingUtils.WriteDebugPrefixNoAutoLog(LogPrefix, strMessage, ex);
            }
        }
#if __IOS__
        public void WriteDebug(int DebugLevel, string strMessage, Exception? ex = null)
#else
        public void WriteDebug(int DebugLevel, string strMessage, Exception ex = null)
#endif
        {
            if (Logger != null && Logger.IsDebugEnabled)
            {
                if (AllowLogging)
                {
                    if (DetailedLoggingDetected.Any(p => p.Key >= DebugLevel && p.Value))
                        LoggingUtils.WriteDebugPrefixNoAutoLog(LogPrefix, strMessage, ex);
                    else
                        LoggingUtils.WriteDebugPrefixNoAutoLog(DebugLevel, LogPrefix, strMessage, ex);
                }
            }
        }
        public void WriteDebugFormat(string format, params object[] args)
        {
            if (Logger != null && Logger.IsDebugEnabled)
            {
                if (AllowLogging)
                    LoggingUtils.WriteDebugFormatPrefixNoAutoLog(LogPrefix, format, args);
            }
        }
        public void WriteDebugFormat(int DebugLevel, string format, params object[] args)
        {
            if (Logger != null && Logger.IsDebugEnabled)
            {
                if (AllowLogging)
                {
                    if (DetailedLoggingDetected.Any(p => p.Key >= DebugLevel && p.Value))
                        LoggingUtils.WriteDebugFormatPrefixNoAutoLog(LogPrefix, format, args);
                    else
                        LoggingUtils.WriteDebugFormatPrefixNoAutoLog(DebugLevel, LogPrefix, format, args);
                }
            }
        }
        //public void WriteDebugFormat(int DebugLevel, string strFunction, string format, params object[] args)
        //{
        //    if (AllowLogging)
        //    {
        //        if (DetailedLoggingDetected.Any(p => p.Key >= DebugLevel && p.Value))
        //            LoggingUtils.WriteDebugFormatPrefixNoAutoLog(LogPrefix, strFunction, format, args);
        //        else
        //            LoggingUtils.WriteDebugFormatPrefixNoAutoLog(DebugLevel, LogPrefix, strFunction, format, args);
        //    }
        //}
#if __IOS__
        public void WriteWarn(string strMessage, Exception? ex = null)
#else
        public void WriteWarn(string strMessage, Exception ex = null)
#endif
        {
            if (Logger != null && Logger.IsWarnEnabled)
            {
                if (AllowLogging)
                    LoggingUtils.WriteWarnPrefixNoAutoLog(LogPrefix, strMessage, ex);
            }
        }
        public void WriteWarnFormat(string format, params object[] args)
        {
            if (Logger != null && Logger.IsWarnEnabled)
            {
                if (AllowLogging)
                    LoggingUtils.WriteWarnPrefixNoAutoLog(LogPrefix, string.Format(format, args));
            }
        }
#if __IOS__
        public void WriteError(string strMessage, Exception? ex = null)
#else
        public void WriteError(string strMessage, Exception ex = null)
#endif
        {
            if (Logger != null && Logger.IsErrorEnabled)
            {
                if (AllowLogging)
                    LoggingUtils.WriteErrorPrefixNoAutoLog(LogPrefix, strMessage, ex);
            }
        }
        public void WriteErrorFormat(string format, params object[] args)
        {
            if (Logger != null && Logger.IsErrorEnabled)
            {
                if (AllowLogging)
                    LoggingUtils.WriteErrorFormatNoAutoLog(LogPrefix + format, args);
            }
        }
#if __IOS__
        public void WriteFatal(string strMessage, Exception? ex = null)
#else
        public void WriteFatal(string strMessage, Exception ex = null)
#endif
        {
            if (Logger != null && Logger.IsFatalEnabled)
            {
                if (AllowLogging)
                    LoggingUtils.WriteFatalPrefixNoAutoLog(LogPrefix, strMessage, ex);
            }
        }
        public void WriteFatalFormat(string format, params object[] args)
        {
            if (Logger != null && Logger.IsFatalEnabled)
            {
                if (AllowLogging)
                    LoggingUtils.WriteFatalFormatNoAutoLog(LogPrefix + format, args);
            }
        }
        // public static void WriteErrorFormat(string format, params object[] args)
        private void ProcessStopWatchNoAutoLog(ref Stopwatch sw, string strFunction, string strMessage = "")
        {
            if (!AllowLogging)
                return;
            string strLogPrefix = "";
            try
            {
                if (strFunction.ToLower().Contains(".sqlhelper") || strFunction.ToLower().Contains("httpwebextensions"))
                {
                    if (sw?.Elapsed.TotalMinutes >= LoggingUtils.Logger?.AutoLogSQLThreshold)
                    {
                        if (strLogPrefix == "")
                            strLogPrefix = LogPrefix;
                        LoggingUtils.Logger?.Warn(strLogPrefix + "+" + new string('-', 79));
                        LoggingUtils.Logger?.WarnFormat("{0}+   Function: [{1}] - {2} Exceeded Time Threashold of [{3}] minutes - Actual [{4}] minutes.", strLogPrefix, strFunction, (strMessage.Length > 0 ? "HTTP Query" : ""), LoggingUtils.Logger?.AutoLogSQLThreshold, sw?.Elapsed);
                        LoggingUtils.Logger?.Warn(strLogPrefix + "+" + new string('-', 79));
                        if (strMessage.Length > 0)
                        {
                            LoggingUtils.Logger?.Warn(strLogPrefix + "+" + new string('-', 79));
                            LoggingUtils.Logger?.Warn(strLogPrefix + "+   Web Call Information: " + strMessage);
                            LoggingUtils.Logger?.Warn(strLogPrefix + "+" + new string('-', 79));
                        }
                    }
                    else if (sw?.Elapsed.TotalSeconds >= LoggingUtils.MaxFunctionTimeThreshold)
                    {
                        LoggingUtils.Logger?.Warn("+" + new string('-', 79));
                        LoggingUtils.Logger?.WarnFormat("+   Function: [{0}] - {1} Exceeded Time Threashold of [{2}] seconds - Actual [{3}] seconds.", strFunction, "Function", LoggingUtils.MaxFunctionTimeThreshold, sw.Elapsed);
                        LoggingUtils.Logger?.Warn("+" + new string('-', 79));
                    }
                }
                else
                {
                    if (sw?.Elapsed.TotalSeconds >= LoggingUtils.MaxFunctionTimeThreshold)
                    {
                        LoggingUtils.Logger?.Warn("+" + new string('-', 79));
                        LoggingUtils.Logger?.WarnFormat("+   Function: [{0}] - {1} Exceeded Time Threashold of [{2}] seconds - Actual [{3}] seconds.", strFunction, "Function", LoggingUtils.MaxFunctionTimeThreshold, sw.Elapsed);
                        LoggingUtils.Logger?.Warn("+" + new string('-', 79));
                    }
                }
                switch (Function.MemberType)
                {
                    case MemberTypes.Method:
                    case MemberTypes.Property:
                        if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod] && p.Value) || LoggingUtils.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                        {
                            if (strLogPrefix == "")
                                strLogPrefix = LogPrefix;
                            if (sw == null)
                                LoggingUtils.Logger?.DebugFormat(strLogPrefix + "[End Func]");
                            else
                                LoggingUtils.Logger?.DebugFormat(strLogPrefix + "[End Func]: Time elapsed: {0}", sw.Elapsed);
                        }
                        break;
                    case MemberTypes.Constructor:
                        if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderConstructor] && p.Value) || LoggingUtils.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderConstructor])
                        {
                            if (strLogPrefix == "")
                                strLogPrefix = LogPrefix;
                            if (sw == null)
                                LoggingUtils.Logger?.DebugFormat(strLogPrefix + "[End Func]");
                            else
                                LoggingUtils.Logger?.DebugFormat(strLogPrefix + "[End Func]: Time elapsed: {0}", sw.Elapsed);
                        }
                        break;
                    default:
                        if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod] && p.Value) || LoggingUtils.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                        {
                            if (strLogPrefix == "")
                                strLogPrefix = LogPrefix;
                            if (sw == null)
                                LoggingUtils.Logger?.DebugFormat(strLogPrefix + "[End Func]");
                            else
                                LoggingUtils.Logger?.DebugFormat(strLogPrefix + "[End Func]: Time elapsed: {0}", sw.Elapsed);
                        }
                        break;
                }
            }
            catch (Exception ExOuter)
            {
                if (strLogPrefix == "")
                    strLogPrefix = LogPrefix;
                LoggingUtils.LogFunctionNoAutoLog(System.Reflection.MethodBase.GetCurrentMethod(), new { sw, strFunction, strMessage, strLogPrefix }, true, strLogPrefix);
                LoggingUtils.Logger?.Error(strLogPrefix + string.Format("{0}", System.Reflection.MethodBase.GetCurrentMethod().Name), ExOuter);
                throw;
            }
        }
        public void Dispose()
        {
            if (!AllowLogging)
                return;
            if (FunctionDeclarationLogged && !IgnoreLogging.GetOrAdd(Name, false))
            {
                FunctionDeclarationLogged = false;
                if (m_sw == null)
                {
                    if (m_bIsError)
                        WriteError("[End Func]");
                    else
                    {
                        if (m_bSuppresFunctionDeclaration)
                            return;
                        switch (Function.MemberType)
                        {
                            case MemberTypes.Method:
                            case MemberTypes.Property:
                                if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod] && p.Value))
                                    WriteDebug("[End Func]");
                                else
                                    WriteDebug(DebugPrintLevel[CLog.Log_FunctionHeaderMethod], "[End Func]");
                                break;
                            case MemberTypes.Constructor:
                                if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderConstructor] && p.Value))
                                    WriteDebug("[End Func]");
                                else
                                    WriteDebug(DebugPrintLevel[CLog.Log_FunctionHeaderConstructor], "[End Func]");
                                break;
                            default:
                                WriteDebug(DebugPrintLevel[CLog.Log_FunctionHeaderMethod], "[End Func]");
                                break;
                        }
                    }
                }
                else
                {
                    TimeSpan ts = m_sw.Elapsed;
                    switch (Function.MemberType)
                    {
                        case MemberTypes.Method:
                        case MemberTypes.Property:
                            if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                            {
                                if (!m_bSuppresFunctionDeclaration)
                                    ProcessStopWatchNoAutoLog(ref m_sw, FullName);
                            }
                            else
                            {
                                if (m_bIsError)
                                    WriteErrorFormat("[End Func]: Time elapsed: {0}", ts);
                                else
                                {
                                    if (!m_bSuppresFunctionDeclaration)
                                    {
                                        if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod] && p.Value))
                                            WriteDebugFormat("[End Func]: Time elapsed: {0}", ts);
                                        else
                                            WriteDebugFormat(DebugPrintLevel[CLog.Log_FunctionHeaderMethod], "[End Func]: Time elapsed: {0}", ts);
                                    }
                                }
                            }
                            break;
                        case MemberTypes.Constructor:
                            if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderConstructor])
                            {
                                if (!m_bSuppresFunctionDeclaration)
                                    ProcessStopWatchNoAutoLog(ref m_sw, FullName);
                            }
                            else
                            {
                                if (m_bIsError)
                                    WriteErrorFormat("[End Func]: Time elapsed: {0}", ts);
                                else
                                {
                                    if (!m_bSuppresFunctionDeclaration)
                                    {
                                        if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderConstructor] && p.Value))
                                            WriteDebugFormat("[End Func]: Time elapsed: {0}", ts);
                                        else
                                            WriteDebugFormat(DebugPrintLevel[CLog.Log_FunctionHeaderConstructor], "[End Func]: Time elapsed: {0}", ts);
                                    }
                                }
                            }
                            break;
                        default:
                            if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod])
                            {
                                if (!m_bSuppresFunctionDeclaration)
                                    ProcessStopWatchNoAutoLog(ref m_sw, FullName);
                            }
                            else
                            {
                                if (m_bIsError)
                                    WriteErrorFormat("[End Func]: Time elapsed: {0}", ts);
                                else
                                {
                                    if (!m_bSuppresFunctionDeclaration)
                                    {
                                        if (DetailedLoggingDetected.Any(p => p.Key >= DebugPrintLevel[CLog.Log_FunctionHeaderMethod] && p.Value))
                                            WriteDebugFormat("[End Func]: Time elapsed: {0}", ts);
                                        else
                                            WriteDebugFormat(DebugPrintLevel[CLog.Log_FunctionHeaderMethod], "[End Func]: Time elapsed: {0}", ts);
                                    }
                                }
                            }
                            break;
                    }
                }
            }
            m_sw?.Stop();
            if (!string.IsNullOrEmpty(CallPath))
            {
                if (ApplicationSettings.AutoLogActivity.TryRemove(CallPath, out Guid guidInstance))
                {

                }
            }
        }
        /// <summary>
        /// Return unique Int64 value for input string
        /// </summary>
        /// <param name="strText"></param>
        /// <returns></returns>
        static Int64 GetInt64HashCode(string strText)
        {
            if (!string.IsNullOrEmpty(strText))
            {
                byte[] byteContents = Encoding.Unicode.GetBytes(strText);
                return GetInt64HashCode(byteContents);
            }
            return 0;
        }
        static Int64 GetInt64HashCode(byte[] byteContents)
        {
            Int64 hashCode = 0;
            if (byteContents.Length > 0)
            {
                // Unicode Encode Covering all characterset
                System.Security.Cryptography.SHA256 hash =
                new System.Security.Cryptography.SHA256CryptoServiceProvider();
                byte[] hashText = hash.ComputeHash(byteContents);
                // 32Byte hashText separate
                // hashCodeStart = 0~7  8Byte
                // hashCodeMedium = 8~23  8Byte
                // hashCodeEnd = 24~31  8Byte
                // and Fold
                Int64 hashCodeStart = BitConverter.ToInt64(hashText, 0);
                Int64 hashCodeMedium = BitConverter.ToInt64(hashText, 8);
                Int64 hashCodeEnd = BitConverter.ToInt64(hashText, 24);
                hashCode = hashCodeStart ^ hashCodeMedium ^ hashCodeEnd;
            }
            return hashCode;
        }
    }
}
