﻿using log4net;
using AdvancedLogging.BE;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Xml;

[assembly: CLSCompliant(true)]
namespace AdvancedLogging.Logging
{
    public interface ICLog : ILog
    {
        event EventHandler<CLogClassTypes.ConfigFileChangedEventArgs> ConfigFileChanged;
        event EventHandler<CLogClassTypes.ConfigSettingChangedEventArgs> ConfigSettingChanged;


        #region Implementation of ILog
        #region Implementation of Debug
        // --------------------------------------------------------------------------------------
        void DebugPrefix(string logPreFix, object message, Exception exception);
        void DebugPrefix(string logPreFix, string functionName, object message, Exception exception);
        // --------------------------------------------------------------------------------------
        bool Debug(Int32 level, object message);
        bool Debug(Int32 level, object message, Exception exception);
        bool DebugFormat(Int32 level, string format, params object[] args);
        bool DebugFormat(Int32 level, string format, object arg0);
        bool DebugFormat(Int32 level, string format, object arg0, object arg1);
        bool DebugFormat(Int32 level, string format, object arg0, object arg1, object arg2);
        bool DebugFormat(Int32 level, IFormatProvider provider, string format, params object[] args);
        // --------------------------------------------------------------------------------------
        bool Debug(Int32 level, string functionName, object message, Exception exception);
        bool DebugPrefix(Int32 level, string logPreFix, object message, Exception exception);
        bool DebugPrefix(Int32 level, string logPreFix, string functionName, object message, Exception exception);
        bool DebugFormat(Int32 level, string functionName, string format, params object[] args);
        bool DebugFormat(Int32 level, string functionName, string format, object arg0);
        bool DebugFormatPrefix(Int32 level, string logPreFix, string functionName, string format, object arg0);
        bool DebugFormat(Int32 level, string functionName, string format, object arg0, object arg1);
        bool DebugFormatPrefix(Int32 level, string logPreFix, string functionName, string format, object arg0, object arg1);
        bool DebugFormat(Int32 level, string functionName, string format, object arg0, object arg1, object arg2);
        bool DebugFormat(Int32 level, string functionName, IFormatProvider provider, string format, params object[] args);
        // --------------------------------------------------------------------------------------
        #endregion Implementation of Debug

        #endregion Implementation of ILog
        bool InCodePathOf(string strFucntion, out string strDetectedFunction);
        bool InCodePathOf(string strFucntion, StackFrame[] arrFrames, out string strDetectedFunction);
        string FullPath(StackFrame[] arrFrames);
        bool LoggingDebug();
        bool ToLog(int _level, out string strDetectedCriteria, out string strDetectedFunction, out int iDetectedLevel);

        Dictionary<string, int> DebugLevels { get; set; }
        ConcurrentDictionary<string, string> MonitoredSettings { get; set; }
        ConcurrentDictionary<string, bool> IsPassword { get; set; }
        //ConcurrentDictionary<string, string> Log4net_Settings { get; set; }
        double AutoLogSQLThreshold { set; get; }
        bool Monitoring { set; get; }
        string LogFile { set; get; }
        string ConfigFile { set; get; }
        int LogLevel { set; get; }
        log4net.Core.Level Level { set; get; }
        string ConfigFileContents { get;  }
        XmlDocument ConfigFileXml { get; }
        XmlDocument ConfigFileXmlDocument { get; }
        /// <summary>
        /// Toggle all appenders to this specified level 
        /// </summary>
        /// <param name="level"></param>
        void ToggleLogging(log4net.Core.Level level);

        /// <summary>
        /// Toggle all appenders to this specified level
        /// </summary>
        /// <param name="logLevel"></param>
        /// <returns></returns>
        log4net.Core.Level ToggleLogging(string logLevel);
        log4net.Core.Level LoggingLevel();

        void SetLogFile(string strFileName, string strAppenderName = "LogFileAppender");

        string GetLogFile(string strAppenderName = "LogFileAppender");

        bool ReplaceLogFile(string strCurrentName, string strFileName);

        bool IsUnEvaluated(string strName, string strValue, bool bCheckForEmpty = false);

        bool IsConnectionString(string strName, string strValue);
    }
}
