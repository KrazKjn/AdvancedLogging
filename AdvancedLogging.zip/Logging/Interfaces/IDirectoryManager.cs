﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace AdvancedLogging.Logging
{
    public interface IDirectoryManager
    {
        DirectoryInfo GetDirectoryInfo(string path);
        FileInfo[] GetDirFiles(DirectoryInfo dir, string searchPattern);
    }
}
