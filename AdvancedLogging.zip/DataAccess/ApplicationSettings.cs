﻿using System.Collections.Concurrent;
//using MHS.HelperLibrary.;

namespace MHS.HelperLibrary.DAL
{
    public class ApplicationSettings
    {
        private static ILoggerUtility _loggerUtility;
        public static ILoggerUtility LoggerUtility
        {
            get { return _loggerUtility; }
            set
            {
                _loggerUtility = value;
                LoggingUtils.LoggerUtility = value;
            }
        }

        private static ICLog _log;

        public static ICLog Logger
        {
            get { return _log; }
            set
            {
                _log = value;
                LoggingUtils.Logger = value;
                SqlHelperStatic.Log = value;
            }
        }

        private static ConcurrentDictionary<string, object> m_dicData = new ConcurrentDictionary<string, object>();

        public static ConcurrentDictionary<string, object> Data
        {
            get { return m_dicData; }
            set { m_dicData = value; }
        }

        public static int MaxAutoRetriesSql = 3;
        public static int AutoRetrySleepMsSql = 250;
        public static int AutoTimeoutIncrementSecondsSql = 0;
        public static int MaxAutoRetriesHttp = 3;
        public static int AutoRetrySleepMsHttp = 250;
        public static int AutoTimeoutIncrementMsHttp = 0;
        public static bool IsRunning = true;
        public static System.Security.Authentication.SslProtocols SslProtocols = System.Security.Authentication.SslProtocols.None;
        private static ConcurrentDictionary<string, int> m_bagAutoLogActivity = new ConcurrentDictionary<string, int>();
        public static ConcurrentDictionary<string, int> AutoLogActivity
        {
            get { return m_bagAutoLogActivity; }
            set { m_bagAutoLogActivity = value; }
        }
    }
}
