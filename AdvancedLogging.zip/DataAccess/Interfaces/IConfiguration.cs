﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AdvancedLogging.DAL.Interfaces
{
    /// <summary>
    /// Interface for createing a Configuration Server Data Access Layer Object
    /// </summary>
    public interface IConfigurationServerFactory
    {
        IConfigurationServer Create(string url);
    }

    /// <summary>
    /// Interface for reading a configuration from the Configuration Server
    /// </summary>
    public interface IConfigurationServer
    {
        Dictionary<string, BE.ConfigurationParameter> GetConfigurationParametersWithDefaults(string clientName, string applicationName);
    }
}
