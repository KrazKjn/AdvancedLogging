﻿using AdvancedLogging.BE;

namespace AdvancedLogging.DAL.Interfaces
{
    using AdvancedLogging.BE;
    using System.Data.SqlClient;

    public interface IVersionInfoDAL
    {
        DatabaseVersionInfo GetDatabaseVersion(SqlConnectionStringBuilder ConnectionString);
        DatabaseVersionInfo GetDatabaseVersion(string dbConnectionString);
    }
}
