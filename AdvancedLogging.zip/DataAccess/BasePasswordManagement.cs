using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using MHS.HelperLibrary.BE;
using MHS.HelperLibrary.Logging;

namespace MHS.HelperLibrary.DAL
{
    public class BasePasswordManagement
    {
        protected ISqlHelper sqlHelper;
        protected string connectionString;

        protected BasePasswordManagement(string connectionStringToUse)
        {
            using (var vAutoLogFunction = new AutoLogFunction(System.Reflection.MethodBase.GetCurrentMethod(), new { connectionStringToUse }))
            {
                try
                {
                    connectionString = connectionStringToUse;
                    sqlHelper = new MHS.HelperLibrary.DAL.SqlHelper();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), new { connectionStringToUse }, true, ExOuter);
                    throw;
                }
            }
        }

        protected BasePasswordManagement(string connectionStringToUse, ISqlHelper sqlHelperToUse)
        {
            using (var vAutoLogFunction = new AutoLogFunction(System.Reflection.MethodBase.GetCurrentMethod(), new { connectionStringToUse, sqlHelperToUse }))
            {
                try
                {
                    connectionString = connectionStringToUse;
                    sqlHelper = sqlHelperToUse;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), new { connectionStringToUse, sqlHelperToUse }, true, ExOuter);
                    throw;
                }
            }
        }

        protected string HashTypeToString(HashType hashType)
        {
            using (var vAutoLogFunction = new AutoLogFunction(System.Reflection.MethodBase.GetCurrentMethod(), new { hashType }))
            {
                try
                {
                    string hashTypeString = String.Empty;

                    switch (hashType)
                    {
                        case HashType.Unsecured:
                            hashTypeString = "UNSECURE";
                            break;
                        case HashType.SHA2_256:
                            hashTypeString = "SHA2-256";
                            break;
                        case HashType.SHA2_512:
                            hashTypeString = "SHA2-512";
                            break;
                        default:
                            throw new System.ArgumentException("Unimplemented hash type:" + hashType.ToString(), "hashType");
                    }

                    return hashTypeString;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), new { hashType }, true, ExOuter);
                    throw;
                }
            }
        }

        protected HashType HashStringToType(string hashString)
        {
            using (var vAutoLogFunction = new AutoLogFunction(System.Reflection.MethodBase.GetCurrentMethod(), new { hashString }))
            {
                try
                {
                    HashType resultantHashType;

                    switch (hashString.ToUpper())
                    {
                        case "UNSECURE":
                            resultantHashType = HashType.Unsecured;
                            break;
                        case "SHA2-256":
                            resultantHashType = HashType.SHA2_256;
                            break;
                        case "SHA2-512":
                            resultantHashType = HashType.SHA2_512;
                            break;
                        default:
                            throw new System.ArgumentException("Hash type must be one of: 'UNSECURE', 'SHA2-256', or 'SHA2-512'", "hashString");
                    }

                    return resultantHashType;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), new { hashString }, true, ExOuter);
                    throw;
                }
            }
        }

        protected SecurityHelperInfo BuildSecurityInfoRecord(string query, SqlParameter[] queryParameters)
        {
            using (var vAutoLogFunction = new AutoLogFunction(System.Reflection.MethodBase.GetCurrentMethod(), new { query, queryParameters }))
            {
                try
                {
                    SecurityHelperInfo result;
                    HashType currentHash = HashType.Unsecured;
                    HashType targetHash = HashType.Unsecured;
                    string encryptedPassword = String.Empty;
                    string primaryKey = String.Empty;

                    bool firstRecord = true;

                    vAutoLogFunction.WriteDebug(2, String.Format("Security query: {0}", query));
                    using (IDbConnection connection = sqlHelper.OpenNewConnection(connectionString))
                    {
                        using (ISqlDataReaderHelper resultRow = sqlHelper.ExecuteReader(connection, System.Data.CommandType.Text, query, queryParameters))
                        {
                            while (resultRow.Read())
                            {
                                if (firstRecord)
                                {
                                    firstRecord = false;
                                    primaryKey = resultRow.GetString("SecPrimaryId");
                                    encryptedPassword = resultRow.GetString("Password");
                                    currentHash = HashStringToType(resultRow.GetString("CurrentHash"));
                                    targetHash = HashStringToType(resultRow.GetString("TargetHash"));
                                }
                                else
                                {
                                    throw new Exception("Multiple records returned when querying security for one user");
                                }
                            }
                        }
                    }

                    result = new SecurityHelperInfo
                    {
                        CurrentHash = currentHash,
                        TargetHash = targetHash,
                        EncryptedPassword = encryptedPassword,
                        PrimaryKeyStr = primaryKey
                    };

                    vAutoLogFunction.WriteDebug(2, String.Format("CurrentHash = {0}, TargetHash = {1}, EncryptedPassword = |{2}|, PrimaryKeyStr = {3} ", currentHash.ToString(), targetHash.ToString(), encryptedPassword, primaryKey));

                    return result;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), new { query, queryParameters }, true, ExOuter);
                    throw;
                }
            }
        }
    }
}
