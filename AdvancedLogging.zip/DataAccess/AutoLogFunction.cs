﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using MHS.HelperLibrary.Utils;

namespace MHS.HelperLibrary.DAL
{
    public class AutoLogFunction : IDisposable
    {
        private readonly bool m_bIsError = false;
        private Stopwatch m_sw = new Stopwatch();
        private MethodBase m_function = null;
        private readonly Guid m_guidInstanceId = Guid.NewGuid();
        private int m_iTabs = 0;
        private string m_strLogPrefix = "";
        private string m_strCallPath;
        private bool m_bDetailedLoggingDetected = false;
        private bool m_bFunctionDeclarationLogged = false;

        public int Tabs
        {
            get { return m_iTabs; }
            set { m_iTabs = value; }
        }

        public string LogPrefix
        {
            get
            {
                return "[" + m_guidInstanceId + "] - "  + m_strLogPrefix;
            }
            set { m_strLogPrefix = value; }
        }

        public string CallPath
        {
            get { return m_strCallPath; }
            set
            {
                m_strCallPath = value;
#if DEBUG
                Debug.WriteLine((m_strLogPrefix == "" ? "-> " : LogPrefix) + m_strCallPath);
#endif
            }
        }
        public bool DetailedLoggingDetected
        {
            get { return m_bDetailedLoggingDetected; }
            set { m_bDetailedLoggingDetected = value; }
        }        
        public bool FunctionDeclarationLogged
        {
            get { return m_bFunctionDeclarationLogged; }
            set { m_bFunctionDeclarationLogged = value; }
        }
        public AutoLogFunction(MethodBase _function, AutoLogFunction _Parent = null, bool bError = false)
        {
            StackTrace st = new StackTrace(); ;
            StackFrame[] arrFrames = st.GetFrames();
            m_sw?.Start();
            m_function = _function;
            CallPath = CLog.FunctionFullPath(arrFrames);
            ApplicationSettings.AutoLogActivity.AddOrUpdate(CallPath, 0, (key, oldValue) => 0);
            if (_Parent == null)
            {
                Tabs = ApplicationSettings.AutoLogActivity.Count(p => CallPath.StartsWith(p.Key.Replace(".AutoLogFunction", ""))) - 1;
            }
            else
                Tabs = _Parent.Tabs + 1;
            if (Tabs > 0)
                LogPrefix = new string('\t', Tabs);
            try
            {
                string strMessage = string.Format("[Func: {0}]", _function.DeclaringType.FullName + " (" + _function.MemberType.ToString() + ")");
                if (LoggingUtils.Logger != null)
                {
                    if (LoggingUtils.Logger.ToLog(LoggingUtils.Logger.LogLevel, out string strDetectedCriteria, out string strDetectedFunction))
                    {
                        if (strDetectedCriteria.Length > 0)
                        {
                            strMessage = string.Format("[Func: {0}]", _function.DeclaringType.FullName + " (" + _function.MemberType.ToString() + ") <-- DYNAMIC LOGGING --> [" + strDetectedCriteria + "]");
                            DetailedLoggingDetected = true;
                        }
                    }
                }
                FunctionDeclarationLogged = WriteToLog(strMessage, bError);

                if (ApplicationSettings.Logger?.LogLevel > 4)
                {
                    strMessage = string.Format("\tCall Path: {0}", CallPath);
                    if (bError)
                        WriteError(strMessage);
                    else
                        WriteDebug(strMessage);
                }
            }
            catch (Exception ex)
            {
                WriteError("Error in LogFuntion: ", ex);
            }
            finally
            {
            }
        }
        public AutoLogFunction(MethodBase _function, object _parameters, AutoLogFunction _Parent = null, bool bError = false)
        {
            StackTrace st = new StackTrace(); ;
            StackFrame[] arrFrames = st.GetFrames();
            m_sw?.Start();
            m_function = _function;
            m_bIsError = bError;
            CallPath = CLog.FunctionFullPath(arrFrames);
            ApplicationSettings.AutoLogActivity.AddOrUpdate(CallPath, 0, (key, oldValue) => 0);
            if (_Parent == null)
            {
                Tabs = ApplicationSettings.AutoLogActivity.Count(p => CallPath.StartsWith(p.Key.Replace(".AutoLogFunction", ""))) - 1;
            }
            else
                Tabs = _Parent.Tabs + 1;
            if (Tabs > 0)
                LogPrefix = new string('\t', Tabs);
            try
            {
                ParameterInfo[] pars = _function.GetParameters();
                string strMessage = string.Format("[Func: {0}]", _function.DeclaringType.FullName + " (" + _function.MemberType.ToString() + ")");
                if (LoggingUtils.Logger != null)
                {
                    if (LoggingUtils.Logger.ToLog(LoggingUtils.Logger.LogLevel, out string strDetectedCriteria, out string strDetectedFunction))
                    {
                        if (strDetectedCriteria.Length > 0)
                        {
                            strMessage = string.Format("[Func: {0}]", _function.DeclaringType.FullName + " (" + _function.MemberType.ToString() + ") <-- DYNAMIC LOGGING --> [" + strDetectedCriteria + "]");
                            DetailedLoggingDetected = true;
                        }
                    }
                }
                FunctionDeclarationLogged = WriteToLog(strMessage, bError);
                if (ApplicationSettings.Logger?.LogLevel > 4)
                {
                    strMessage = string.Format("\tCall Path: {0}", CallPath);
                    if (bError)
                        WriteError(strMessage);
                    else
                        WriteDebug(strMessage);
                }
                ProcessParameters(pars, _parameters, bError);
            }
            catch (Exception ex)
            {
                WriteError("Error in LogFuntion: ", ex);
            }
            finally
            {
            }
        }
        public AutoLogFunction(MethodBase _function, object _parameters, int _Tabs, bool bError = false)
        {
            m_sw?.Start();
            m_function = _function;
            m_bIsError = bError;
            if (_Tabs > -1)
                Tabs = _Tabs + 1;
            if (Tabs > 0)
                LogPrefix = new string('\t', Tabs);
            try
            {
                ParameterInfo[] pars = _function.GetParameters();
                string strMessage = string.Format("[Func: {0}]", _function.DeclaringType.FullName + " (" + _function.MemberType.ToString() + ")");
                if (LoggingUtils.Logger != null)
                {
                    if (LoggingUtils.Logger.ToLog(LoggingUtils.Logger.LogLevel, out string strDetectedCriteria, out string strDetectedFunction))
                    {
                        if (strDetectedCriteria.Length > 0)
                        {
                            strMessage = string.Format("[Func: {0}]", _function.DeclaringType.FullName + " (" + _function.MemberType.ToString() + ") <-- DYNAMIC LOGGING --> [" + strDetectedCriteria + "]");
                            DetailedLoggingDetected = true;
                        }
                    }
                }
                FunctionDeclarationLogged = WriteToLog(strMessage, bError);
                if (ApplicationSettings.Logger?.LogLevel > 4)
                {
                    StackTrace st = new StackTrace();
                    StackFrame[] arrFrames = st.GetFrames();
                    CallPath = CLog.FunctionFullPath(arrFrames);
                    strMessage = string.Format("\tCall Path: {0}", CallPath);
                    if (bError)
                        WriteError(strMessage);
                    else
                        WriteDebug(strMessage);
                }
                ProcessParameters(pars, _parameters, bError);
            }
            catch (Exception ex)
            {
                WriteError("Error in LogFuntion: ", ex);
            }
            finally
            {
            }
        }
        private void ProcessParameters(ParameterInfo[] pars, object _parameters, bool bError = false)
        {
            if (pars.Length == 0)
            {
                throw new ArgumentOutOfRangeException("Parameter [pars] is empty.");
            }
            int i = 0;
            string strMessage = "";
            foreach (PropertyInfo pi in _parameters.GetType().GetProperties())
            {
                string strName = pars[i].ParameterType.Name;
                string strFullName = pars[i].ParameterType.FullName;
                System.Type _Type = pars[i].ParameterType;
                List<string> lstValueType  = new List<string>();
                bool bIsArray = false;
                int iDimensions = 0;
#if DEBUG
                if (ApplicationSettings.Logger?.LogLevel >= 2)
                    Debug.WriteLine((LogPrefix == "" ? "-> " : LogPrefix) + pars[i].ParameterType.FullName);
#endif
                if (pars[i].ParameterType.FullName.EndsWith("&"))
                {
                    strFullName = pars[i].ParameterType.FullName.Replace("&", "");
                }
                if (strFullName.EndsWith("[]"))
                {
                    bIsArray = true;
                    strFullName = strFullName.Replace("[]", "");
                }
                if (strFullName.Contains("`") && strFullName.Contains("[["))
                {
                    // "System.Collections.Generic.List`1[[System.String, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]"
                    bIsArray = true;
                    string[] arrItems = strFullName.Split('`');
                    strFullName = arrItems[0];
                    string strTemp = arrItems[1].Substring(0, arrItems[1].IndexOf("["));
                    iDimensions = int.Parse(strTemp);
                    strTemp = arrItems[1].Substring(arrItems[1].IndexOf("[") + 1);
                    strTemp = strTemp.Substring(0, strTemp.Length - 2);
                    arrItems = strTemp.Split(']');
                    foreach (string strItem in arrItems)
                    {
                        lstValueType.Add(strItem.Split('[')[1].Split(',')[0]);
                    }
                }
                if (pars[i].ParameterType.Name.Contains("`"))
                {                    
                    strName = pars[i].ParameterType.Name.Split('`')[0];
                }
                switch (strFullName)
                {
                    case "System.Data.SqlClient.SqlCommand":
                        //System.Data.SqlClient.SqlCommand sc = (System.Data.SqlClient.SqlCommand)pi.GetValue(_parameters, null);
                        //if (bError)
                        //    LoggingUtils.WriteError("\tCommand: " + sc.CommandText);
                        //else
                        //{
                        //    ApplicationSettings.logger?.Debug("\tCommand: " + sc.CommandText);
                        //    Debug.WriteLine("\tCommand: " + sc.CommandText);
                        //}
                        //if (sc.Parameters != null)
                        //{
                        //    SqlHelperStatic.LogSQLData(sc.Parameters);
                        //}
                        strMessage = string.Format("\t({0}){1}: {2}", i < pars.Length ? strName : "???", pi.Name, ApplicationSettings.Logger?.LogLevel >= 10 ? "(See Command/Parameters/Values Below)" : "(See Command Below.  Set LogLevel >= 10 for Parameters/Values)");
                        WriteToLog(strMessage, bError);
                        break;
                    case "System.Collections.Generic.List":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        if (ApplicationSettings.Logger?.LogLevel >= 6)
                        {
                            switch (lstValueType[0])
                            {
                                case "System.String":
                                    {
                                        List<string> vList = (List<string>)pi.GetValue(_parameters, null);
                                        foreach (string vItem in vList)
                                        {
                                            strMessage = string.Format("\t\t{0}", vItem);
                                            if (bError)
                                                WriteError(strMessage);
                                            else
                                                WriteDebug(strMessage);
                                        }
                                    }
                                    break;
                                case "System.Int":
                                    {
                                        List<int> vList = (List<int>)pi.GetValue(_parameters, null);
                                        foreach (int vItem in vList)
                                        {
                                            strMessage = string.Format("\t\t{0}", vItem.ToString());
                                            if (bError)
                                                WriteError(strMessage);
                                            else
                                                WriteDebug(strMessage);
                                        }
                                    }
                                    break;
                            }
                        }
                        break;
                    case "System.Collections.Generic.SortedDictionary":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        if (ApplicationSettings.Logger?.LogLevel >= 6)
                        {
                            switch (lstValueType[0])
                            {
                                case "System.String":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    SortedDictionary<string, string> vList = (SortedDictionary<string, string>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    SortedDictionary<string, int> vList = (SortedDictionary<string, int>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                                case "System.Int":
                                case "System.Int32":
                                case "System.Int64":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    SortedDictionary<int, string> vList = (SortedDictionary<int, string>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    SortedDictionary<int, int> vList = (SortedDictionary<int, int>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                            }
                        }
                        break;
                    case "System.Collections.Generic.Dictionary":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        if (ApplicationSettings.Logger?.LogLevel >= 6)
                        {
                            switch (lstValueType[0])
                            {
                                case "System.String":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    Dictionary<string, string> vList = (Dictionary<string, string>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    Dictionary<string, int> vList = (Dictionary<string, int>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                                case "System.Int":
                                case "System.Int32":
                                case "System.Int64":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    Dictionary<int, string> vList = (Dictionary<int, string>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    Dictionary<int, int> vList = (Dictionary<int, int>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                            }
                        }
                        break;
                    case "System.Collections.Concurrent.ConcurrentDictionary":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        if (ApplicationSettings.Logger?.LogLevel >= 6)
                        {
                            switch (lstValueType[0])
                            {
                                case "System.String":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    ConcurrentDictionary<string, string> vList = (ConcurrentDictionary<string, string>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    ConcurrentDictionary<string, int> vList = (ConcurrentDictionary<string, int>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                                case "System.Int":
                                case "System.Int32":
                                case "System.Int64":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    ConcurrentDictionary<int, string> vList = (ConcurrentDictionary<int, string>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    ConcurrentDictionary<int, int> vList = (ConcurrentDictionary<int, int>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                            }
                        }
                        break;
                    case "System.Collections.Generic.SortedList":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        if (ApplicationSettings.Logger?.LogLevel >= 6)
                        {
                            switch (lstValueType[0])
                            {
                                case "System.String":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    SortedList<string, string> vList = (SortedList<string, string>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    SortedList<string, int> vList = (SortedList<string, int>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                                case "System.Int":
                                case "System.Int32":
                                case "System.Int64":
                                    {
                                        switch (lstValueType[1])
                                        {
                                            case "System.String":
                                                {
                                                    SortedList<int, string> vList = (SortedList<int, string>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                            case "System.Int16":
                                            case "System.Int32":
                                            case "System.Int64":
                                                {
                                                    SortedList<int, int> vList = (SortedList<int, int>)pi.GetValue(_parameters, null);
                                                    foreach (var vItem in vList)
                                                    {
                                                        strMessage = string.Format("\t\t{0} - {1}", vItem.Key, vItem.Value);
                                                        if (bError)
                                                            WriteError(strMessage);
                                                        else
                                                            WriteDebug(strMessage);
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                    break;
                            }
                        }
                        break;
                    case "System.Array":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        if (ApplicationSettings.Logger?.LogLevel >= 6)
                        {
                            System.Array vArray = pi.GetValue(_parameters, null) as System.Array;
                            foreach (var vItem in vArray)
                            {
                                strMessage = string.Format("\t\t{0}", vItem);
                                if (bError)
                                    WriteError(strMessage);
                                else
                                    WriteDebug(strMessage);
                            }
                        }
                        break;
                    case "MHS.HelperLibrary.Utils.ICLog":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        if (ApplicationSettings.Logger?.LogLevel >= 6)
                        {
                            CLog log = (CLog)pi.GetValue(_parameters, null);
                            strMessage = string.Format("\tFileName: {0}", log.LogFile?? "Not Configued");
                            if (bError)
                                WriteError(strMessage);
                            else
                                WriteDebug(strMessage);
                            if (log.LogFile != null)
                            {
                                strMessage = string.Format("\tLevel  : {0}", log.Level?.ToString());
                                if (bError)
                                    WriteError(strMessage);
                                else
                                    WriteDebug(strMessage);
                                if (log.IsDebugEnabled)
                                {
                                    strMessage = string.Format("\tDebug Level: {0}", log.LogLevel.ToString());
                                    if (bError)
                                        WriteError(strMessage);
                                    else
                                        WriteDebug(strMessage);
                                }
                            }
                        }
                        break;
                    case "System.Configuration.Configuration":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        break;
                    case "System.Data.SqlClient.SqlParameter":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        if (bIsArray)
                        {

                        }
                        else
                        {

                        }
                        break;
                    case "System.Data.SqlClient.SqlParameterCollection":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        break;
                    case "System.Security.Cryptography.X509Certificates.X509CertificateCollection":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        {
                            System.Security.Cryptography.X509Certificates.X509CertificateCollection vList = (System.Security.Cryptography.X509Certificates.X509CertificateCollection)pi.GetValue(_parameters, null);
                            foreach (var vItem in vList)
                            {
                                strMessage = string.Format("\tIssuer: {0}", vItem.Issuer);
                                if (bError)
                                    WriteError(strMessage);
                                else
                                    WriteDebug(strMessage);
                                strMessage = string.Format("\t\tExpires: {0}", vItem.GetExpirationDateString());
                                if (bError)
                                    WriteError(strMessage);
                                else
                                    WriteDebug(strMessage);
                                strMessage = string.Format("\t\tSerial#: {0}", vItem.GetSerialNumberString());
                                if (bError)
                                    WriteError(strMessage);
                                else
                                    WriteDebug(strMessage);
                                strMessage = string.Format("\t\tSubject: {0}", vItem.Subject);
                                if (bError)
                                    WriteError(strMessage);
                                else
                                    WriteDebug(strMessage);
                            }
                        }
                        break;
                    case "System.Diagnostics.Stopwatch":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        if (ApplicationSettings.Logger?.LogLevel >= 6)
                        {
                            Stopwatch sw = (Stopwatch)pi.GetValue(_parameters, null);
                            if (sw.IsRunning)
                            {
                                strMessage = string.Format("\tElapsed: {0}", sw.Elapsed.ToString());
                            }
                            else
                            {
                                strMessage = string.Format("\tElapsed: Not Running");
                            }
                            if (bError)
                                WriteError(strMessage);
                            else
                                WriteDebug(strMessage);
                        }
                        break;
                    case "System.Net.BufferAsyncResult":
                        strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                        if (bError)
                            WriteError(strMessage);
                        else
                            WriteDebug(strMessage);
                        //if (ApplicationSettings.Logger?.LogLevel >= 6)
                        //{
                        //    System.Net.BufferAsyncResult sw = (System.Net.BufferAsyncResult)pi.GetValue(_parameters, null);
                        //    if (sw.IsRunning)
                        //    {
                        //        strMessage = string.Format("\tElapsed: {0}", sw.Elapsed.ToString());
                        //    }
                        //    else
                        //    {
                        //        strMessage = string.Format("\tElapsed: Not Running");
                        //    }
                        //    if (bError)
                        //        WriteError(strMessage);
                        //    else
                        //        WriteDebug(strMessage);
                        //}
                        break;
                    default:
                        if (bIsArray)
                        {
                            strMessage = string.Format("\t({0}){1} ...", i < pars.Length ? strName : "???", pi.Name);
                            if (bError)
                                WriteError(strMessage);
                            else
                                WriteDebug(strMessage);
                            switch (strFullName)
                            {
                                case "System.String":
                                    {
                                        string[] vList = (string[])pi.GetValue(_parameters, null);
                                        foreach (string vItem in vList)
                                        {
                                            strMessage = string.Format("\t\t{0}", vItem);
                                            WriteToLog(strMessage, bError);
                                        }
                                    }
                                    break;
                                case "System.Int16":
                                case "System.Int32":
                                case "System.Int64":
                                case "System.IntPtr":
                                    {
                                        int[] vList = (int[])pi.GetValue(_parameters, null);
                                        foreach (int vItem in vList)
                                        {
                                            strMessage = string.Format("\t\t{0}", vItem.ToString());
                                            WriteToLog(strMessage, bError);
                                        }
                                    }
                                    break;
                                case "System.UInt16":
                                case "System.UInt32":
                                case "System.UInt64":
                                case "System.UIntPtr":
                                    {
                                        uint[] vList = (uint[])pi.GetValue(_parameters, null);
                                        foreach (uint vItem in vList)
                                        {
                                            strMessage = string.Format("\t\t{0}", vItem.ToString());
                                            WriteToLog(strMessage, bError);
                                        }
                                    }
                                    break;
                                case "System.Double":
                                case "System.Single":
                                    {
                                        Double[] vList = (Double[])pi.GetValue(_parameters, null);
                                        foreach (Double vItem in vList)
                                        {
                                            strMessage = string.Format("\t\t{0}", vItem.ToString());
                                            WriteToLog(strMessage, bError);
                                        }
                                    }
                                    break;
                                case "System.Boolean":
                                    {
                                        Boolean[] vList = (Boolean[])pi.GetValue(_parameters, null);
                                        foreach (Boolean vItem in vList)
                                        {
                                            strMessage = string.Format("\t\t{0}", vItem.ToString());
                                            WriteToLog(strMessage, bError);
                                        }
                                    }
                                    break;
                                case "System.Byte":
                                    {
                                        Byte[] vList = (Byte[])pi.GetValue(_parameters, null);
                                        foreach (Byte vItem in vList)
                                        {
                                            strMessage = string.Format("\t\t{0}", vItem.ToString());
                                            WriteToLog(strMessage, bError);
                                        }
                                    }
                                    break;
                                case "System.SByte":
                                    {
                                        SByte[] vList = (SByte[])pi.GetValue(_parameters, null);
                                        foreach (SByte vItem in vList)
                                        {
                                            strMessage = string.Format("\t\t{0}", vItem.ToString());
                                            WriteToLog(strMessage, bError);
                                        }
                                    }
                                    break;
                                case "System.Char":
                                    {
                                        Char[] vList = (Char[])pi.GetValue(_parameters, null);
                                        foreach (Char vItem in vList)
                                        {
                                            strMessage = string.Format("\t\t{0}", vItem.ToString());
                                            WriteToLog(strMessage, bError);
                                        }
                                    }
                                    break;
                                case "System.Decimal":
                                    {
                                        Decimal[] vList = (Decimal[])pi.GetValue(_parameters, null);
                                        foreach (Decimal vItem in vList)
                                        {
                                            strMessage = string.Format("\t\t{0}", vItem.ToString());
                                            WriteToLog(strMessage, bError);
                                        }
                                    }
                                    break;
                                case "System.DateTime":
                                    {
                                        DateTime[] vList = (DateTime[])pi.GetValue(_parameters, null);
                                        foreach (DateTime vItem in vList)
                                        {
                                            strMessage = string.Format("\t\t{0}", vItem.ToShortDateString() + " " + vItem.ToShortTimeString());
                                            WriteToLog(strMessage, bError);
                                        }
                                    }
                                    break;
                            }
                        }
                        else
                        {
                            strMessage = string.Format("\t({0}){1}: {2}", i < pars.Length ? strName : "???", pi.Name, pi.GetValue(_parameters, null));
                            WriteToLog(strMessage, bError);
                        }
                        break;
                }
                i++;
            }
        }
        private bool WriteToLog(string strMessage, bool bError)
        {
            if (bError)
            {
                WriteError(strMessage);
                return true;
            }
            else
            {
                if (DetailedLoggingDetected)
                {
                    WriteDebug(strMessage);
                    return true;
                }
                else
                {
                    WriteDebug(2, strMessage);
                    return (LoggingUtils.Logger?.LogLevel >= 2);
                }
            }
        }
        public void LogFunction(MethodBase _function, object _parameters, bool bError = false)
        {
            try
            {
                string strMessage = "";

                ParameterInfo[] pars = _function.GetParameters();
                strMessage = string.Format("[Func: {0}]", _function.DeclaringType.FullName + " (" + _function.MemberType.ToString() + ")");
                if (bError)
                    WriteError(strMessage);
                else
                    WriteDebug(strMessage);

                ProcessParameters(pars, _parameters, bError);
            }
            catch (Exception ex)
            {
                WriteError("Error in LogFuntion: ", ex);
            }
            finally
            {
                if (bError)
                    WriteError("[End Func]");
                else
                    WriteDebug("[End Func]");
            }
        }
        public void WriteLog(string strMessage, Exception ex = null)
        {
            LoggingUtils.WriteLogPrefix(LogPrefix, strMessage, ex);
        }
        public void WriteLogFormat(string format, params object[] args)
        {
            LoggingUtils.WriteDebugFormatPrefix(LogPrefix, format, args);
        }
        public void WriteDebug(string strMessage, Exception ex = null)
        {
            LoggingUtils.WriteDebugPrefix(LogPrefix, strMessage, ex);
        }
        public void WriteDebug(int DebugLevel, string strMessage, Exception ex = null)
        {
            LoggingUtils.WriteDebugPrefix(DebugLevel, LogPrefix, strMessage, ex);
        }
        public void WriteDebugFormat(string format, params object[] args)
        {
            LoggingUtils.WriteDebugFormatPrefix(LogPrefix, format, args);
        }
        public void WriteDebugFormat(int DebugLevel, string format, params object[] args)
        {
            LoggingUtils.WriteDebugFormatPrefix(DebugLevel, LogPrefix, format, args);
        }
        public void WriteDebugFormat(int DebugLevel, string strFunction, string format, params object[] args)
        {
            LoggingUtils.WriteDebugFormatPrefix(DebugLevel, LogPrefix, strFunction, format, args);
        }
        public void WriteWarn(string strMessage, Exception ex = null)
        {
            LoggingUtils.WriteWarnPrefix(LogPrefix, strMessage, ex);
        }
        public void WriteWarnFormat(string format, params object[] args)
        {
            LoggingUtils.WriteWarnFormat(format, args);
        }
        public void WriteError(string strMessage, Exception ex = null)
        {
            LoggingUtils.WriteErrorPrefix(LogPrefix, strMessage, ex);
        }
        public void WriteErrorFormat(string format, params object[] args)
        {
            LoggingUtils.WriteErrorFormat(format, args);
        }
        // public static void WriteErrorFormat(string format, params object[] args)
        public void Dispose()
        {
            if (m_sw == null)
            {
                if (m_bIsError)
                    WriteError("[End Func]");
                else
                    WriteDebug(2, "[End Func]");
            }
            else
            {
                if (ApplicationSettings.Logger?.LogLevel >= 2)
                {
                    SqlHelperStatic.ProcessStopWatchNoAutoLog(ref m_sw, "[End Func]", strLogPrefix: LogPrefix);
                }
                else
                {
                    if (m_bIsError)
                        WriteError("[End Func]");
                    else
                        WriteDebug(2, "[End Func]");
                }
            }
            m_sw?.Stop();
            if (ApplicationSettings.AutoLogActivity.TryRemove(CallPath, out int iCount))
            {

            }
        }
    }
}
