using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Threading.Tasks;
using AdvancedLogging.DAL.Interfaces;
using AdvancedLogging.Logging;
using static AdvancedLogging.Logging.LoggingUtils;

#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning disable CS8602 // Possible null reference return.
#pragma warning disable CS8603 // Possible null reference return.
namespace AdvancedLogging.DAL
{
    public static class HttpWebExtensions
    {
        //
        // WebClient
        //

        //public static byte[] DownloadData(this WebClient _webClient, string address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] DownloadData(this WebClient _webClient, Uri address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void DownloadDataAsync(this WebClient _webClient, Uri address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void DownloadDataAsync(this WebClient _webClient, Uri address, object userToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void DownloadFile(this WebClient _webClient, string address, string fileName, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void DownloadFile(this WebClient _webClient, Uri address, string fileName, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void DownloadFileAsync(this WebClient _webClient, Uri address, string fileName, object userToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void DownloadFileAsync(this WebClient _webClient, Uri address, string fileName, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        public static string DownloadString(this WebClient _webClient, string address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0)
        {
            return DownloadString((IWebClient)_webClient, address, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement);
        }

        public static string DownloadString(this IWebClient _webClient, string address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { _webClient, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }))
            {
                try
                {
                    string wr = "";
                    bool bSuccess = true;
                    // Add 1 so that we process the original request + the _Retries
                    for (int i = 0; i < (_Retries + 1); i++)
                    {
                        Stopwatch sw = null;
                        int iIncreaseValueForTimeout = 0;
                        try
                        {
                            sw = new Stopwatch();
                            sw?.Start();
                            wr = _webClient.DownloadString(address);
                            sw?.Stop();
                            if (sw != null)
                            {
                                LoggingUtils.ProcessStopWatch(ref sw, vAutoLogFunction, address, LoggingUtils.DebugPrintLevel[CLog.Log_FunctionHeaderMethod]);
                            }
                            if (!bSuccess)
                            {
                                vAutoLogFunction.WriteLog("WebClient.DownloadString: Retry is Successful!");
                            }
                            return wr;
                        }
                        catch (WebException ex)
                        {
                            if (i == (_Retries - 1))
                            {
                                vAutoLogFunction.LogFunction(new { _webClient, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ex);
                                throw;
                            }
                            if (bSuccess)
                            {
                                bSuccess = false;
                                vAutoLogFunction.WriteLog("WebClient.DownloadString: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ...", ex);
                            }
                            else
                                vAutoLogFunction.WriteLog("WebClient.DownloadString: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ... (Error: " + ex.Message + ")");
                            if (ex.Status == WebExceptionStatus.Timeout)
                            {
                                iIncreaseValueForTimeout = _iAutoTimeoutIncrement;
                            }
                        }
                        catch (Exception ex)
                        {
                            if (i == (_Retries - 1))
                            {
                                vAutoLogFunction.LogFunction(new { _webClient, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ex);
                                throw;
                            }
                            if (bSuccess)
                            {
                                bSuccess = false;
                                vAutoLogFunction.WriteLog("WebClient.DownloadString: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ...", ex);
                            }
                            else
                                vAutoLogFunction.WriteLog("WebClient.DownloadString: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ... (Error: " + ex.Message + ")");
                        }
                        if (_RetryWaitMS > 250)
                        {
                            DateTime dt = DateTime.Now.AddMilliseconds(_RetryWaitMS);
                            vAutoLogFunction.WriteLog("WebClient.DownloadString: Waiting " + (_RetryWaitMS / 1000).ToString() + " seconds before retrying...");
                            while (dt > DateTime.Now && ApplicationSettings.IsRunning)
                            {
                                System.Threading.Thread.Sleep(250);
                            }
                        }
                        else
                            System.Threading.Thread.Sleep(_RetryWaitMS);
                    }
                    return wr;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { _webClient, address, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        //public static string DownloadString(this WebClient _webClient, Uri address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void DownloadStringAsync(this WebClient _webClient, Uri address, object userToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void DownloadStringAsync(this WebClient _webClient, Uri address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Stream OpenRead(this WebClient _webClient, string address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Stream OpenRead(this WebClient _webClient, Uri address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void OpenReadAsync(this WebClient _webClient, Uri address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void OpenReadAsync(this WebClient _webClient, Uri address, object userToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Stream OpenWrite(this WebClient _webClient, string address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Stream OpenWrite(this WebClient _webClient, string address, string method, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Stream OpenWrite(this WebClient _webClient, Uri address, string method, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Stream OpenWrite(this WebClient _webClient, Uri address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void OpenWriteAsync(this WebClient _webClient, Uri address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void OpenWriteAsync(this WebClient _webClient, Uri address, string method, object userToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void OpenWriteAsync(this WebClient _webClient, Uri address, string method, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] UploadData(this WebClient _webClient, string address, byte[] data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] UploadData(this WebClient _webClient, string address, string method, byte[] data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] UploadData(this WebClient _webClient, Uri address, string method, byte[] data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] UploadData(this WebClient _webClient, Uri address, byte[] data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void UploadDataAsync(this WebClient _webClient, Uri address, string method, byte[] data, object userToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void UploadDataAsync(this WebClient _webClient, Uri address, byte[] data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void UploadDataAsync(this WebClient _webClient, Uri address, string method, byte[] data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] UploadFile(this WebClient _webClient, string address, string method, string fileName, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] UploadFile(this WebClient _webClient, Uri address, string method, string fileName, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] UploadFile(this WebClient _webClient, Uri address, string fileName, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] UploadFile(this WebClient _webClient, string address, string fileName, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void UploadFileAsync(this WebClient _webClient, Uri address, string fileName, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void UploadFileAsync(this WebClient _webClient, Uri address, string method, string fileName, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void UploadFileAsync(this WebClient _webClient, Uri address, string method, string fileName, object userToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static string UploadString(this WebClient _webClient, Uri address, string method, string data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static string UploadString(this WebClient _webClient, string address, string method, string data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static string UploadString(this WebClient _webClient, string address, string data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static string UploadString(this WebClient _webClient, Uri address, string data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void UploadStringAsync(this WebClient _webClient, Uri address, string method, string data, object userToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void UploadStringAsync(this WebClient _webClient, Uri address, string method, string data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void UploadStringAsync(this WebClient _webClient, Uri address, string data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] UploadValues(this WebClient _webClient, string address, string method, NameValueCollection data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] UploadValues(this WebClient _webClient, Uri address, NameValueCollection data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] UploadValues(this WebClient _webClient, Uri address, string method, NameValueCollection data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static byte[] UploadValues(this WebClient _webClient, string address, NameValueCollection data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void UploadValuesAsync(this WebClient _webClient, Uri address, string method, NameValueCollection data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void UploadValuesAsync(this WebClient _webClient, Uri address, NameValueCollection data, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static void UploadValuesAsync(this WebClient _webClient, Uri address, string method, NameValueCollection data, object userToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static WebRequest GetWebRequest(this WebClient _webClient, Uri address, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static WebResponse GetWebResponse(this WebClient _webClient, WebRequest request, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static WebResponse GetWebResponse(this WebClient _webClient, WebRequest request, IAsyncResult result, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);

        //
        // System.Web.HttpApplicationState
        //
#if !__IOS__
        public static object Get(this System.Web.HttpApplicationState _httpAppState, int index, object defaultvalue)
        {
            try
            {
                if (_httpAppState.Get(index) is null)
                    return defaultvalue;
                else
                    return _httpAppState.Get(index);
            }
            catch
            {
                return defaultvalue;
            }
        }
        public static object Get(this System.Web.HttpApplicationState _httpAppState, string name, object defaultvalue)
        {
            try
            {
                if (_httpAppState.Get(name) is null)
                    return defaultvalue;
                else
                    return _httpAppState.Get(name);
            }
            catch
            {
                return defaultvalue;
            }
        }
#endif
        //
        // WebRequest
        //

        //public static IAsyncResult BeginGetRequestStream(this WebRequest _WebRequest, AsyncCallback callback, object state, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static IAsyncResult BeginGetResponse(this WebRequest _WebRequest, AsyncCallback callback, object state, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Stream EndGetRequestStream(this WebRequest _WebRequest, IAsyncResult asyncResult, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static WebResponse EndGetResponse(this WebRequest _WebRequest, IAsyncResult asyncResult, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Stream GetRequestStream(this WebRequest _WebRequest, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        public static WebResponse GetResponse(this WebRequest _WebRequest, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }))
            {
                try
                {
                    WebResponse wr = null;
                    bool bSuccess = true;
                    // Add 1 so that we process the original request + the _Retries
                    for (int i = 0; i < (_Retries + 1); i++)
                    {
                        Stopwatch sw = null;
                        int iIncreaseValueForTimeout = 0;
                        try
                        {
                            sw = new Stopwatch();
                            sw?.Start();
                            wr = _WebRequest.GetResponse();
                            sw?.Stop();
                            if (sw != null)
                            {
                                LoggingUtils.ProcessStopWatch(ref sw, vAutoLogFunction, _WebRequest.RequestUri.ToString(), LoggingUtils.DebugPrintLevel[CLog.Log_FunctionHeaderMethod]);
                            }
                            if (!bSuccess)
                            {
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retry is Successful!");
                            }
                            return wr;
                        }
                        catch (WebException ex)
                        {
                            if (i == (_Retries - 1))
                            {
                                vAutoLogFunction.LogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ex);
                                throw;
                            }
                            if (bSuccess)
                            {
                                bSuccess = false;
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ...", ex);
                            }
                            else
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ... (Error: " + ex.Message + ")");
                            if (ex.Status == WebExceptionStatus.Timeout)
                            {
                                iIncreaseValueForTimeout = _iAutoTimeoutIncrement;
                            }
                        }
                        catch (Exception ex)
                        {
                            if (i == (_Retries - 1))
                            {
                                vAutoLogFunction.LogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ex);
                                throw;
                            }
                            if (bSuccess)
                            {
                                bSuccess = false;
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ...", ex);
                            }
                            else
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ... (Error: " + ex.Message + ")");
                        }
                        if (_RetryWaitMS > 250)
                        {
                            DateTime dt = DateTime.Now.AddMilliseconds(_RetryWaitMS);
                            vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Waiting " + (_RetryWaitMS / 1000).ToString() + " seconds before retrying...");
                            while (dt > DateTime.Now && ApplicationSettings.IsRunning)
                            {
                                System.Threading.Thread.Sleep(250);
                            }
                        }
                        else
                            System.Threading.Thread.Sleep(_RetryWaitMS);

                        HttpWebRequest _request = WebRequest.Create(_WebRequest.RequestUri) as HttpWebRequest;
                        var propInfo = _WebRequest.GetType().GetProperties();
                        foreach (var item in propInfo)
                        {
                            if (!item.CanWrite)
                                continue;
                            try
                            {
                                if (item.CanWrite && item.CanRead)
                                {
                                    try
                                    {
                                        vAutoLogFunction.WriteDebugFormat(LoggingUtils.DebugPrintLevel[CLog.Log_FunctionHeaderMethod] + 2, "Copying Property [{0}] ...", item.Name);
                                        switch (item.Name)
                                        {
                                            case "Headers":
                                                if (_WebRequest.Headers != null)
                                                {
                                                    foreach (var oHeader in _WebRequest.Headers)
                                                    {
                                                        switch ((string)oHeader)
                                                        {
                                                            case "Content-Type":
                                                                // Set with a Property
                                                                break;
                                                            default:
                                                                vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "].[" + (string)oHeader + "] = " + _WebRequest.Headers[(string)oHeader] + " ...");
                                                                _request.Headers.Add((string)oHeader, _WebRequest.Headers[(string)oHeader]);
                                                                break;
                                                        }
                                                    }
                                                }
                                                break;
                                            case "CookieContainer":
                                                break;
                                            case "ContentLength":
                                                if (item.GetValue(_WebRequest, null) is int iTimeout)
                                                {
                                                    if (iTimeout > 0)
                                                    {
                                                        vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "] = " + iTimeout + " ...");
                                                        _request.GetType().GetProperty(item.Name).SetValue(_request, iTimeout, null);
                                                    }
                                                }
                                                break;
                                            case "Connection":
                                                if (!string.IsNullOrEmpty((string)item.GetValue(_WebRequest, null)))
                                                {
                                                    string strValue = ((string)item.GetValue(_WebRequest, null)).ToLower();
                                                    // "Keep-Alive" and "Close"
                                                    if (!(strValue == "Keep-Alive".ToLower() || strValue == "Close".ToLower()))
                                                    {
                                                        vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "] = " + item.GetValue(_WebRequest, null) + " ...");
                                                        _request.GetType().GetProperty(item.Name).SetValue(_request, item.GetValue(_WebRequest, null), null);
                                                    }
                                                }
                                                break;
                                            default:
                                                vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "] = " + item.GetValue(_WebRequest, null) + " ...");
                                                _request.GetType().GetProperty(item.Name).SetValue(_request, item.GetValue(_WebRequest, null), null);
                                                break;
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        vAutoLogFunction.WriteErrorFormat("Error Copying Property [{0}] ... [{1}].", item.Name, ex.Message);
                                    }
                                }
                            }
                            catch (Exception ex2)
                            {
                                vAutoLogFunction.WriteError("Setting HttpWebRequest Property [" + item.Name + "] = " + item.GetValue(_WebRequest, null) + " ...", ex2);
                            }
                        }
                        // Set the new Timeout AFTER we copy the Properties
                        _request.Timeout = _WebRequest.Timeout + iIncreaseValueForTimeout;
                        _WebRequest = null;
                        _WebRequest = _request;
                    }
                    return wr;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        public static async Task<WebResponse> GetResponseAsync(this WebRequest _WebRequest, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }))
            {
                try
                {
                    WebResponse wr = null;
                    bool bSuccess = true;
                    // Add 1 so that we process the original request + the _Retries
                    for (int i = 0; i < (_Retries + 1); i++)
                    {
                        Stopwatch sw = null;
                        int iIncreaseValueForTimeout = 0;
                        try
                        {
                            sw = new Stopwatch();
                            sw?.Start();
                            wr = await _WebRequest.GetResponseAsync();
                            sw?.Stop();
                            if (sw != null)
                            {
                                LoggingUtils.ProcessStopWatch(ref sw, vAutoLogFunction, _WebRequest.RequestUri.ToString(), LoggingUtils.DebugPrintLevel[CLog.Log_FunctionHeaderMethod]);
                            }
                            if (!bSuccess)
                            {
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponseAsync: Retry is Successful!");
                            }
                            return wr;
                        }
                        catch (WebException ex)
                        {
                            if (i == (_Retries - 1))
                            {
                                vAutoLogFunction.LogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ex);
                                throw;
                            }
                            if (bSuccess)
                            {
                                bSuccess = false;
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponseAsync: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ...", ex);
                            }
                            else
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponseAsync: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ... (Error: " + ex.Message + ")");
                            if (ex.Status == WebExceptionStatus.Timeout)
                            {
                                iIncreaseValueForTimeout = _iAutoTimeoutIncrement;
                            }
                        }
                        catch (Exception ex)
                        {
                            if (i == (_Retries - 1))
                            {
                                vAutoLogFunction.LogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ex);
                                throw;
                            }
                            if (bSuccess)
                            {
                                bSuccess = false;
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponseAsync: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ...", ex);
                            }
                            else
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponseAsync: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ... (Error: " + ex.Message + ")");
                        }
                        if (_RetryWaitMS > 250)
                        {
                            DateTime dt = DateTime.Now.AddMilliseconds(_RetryWaitMS);
                            vAutoLogFunction.WriteLog("HttpWebRequest.GetResponseAsync: Waiting " + (_RetryWaitMS / 1000).ToString() + " seconds before retrying...");
                            while (dt > DateTime.Now && ApplicationSettings.IsRunning)
                            {
                                System.Threading.Thread.Sleep(250);
                            }
                        }
                        else
                            System.Threading.Thread.Sleep(_RetryWaitMS);

                        HttpWebRequest _request = WebRequest.Create(_WebRequest.RequestUri) as HttpWebRequest;
                        var propInfo = _WebRequest.GetType().GetProperties();
                        foreach (var item in propInfo)
                        {
                            if (!item.CanWrite)
                                continue;
                            try
                            {
                                if (item.CanWrite && item.CanRead)
                                {
                                    try
                                    {
                                        vAutoLogFunction.WriteDebugFormat(LoggingUtils.DebugPrintLevel[CLog.Log_FunctionHeaderMethod] + 2, "Copying Property [{0}] ...", item.Name);
                                        switch (item.Name)
                                        {
                                            case "Headers":
                                                if (_WebRequest.Headers != null)
                                                {
                                                    foreach (var oHeader in _WebRequest.Headers)
                                                    {
                                                        switch ((string)oHeader)
                                                        {
                                                            case "Content-Type":
                                                                // Set with a Property
                                                                break;
                                                            default:
                                                                vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "].[" + (string)oHeader + "] = " + _WebRequest.Headers[(string)oHeader] + " ...");
                                                                _request.Headers.Add((string)oHeader, _WebRequest.Headers[(string)oHeader]);
                                                                break;
                                                        }
                                                    }
                                                }
                                                break;
                                            case "CookieContainer":
                                                break;
                                            case "ContentLength":
                                                if (item.GetValue(_WebRequest, null) is int iTimeout)
                                                {
                                                    if (iTimeout > 0)
                                                    {
                                                        vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "] = " + iTimeout + " ...");
                                                        _request.GetType().GetProperty(item.Name).SetValue(_request, iTimeout, null);
                                                    }
                                                }
                                                break;
                                            case "Connection":
                                                if (!string.IsNullOrEmpty((string)item.GetValue(_WebRequest, null)))
                                                {
                                                    string strValue = ((string)item.GetValue(_WebRequest, null)).ToLower();
                                                    // "Keep-Alive" and "Close"
                                                    if (!(strValue == "Keep-Alive".ToLower() || strValue == "Close".ToLower()))
                                                    {
                                                        vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "] = " + item.GetValue(_WebRequest, null) + " ...");
                                                        _request.GetType().GetProperty(item.Name).SetValue(_request, item.GetValue(_WebRequest, null), null);
                                                    }
                                                }
                                                break;
                                            default:
                                                vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "] = " + item.GetValue(_WebRequest, null) + " ...");
                                                _request.GetType().GetProperty(item.Name).SetValue(_request, item.GetValue(_WebRequest, null), null);
                                                break;
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        vAutoLogFunction.WriteErrorFormat("Error Copying Property [{0}] ... [{1}].", item.Name, ex.Message);
                                    }
                                }
                            }
                            catch (Exception ex2)
                            {
                                vAutoLogFunction.WriteError("Setting HttpWebRequest Property [" + item.Name + "] = " + item.GetValue(_WebRequest, null) + " ...", ex2);
                            }
                        }
                        // Set the new Timeout AFTER we copy the Properties
                        _request.Timeout = _WebRequest.Timeout + iIncreaseValueForTimeout;
                        _WebRequest = null;
                        _WebRequest = _request;
                    }
                    return wr;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        public static WebResponse GetResponse(this HttpWebRequest _WebRequest, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }))
            {
                try
                {
                    WebResponse wr = null;
                    bool bSuccess = true;
                    // Add 1 so that we process the original request + the _Retries
                    for (int i = 0; i < (_Retries + 1); i++)
                    {
                        Stopwatch sw = null;
                        int iIncreaseValueForTimeout = 0;
                        try
                        {
                            sw = new Stopwatch();
                            sw?.Start();
                            wr = _WebRequest.GetResponse();
                            sw?.Stop();
                            if (sw != null)
                            {
                                LoggingUtils.ProcessStopWatch(ref sw, vAutoLogFunction, _WebRequest.RequestUri.ToString(), LoggingUtils.DebugPrintLevel[CLog.Log_FunctionHeaderMethod]);
                            }
                            if (!bSuccess)
                            {
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retry is Successful!");
                            }
                            return wr;
                        }
                        catch (WebException ex)
                        {
                            if (i == (_Retries - 1))
                            {
                                vAutoLogFunction.LogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ex);
                                throw;
                            }
                            if (bSuccess)
                            {
                                bSuccess = false;
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ...", ex);
                            }
                            else
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ... (Error: " + ex.Message + ")");
                            if (ex.Status == WebExceptionStatus.Timeout)
                            {
                                iIncreaseValueForTimeout = _iAutoTimeoutIncrement;
                            }
                        }
                        catch (Exception ex)
                        {
                            if (i == (_Retries - 1))
                            {
                                vAutoLogFunction.LogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ex);
                                throw;
                            }
                            if (bSuccess)
                            {
                                bSuccess = false;
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ...", ex);
                            }
                            else
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ... (Error: " + ex.Message + ")");
                        }
                        if (_RetryWaitMS > 250)
                        {
                            DateTime dt = DateTime.Now.AddMilliseconds(_RetryWaitMS);
                            vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Waiting " + (_RetryWaitMS / 1000).ToString() + " seconds before retrying...");
                            while (dt > DateTime.Now && ApplicationSettings.IsRunning)
                            {
                                System.Threading.Thread.Sleep(250);
                            }
                        }
                        else
                            System.Threading.Thread.Sleep(_RetryWaitMS);

                        HttpWebRequest _request = WebRequest.Create(_WebRequest.RequestUri) as HttpWebRequest;
                        var propInfo = _WebRequest.GetType().GetProperties();
                        foreach (var item in propInfo)
                        {
                            if (!item.CanWrite)
                                continue;
                            try
                            {
                                if (item.CanWrite && item.CanRead)
                                {
                                    try
                                    {
                                        vAutoLogFunction.WriteDebugFormat(LoggingUtils.DebugPrintLevel[CLog.Log_FunctionHeaderMethod] + 2, "Copying Property [{0}] ...", item.Name);
                                        switch (item.Name)
                                        {
                                            case "Headers":
                                                if (_WebRequest.Headers != null)
                                                {
                                                    foreach (var oHeader in _WebRequest.Headers)
                                                    {
                                                        switch ((string)oHeader)
                                                        {
                                                            case "Content-Type":
                                                                // Set with a Property
                                                                break;
                                                            default:
                                                                vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "].[" + (string)oHeader + "] = " + _WebRequest.Headers[(string)oHeader] + " ...");
                                                                _request.Headers.Add((string)oHeader, _WebRequest.Headers[(string)oHeader]);
                                                                break;
                                                        }
                                                    }
                                                }
                                                break;
                                            case "ClientCertificates":
                                                if (_WebRequest.ClientCertificates != null)
                                                {
                                                    foreach (var oCerts in _WebRequest.ClientCertificates)
                                                    {
                                                        vAutoLogFunction.WriteDebug("Setting ClientCertificates Property [" + item.Name + "].[" + oCerts.Subject + "] = " + oCerts.Issuer + " ...");
                                                        _request.ClientCertificates.Add(oCerts);
                                                    }
                                                }
                                                break;
                                            case "CookieContainer":
                                                break;
                                            case "ContentLength":
                                                if (item.GetValue(_WebRequest, null) is int iTimeout)
                                                {
                                                    if (iTimeout > 0)
                                                    {
                                                        vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "] = " + iTimeout + " ...");
                                                        _request.GetType().GetProperty(item.Name).SetValue(_request, iTimeout, null);
                                                    }
                                                }
                                                break;
                                            case "Connection":
                                                if (!string.IsNullOrEmpty((string)item.GetValue(_WebRequest, null)))
                                                {
                                                    string strValue = ((string)item.GetValue(_WebRequest, null)).ToLower();
                                                    // "Keep-Alive" and "Close"
                                                    if (!(strValue == "Keep-Alive".ToLower() || strValue == "Close".ToLower()))
                                                    {
                                                        vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "] = " + item.GetValue(_WebRequest, null) + " ...");
                                                        _request.GetType().GetProperty(item.Name).SetValue(_request, item.GetValue(_WebRequest, null), null);
                                                    }
                                                }
                                                break;
                                            default:
                                                vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "] = " + item.GetValue(_WebRequest, null) + " ...");
                                                _request.GetType().GetProperty(item.Name).SetValue(_request, item.GetValue(_WebRequest, null), null);
                                                break;
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        vAutoLogFunction.WriteErrorFormat("Error Copying Property [{0}] ... [{1}].", item.Name, ex.Message);
                                    }
                                }
                            }
                            catch (Exception ex2)
                            {
                                vAutoLogFunction.WriteError("Setting HttpWebRequest Property [" + item.Name + "] = " + item.GetValue(_WebRequest, null) + " ...", ex2);
                            }
                        }
                        // Set the new Timeout AFTER we copy the Properties
                        _request.Timeout = _WebRequest.Timeout + iIncreaseValueForTimeout;
                        _WebRequest = null;
                        _WebRequest = _request;
                    }
                    return wr;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        public static async Task<WebResponse> GetResponseAsync(this HttpWebRequest _WebRequest, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }))
            {
                try
                {
                    WebResponse wr = null;
                    bool bSuccess = true;
                    // Add 1 so that we process the original request + the _Retries
                    for (int i = 0; i < (_Retries + 1); i++)
                    {
                        Stopwatch sw = null;
                        int iIncreaseValueForTimeout = 0;
                        try
                        {
                            sw = new Stopwatch();
                            sw?.Start();
                            wr = await _WebRequest.GetResponseAsync();
                            sw?.Stop();
                            if (sw != null)
                            {
                                LoggingUtils.ProcessStopWatch(ref sw, vAutoLogFunction, _WebRequest.RequestUri.ToString(), LoggingUtils.DebugPrintLevel[CLog.Log_FunctionHeaderMethod]);
                            }
                            if (!bSuccess)
                            {
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponseAsync: Retry is Successful!");
                            }
                            return wr;
                        }
                        catch (WebException ex)
                        {
                            if (i == (_Retries - 1))
                            {
                                vAutoLogFunction.LogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ex);
                                throw;
                            }
                            if (bSuccess)
                            {
                                bSuccess = false;
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponseAsync: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ...", ex);
                            }
                            else
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponseAsync: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ... (Error: " + ex.Message + ")");
                            if (ex.Status == WebExceptionStatus.Timeout)
                            {
                                iIncreaseValueForTimeout = _iAutoTimeoutIncrement;
                            }
                        }
                        catch (Exception ex)
                        {
                            if (i == (_Retries - 1))
                            {
                                vAutoLogFunction.LogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ex);
                                throw;
                            }
                            if (bSuccess)
                            {
                                bSuccess = false;
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponseAsync: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ...", ex);
                            }
                            else
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponseAsync: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ... (Error: " + ex.Message + ")");
                        }
                        if (_RetryWaitMS > 250)
                        {
                            DateTime dt = DateTime.Now.AddMilliseconds(_RetryWaitMS);
                            vAutoLogFunction.WriteLog("HttpWebRequest.GetResponseAsync: Waiting " + (_RetryWaitMS / 1000).ToString() + " seconds before retrying...");
                            while (dt > DateTime.Now && ApplicationSettings.IsRunning)
                            {
                                System.Threading.Thread.Sleep(250);
                            }
                        }
                        else
                            System.Threading.Thread.Sleep(_RetryWaitMS);

                        HttpWebRequest _request = WebRequest.Create(_WebRequest.RequestUri) as HttpWebRequest;
                        var propInfo = _WebRequest.GetType().GetProperties();
                        foreach (var item in propInfo)
                        {
                            if (!item.CanWrite)
                                continue;
                            try
                            {
                                if (item.CanWrite && item.CanRead)
                                {
                                    try
                                    {
                                        vAutoLogFunction.WriteDebugFormat(LoggingUtils.DebugPrintLevel[CLog.Log_FunctionHeaderMethod] + 2, "Copying Property [{0}] ...", item.Name);
                                        switch (item.Name)
                                        {
                                            case "Headers":
                                                if (_WebRequest.Headers != null)
                                                {
                                                    foreach (var oHeader in _WebRequest.Headers)
                                                    {
                                                        switch ((string)oHeader)
                                                        {
                                                            case "Content-Type":
                                                                // Set with a Property
                                                                break;
                                                            default:
                                                                vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "].[" + (string)oHeader + "] = " + _WebRequest.Headers[(string)oHeader] + " ...");
                                                                _request.Headers.Add((string)oHeader, _WebRequest.Headers[(string)oHeader]);
                                                                break;
                                                        }
                                                    }
                                                }
                                                break;
                                            case "ClientCertificates":
                                                if (_WebRequest.ClientCertificates != null)
                                                {
                                                    foreach (var oCerts in _WebRequest.ClientCertificates)
                                                    {
                                                        vAutoLogFunction.WriteDebug("Setting ClientCertificates Property [" + item.Name + "].[" + oCerts.Subject + "] = " + oCerts.Issuer + " ...");
                                                        _request.ClientCertificates.Add(oCerts);
                                                    }
                                                }
                                                break;
                                            case "CookieContainer":
                                                break;
                                            case "ContentLength":
                                                if (item.GetValue(_WebRequest, null) is int iTimeout)
                                                {
                                                    if (iTimeout > 0)
                                                    {
                                                        vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "] = " + iTimeout + " ...");
                                                        _request.GetType().GetProperty(item.Name).SetValue(_request, iTimeout, null);
                                                    }
                                                }
                                                break;
                                            case "Connection":
                                                if (!string.IsNullOrEmpty((string)item.GetValue(_WebRequest, null)))
                                                {
                                                    string strValue = ((string)item.GetValue(_WebRequest, null)).ToLower();
                                                    // "Keep-Alive" and "Close"
                                                    if (!(strValue == "Keep-Alive".ToLower() || strValue == "Close".ToLower()))
                                                    {
                                                        vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "] = " + item.GetValue(_WebRequest, null) + " ...");
                                                        _request.GetType().GetProperty(item.Name).SetValue(_request, item.GetValue(_WebRequest, null), null);
                                                    }
                                                }
                                                break;
                                            default:
                                                vAutoLogFunction.WriteDebug("Setting HttpWebRequest Property [" + item.Name + "] = " + item.GetValue(_WebRequest, null) + " ...");
                                                _request.GetType().GetProperty(item.Name).SetValue(_request, item.GetValue(_WebRequest, null), null);
                                                break;
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        vAutoLogFunction.WriteErrorFormat("Error Copying Property [{0}] ... [{1}].", item.Name, ex.Message);
                                    }
                                }
                            }
                            catch (Exception ex2)
                            {
                                vAutoLogFunction.WriteError("Setting HttpWebRequest Property [" + item.Name + "] = " + item.GetValue(_WebRequest, null) + " ...", ex2);
                            }
                        }
                        // Set the new Timeout AFTER we copy the Properties
                        _request.Timeout = _WebRequest.Timeout + iIncreaseValueForTimeout;
                        _WebRequest = null;
                        _WebRequest = _request;
                    }
                    return wr;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { _WebRequest, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        public static KeyValuePair<string, string>[] GetHeaders(this WebHeaderCollection webHeaderCollection)
        {
            string[] keys = webHeaderCollection.AllKeys;
            var keyVals = new KeyValuePair<string, string>[keys.Length];
            for (int i = 0; i < keys.Length; i++)
                keyVals[i] = new KeyValuePair<string, string>(keys[i], webHeaderCollection[keys[i]]);
            return keyVals;
        }
        private static string Serialize(this WebHeaderCollection webHeaderCollection)
        {
            var response = new System.Text.StringBuilder();
            foreach (string k in webHeaderCollection.Keys)
                response.AppendLine(k + ": " + webHeaderCollection[k]);
            return response.ToString();
        }
        public static void Dump(this HttpWebRequest _httpRequest, int iDebugLevel, string strLogPrefix, bool bError = false)
        {
            if (bError)
                DumpError(_httpRequest, iDebugLevel, strLogPrefix);
            else
                DumpDebug(_httpRequest, iDebugLevel, strLogPrefix);
        }
        public static void DumpError(this HttpWebRequest _httpRequest, int iDebugLevel, string strLogPrefix)
        {
            string strMessage = "";
            if (_httpRequest == null)
            {
                strMessage = string.Format("\t{0}", "(NULL)");
            }
            else
            {
                strMessage = string.Format("Address: {0}", _httpRequest.Address);
                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                strMessage = string.Format("Timeout: {0}", _httpRequest.Timeout.ToString());
                WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                if (_httpRequest.Credentials != null)
                {
                    System.Net.NetworkCredential nc = _httpRequest.Credentials?.GetCredential(_httpRequest.RequestUri, "");
                    if (nc == null)
                    {
                        strMessage = "Credentials: None";
                        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                    }
                    else
                    {
                        if (nc.Domain == "" && nc.UserName == "")
                            strMessage = "Credentials: None";
                        else
                            strMessage = string.Format("Credentials: {0}{1}", nc.Domain == "" ? "" : nc.Domain + "\\", nc.UserName);
                        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                    }
                }
                if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_DumpComplexParameterValues])
                {
                    try
                    {
                        strMessage = string.Format("Object Data  : {0}", ObjectDumper.Dump(_httpRequest));
                        WriteErrorPrefixNoAutoLog(strLogPrefix, strMessage);
                    }
                    catch (Exception ex)
                    {
                        WriteErrorPrefixNoAutoLog(strLogPrefix, "Error 'Dumping' object of type [System.Net.HttpWebRequest].", ex);
                    }
                }
            }
        }
        public static void DumpDebug(this HttpWebRequest _httpRequest, int iDebugLevel, string strLogPrefix)
        {
            string strMessage = "";
            if (_httpRequest == null)
            {
                strMessage = string.Format("\t{0}", "(NULL)");
            }
            else
            {
                strMessage = string.Format("Address: {0}", _httpRequest.Address);
                WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                strMessage = string.Format("Timeout: {0}", _httpRequest.Timeout.ToString());
                WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                if (_httpRequest.Credentials != null)
                {
                    System.Net.NetworkCredential nc = _httpRequest.Credentials?.GetCredential(_httpRequest.RequestUri, "");
                    if (nc == null)
                    {
                        strMessage = "Credentials: None";
                        WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                    }
                    else
                    {
                        if (nc.Domain == "" && nc.UserName == "")
                            strMessage = "Credentials: None";
                        else
                            strMessage = string.Format("Credentials: {0}{1}", nc.Domain == "" ? "" : nc.Domain + "\\", nc.UserName);
                        WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                    }
                }
                if (ApplicationSettings.Logger?.LogLevel >= DebugPrintLevel[CLog.Log_DumpComplexParameterValues])
                {
                    try
                    {
                        strMessage = string.Format("Object Data  : {0}", ObjectDumper.Dump(_httpRequest));
                        WriteDebugPrefixNoAutoLog(iDebugLevel, strLogPrefix, strMessage);
                    }
                    catch (Exception ex)
                    {
                        WriteErrorPrefixNoAutoLog(strLogPrefix, "Error 'Dumping' object of type [System.Net.HttpWebRequest].", ex);
                    }
                }
            }
        }
    }
}
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning restore CS8602 // Possible null reference return.
#pragma warning restore CS8603 // Possible null reference return.
