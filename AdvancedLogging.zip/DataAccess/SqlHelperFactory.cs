﻿namespace MHS.HelperLibrary.DAL
{
    public class SqlHelperFactory
    {
        private static ISqlHelper helper = null;

        public static ISqlHelper UseHelper
        {
            get
            {
                if (helper == null)
                {
                    return new SqlHelper();
                }
                else
                {
                    return helper;
                }
            }
            set
            {
                helper = value;
            }
        }


    }
}
