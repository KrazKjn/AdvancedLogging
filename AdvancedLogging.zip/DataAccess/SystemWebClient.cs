using System;
using System.Net;
using AdvancedLogging.DAL.Interfaces;
using AdvancedLogging.Logging;

namespace AdvancedLogging.DAL
{
    // <summary>
    /// System web client.
    /// </summary>
    public class SystemWebClient : WebClient, IWebClient
    {

    }

    /// <summary>
    /// System web client factory.
    /// </summary>
    public class SystemWebClientFactory : IWebClientFactory
    {
        #region IWebClientFactory implementation

        public IWebClient Create()
        {
            using (var vAutoLogFunction = new AutoLogFunction(System.Reflection.MethodBase.GetCurrentMethod()))
            {
                try
                {
                    return new SystemWebClient();
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        #endregion
    }
}
