using System;
using System.Collections.Generic;

using Newtonsoft.Json.Linq;
using AdvancedLogging.DAL.Interfaces;
using AdvancedLogging.Logging;

[assembly: CLSCompliant(true)]
namespace AdvancedLogging.DAL
{
    /// <summary>
    /// Class to implement default factory for a Configuration Server
    /// </summary>
    public class ConfigurationFactory : IConfigurationServerFactory
    {
        /// <summary>
        /// Create a new instance of a configuration server for the specfied URL
        /// </summary>
        /// <param name="url">The URL of the configuration server.</param>
        /// <returns>An instance of a configuration server for the specfied URL.</returns>
        public IConfigurationServer Create(string url)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { url }))
            {
                try
                {
                    return new Configuration(url, new SystemWebClientFactory());
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { url }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
    }

    /// <summary>
    /// Standard class to talk to a Configuration Server.
    /// </summary>
    public class Configuration : IConfigurationServer
    {
        protected IWebClient client;
        protected Dictionary<string, BE.ConfigurationParameter> receivedConfiguration;

        /// <summary>
        /// Create a Configuration that talks to the Configuration Server at the specified URL.
        /// </summary>
        /// <param name="serverBaseUrl">The base URL of the configuration server.</param>
        public Configuration(string serverBaseUrl, IWebClientFactory webClientFactory)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { serverBaseUrl, webClientFactory }))
            {
                try
                {
                    client = webClientFactory.Create();

                    client.BaseAddress = serverBaseUrl;
                    client.Headers.Add("Accept", "application/json");
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { serverBaseUrl, webClientFactory }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }

        /// <summary>
        /// Get the configuration for the specified application for the specified client.
        /// </summary>
        /// <param name="clientName">Name of the client.</param>
        /// <param name="applicationName">Name of teh application.</param>
        /// <returns>The configuration.</returns>
        public Dictionary<string, BE.ConfigurationParameter> GetConfigurationParametersWithDefaults(string clientName, string applicationName)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { clientName, applicationName }))
            {
                try
                {
                    Dictionary<string, BE.ConfigurationParameter> results = new Dictionary<string, BE.ConfigurationParameter>();

                    try
                    {
                        string url = String.Format("/api/Configuration?clientName={0}&applicationName={1}",
                                                 clientName, applicationName);
                        string path = Uri.EscapeUriString(client.BaseAddress + url);
                        string jsonResponse = client.DownloadString(path, ApplicationSettings.MaxAutoRetriesHttp, ApplicationSettings.AutoRetrySleepMsHttp, ApplicationSettings.AutoTimeoutIncrementMsHttp);

                        JObject jsonObj = JObject.Parse(jsonResponse);

                        results = jsonObj.ToObject<Dictionary<string, BE.ConfigurationParameter>>();
                    }
                    catch (Exception)
                    {
                        // Logging is likely not initialized at this point -- so we can't log.
                        // This is an "expected" error as we transition to using the Configuration Server -- so I am ignoring it.
                    }
                    return results;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { clientName, applicationName }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
    }
}
