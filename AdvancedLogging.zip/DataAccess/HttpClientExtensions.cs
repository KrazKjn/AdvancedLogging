using System;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AdvancedLogging.Logging;
using static AdvancedLogging.Logging.LoggingUtils;

#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning disable CS8603 // Possible null reference return.
namespace AdvancedLogging.DAL
{
    public static class HttpClientExtensions
    {
        //public static Task<HttpResponseMessage> DeleteAsync(this HttpClient _WebClient, string requestUri, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> DeleteAsync(this HttpClient _WebClient, string requestUri, CancellationToken cancellationToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> DeleteAsync(this HttpClient _WebClient, Uri requestUri, CancellationToken cancellationToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> DeleteAsync(this HttpClient _WebClient, Uri requestUri, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> GetAsync(this HttpClient _WebClient, string requestUri, HttpCompletionOption completionOption, CancellationToken cancellationToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> GetAsync(this HttpClient _WebClient, Uri requestUri, CancellationToken cancellationToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> GetAsyncthis HttpClient _WebClient, (Uri requestUri, HttpCompletionOption completionOption, CancellationToken cancellationToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> GetAsync(this HttpClient _WebClient, Uri requestUri, HttpCompletionOption completionOption, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> GetAsync(this HttpClient _WebClient, string requestUri, HttpCompletionOption completionOption, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> GetAsync(this HttpClient _WebClient, Uri requestUri, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> GetAsync(this HttpClient _WebClient, string requestUri, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> GetAsync(this HttpClient _WebClient, string requestUri, CancellationToken cancellationToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<byte[]> GetByteArrayAsyncthis HttpClient _WebClient, (string requestUri, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<byte[]> GetByteArrayAsync(this HttpClient _WebClient, Uri requestUri, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<Stream> GetStreamAsync(this HttpClient _WebClient, Uri requestUri, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<Stream> GetStreamAsyncthis HttpClient _WebClient, (string requestUri, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<string> GetStringAsync(this HttpClient _WebClient, string requestUri, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<string> GetStringAsyncthis HttpClient _WebClient, (Uri requestUri, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> PostAsync(this HttpClient _WebClient, string requestUri, HttpContent content, CancellationToken cancellationToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> PostAsync(this HttpClient _WebClient, Uri requestUri, HttpContent content, CancellationToken cancellationToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> PostAsync(this HttpClient _WebClient, Uri requestUri, HttpContent content, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        public static Task<HttpResponseMessage> PostAsync(this HttpClient _WebClient, string requestUri, HttpContent content, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0)
        {
            using (var vAutoLogFunction = new AutoLogFunction(new { _WebClient, requestUri, content, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }))
            {
                try
                {
                    Task<HttpResponseMessage> wr = null;
                    bool bSuccess = true;
                    // Add 1 so that we process the original request + the _Retries
                    for (int i = 0; i < (_Retries + 1); i++)
                    {
                        Stopwatch sw = null;
                        int iIncreaseValueForTimeout = 0;
                        try
                        {
                            sw = new Stopwatch();
                            sw?.Start();
                            wr = _WebClient.PostAsync(requestUri, content);
                            sw?.Stop();
                            if (sw != null)
                            {
                                LoggingUtils.ProcessStopWatch(ref sw, vAutoLogFunction, requestUri, LoggingUtils.DebugPrintLevel[CLog.Log_FunctionHeaderMethod]);
                            }
                            if (!bSuccess)
                            {
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retry is Successful!");
                            }
                            return wr;
                        }
                        catch (WebException ex)
                        {
                            if (i == (_Retries - 1))
                            {
                                vAutoLogFunction.LogFunction(new { _WebClient, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ex);
                                throw;
                            }
                            if (bSuccess)
                            {
                                bSuccess = false;
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ...", ex);
                            }
                            else
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ... (Error: " + ex.Message + ")");
                            if (ex.Status == WebExceptionStatus.Timeout)
                            {
                                iIncreaseValueForTimeout = _iAutoTimeoutIncrement;
                            }
                        }
                        catch (Exception ex)
                        {
                            if (i == (_Retries - 1))
                            {
                                vAutoLogFunction.LogFunction(new { _WebClient, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ex);
                                throw;
                            }
                            if (bSuccess)
                            {
                                bSuccess = false;
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ...", ex);
                            }
                            else
                                vAutoLogFunction.WriteLog("HttpWebRequest.GetResponse: Retrying (" + (i + 1).ToString() + "/" + _Retries.ToString() + " ... (Error: " + ex.Message + ")");
                        }
                        if (_RetryWaitMS > 250)
                        {
                            DateTime dt = DateTime.Now.AddMilliseconds(_RetryWaitMS);
                            while (dt > DateTime.Now && ApplicationSettings.IsRunning)
                            {
                                System.Threading.Thread.Sleep(250);
                            }
                        }
                        else
                            System.Threading.Thread.Sleep(_RetryWaitMS);

                        _WebClient.Timeout = _WebClient.Timeout.Add(new TimeSpan(iIncreaseValueForTimeout));
                    }
                    return wr;
                }
                catch (Exception ExOuter)
                {
                    vAutoLogFunction.LogFunction(new { _WebClient, requestUri, content, _Retries, _RetryWaitMS, _iAutoTimeoutIncrement }, System.Reflection.MethodBase.GetCurrentMethod(), true, ExOuter);
                    throw;
                }
            }
        }
        //public static Task<HttpResponseMessage> PutAsync(this HttpClient _WebClient, string requestUri, HttpContent content, CancellationToken cancellationToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> PutAsync(this HttpClient _WebClient, string requestUri, HttpContent content, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> PutAsync(this HttpClient _WebClient, Uri requestUri, HttpContent content, CancellationToken cancellationToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> PutAsync(this HttpClient _WebClient, Uri requestUri, HttpContent content, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> SendAsync(this HttpClient _WebClient, HttpRequestMessage request, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static override Task<HttpResponseMessage> SendAsync(this HttpClient _WebClient, HttpRequestMessage request, CancellationToken cancellationToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> SendAsync(this HttpClient _WebClient, HttpRequestMessage request, HttpCompletionOption completionOption, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
        //public static Task<HttpResponseMessage> SendAsync(this HttpClient _WebClient, HttpRequestMessage request, HttpCompletionOption completionOption, CancellationToken cancellationToken, int _Retries, int _RetryWaitMS, int _iAutoTimeoutIncrement = 0);
    }
}
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning restore CS8603 // Possible null reference return.
